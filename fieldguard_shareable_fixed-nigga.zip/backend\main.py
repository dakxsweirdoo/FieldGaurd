﻿import csv
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Optional

import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, ImageFilter


# ============================================================
# FIELDGUARD AI LOCATION
# ============================================================

AI_ROOT = Path(
    os.getenv(
        "FIELDGUARD_AI_ROOT",
        r"C:\FieldGuard",
    )
)

if str(AI_ROOT) not in sys.path:
    sys.path.insert(0, str(AI_ROOT))


# ============================================================
# LOAD REAL FIELDGUARD AI
# ============================================================

try:
    from fieldguard_ai_core import analyze_image
    AI_IMPORT_ERROR = None
except Exception as exc:
    analyze_image = None
    AI_IMPORT_ERROR = str(exc)


# ============================================================
# APPLICATION
# ============================================================

app = FastAPI(
    title="FieldGuard AI API",
    version="2.1.0",
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# GENERIC RESULT CONVERSION
# ============================================================

def result_to_dict(value):
    if hasattr(value, "__dataclass_fields__"):
        return {
            name: result_to_dict(getattr(value, name))
            for name in value.__dataclass_fields__
        }
    if isinstance(value, dict):
        return {
            str(key): result_to_dict(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [result_to_dict(item) for item in value]
    return value


# ============================================================
# SENSOR PARSER
# ============================================================

def parse_sensor(raw: Optional[str]):
    if raw is None or raw == "":
        return None

    try:
        values = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid sensor_readings JSON: {exc}",
        )

    if not isinstance(values, list):
        raise HTTPException(
            status_code=400,
            detail="sensor_readings must be a JSON list.",
        )

    if len(values) != 31:
        raise HTTPException(
            status_code=400,
            detail=(
                "Exactly 31 sensor readings are required. "
                f"Received {len(values)}."
            ),
        )

    try:
        return [float(value) for value in values]
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Sensor readings must be numeric: {exc}",
        )


# ============================================================
# SENSOR SAMPLE LOADER
# ============================================================

def load_sensor_sample(sample_id: str):
    csv_path = (
        AI_ROOT
        / "sensor_ai"
        / "data"
        / "sensor_prototype.csv"
    )

    if not csv_path.exists():
        raise HTTPException(
            status_code=404,
            detail="Sensor prototype dataset not found.",
        )

    try:
        import pandas as pd

        sid = int(str(sample_id).strip())
        df = pd.read_csv(csv_path)

        rows = (
            df[df["sample_id"] == sid]
            .sort_values("time_sec")
        )

        if rows.empty:
            raise HTTPException(
                status_code=404,
                detail=f"Sensor sample {sid} was not found.",
            )

        readings = (
            rows["temperature_c"]
            .astype(float)
            .tolist()
        )

        if len(readings) != 31:
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Sensor sample {sid} has {len(readings)} readings; "
                    "expected 31."
                ),
            )

        condition = (
            str(rows["condition"].iloc[0])
            if "condition" in rows.columns
            else None
        )

        return {
            "sample_id": sid,
            "readings": readings,
            "condition": condition,
            "count": len(readings),
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Could not load sensor sample: {exc}",
        )


# ============================================================
# DISPLAY QUALITY METRICS
# ============================================================

def calculate_image_quality(image: Image.Image):
    rgb = image.convert("RGB")
    width, height = rgb.size
    pixels = width * height
    gray = np.asarray(rgb.convert("L"), dtype=np.float32)

    brightness_raw = float(gray.mean())
    brightness = float(
        np.clip(brightness_raw / 255.0 * 100.0, 0, 100)
    )

    contrast_raw = float(gray.std())
    contrast = float(
        np.clip(contrast_raw / 64.0 * 100.0, 0, 100)
    )

    edges = rgb.convert("L").filter(ImageFilter.FIND_EDGES)
    edge_array = np.asarray(edges, dtype=np.float32)
    sharpness_raw = float(edge_array.var())
    sharpness = float(
        np.clip(sharpness_raw / 1000.0 * 100.0, 0, 100)
    )

    return {
        "brightness": round(brightness, 2),
        "contrast": round(contrast, 2),
        "sharpness": round(sharpness, 2),
        "resolution": f"{width} Ã— {height}",
        "width": width,
        "height": height,
        "pixels": pixels,
        "brightness_raw": round(brightness_raw, 2),
        "contrast_raw": round(contrast_raw, 2),
        "sharpness_raw": round(sharpness_raw, 2),
    }


# ============================================================
# AUDIT STORAGE
# ============================================================

def audit_directory() -> Path:
    path = AI_ROOT / "audit_records"
    path.mkdir(parents=True, exist_ok=True)
    return path


def make_case_id() -> str:
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%d-%H%M%S")
    suffix = hashlib.sha256(
        f"{stamp}-{now.timestamp()}".encode("utf-8")
    ).hexdigest()[:6]
    return f"FG-{stamp}-{suffix}"


def record_audit(
    payload: dict,
    *,
    case_id: str,
    timestamp_utc: str,
    image_filename: str,
    image_sha256: str,
    operator_id: Optional[str],
    sensor_sample_id: Optional[str],
):
    directory = audit_directory()

    vision = payload.get("vision") or {}
    sensor = payload.get("sensor") or {}

    record = {
        "case_id": case_id,
        "timestamp_utc": timestamp_utc,
        "operator_id": operator_id,
        "image_filename": image_filename,
        "image_sha256": image_sha256,
        "sensor_sample_id": sensor_sample_id,
        "model_paths": {
            "vision": str(AI_ROOT / "models" / "fieldguard_v2.pt"),
            "quality_gate": str(
                AI_ROOT
                / "quality_risk_gate"
                / "fieldguard_quality_risk_gate.joblib"
            ),
            "sensor": str(
                AI_ROOT
                / "sensor_ai"
                / "v2"
                / "sensor_ai_v2_best.joblib"
            ),
        },
        "quality_risk": vision.get("quality_risk"),
        "quality_gate": vision.get("quality_gate"),
        "vision_raw_class": vision.get("raw_class"),
        "vision_confidence": vision.get("confidence"),
        "vision_probabilities": vision.get("probabilities"),
        "sensor_available": sensor.get("available"),
        "sensor_signal_class": sensor.get("signal_class"),
        "sensor_confidence": sensor.get("confidence"),
        "final_result": payload.get("final_result"),
        "evidence_mode": payload.get("evidence_mode"),
        "reason": payload.get("reason"),
        "warnings": payload.get("warnings", []),
        "prototype_notice": (
            "FieldGuard is an AI-assisted field-screening prototype. "
            "A presumptive positive is not chemical or forensic confirmation, "
            "and a preliminary negative does not establish absence."
        ),
    }

    json_path = directory / f"{case_id}.json"
    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(record, handle, indent=2, ensure_ascii=False, default=str)

    index_path = directory / "audit_index.csv"
    row = {
        "case_id": case_id,
        "timestamp_utc": timestamp_utc,
        "final_result": payload.get("final_result"),
        "evidence_mode": payload.get("evidence_mode"),
        "vision_raw_class": vision.get("raw_class"),
        "vision_confidence": vision.get("confidence"),
        "quality_risk": vision.get("quality_risk"),
        "quality_gate": vision.get("quality_gate"),
        "sensor_signal_class": sensor.get("signal_class"),
        "sensor_confidence": sensor.get("confidence"),
        "image_filename": image_filename,
        "image_sha256": image_sha256,
        "audit_file": str(json_path),
    }

    fieldnames = list(row.keys())
    file_exists = index_path.exists()

    with index_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

    return {
        "recorded": True,
        "case_id": case_id,
        "timestamp_utc": timestamp_utc,
        "operator_id": operator_id,
        "image_filename": image_filename,
        "json_filename": json_path.name,
        "csv_filename": index_path.name,
    }


def audit_ready() -> tuple[bool, Optional[str]]:
    try:
        directory = audit_directory()
        test_path = directory / ".fieldguard_write_test"
        test_path.write_text("ok", encoding="utf-8")
        test_path.unlink(missing_ok=True)
        return True, None
    except Exception as exc:
        return False, str(exc)


# ============================================================
# ROOT
# ============================================================

@app.get("/")
def root():
    ready, audit_error = audit_ready()
    return {
        "service": "FieldGuard AI",
        "status": "online" if analyze_image is not None and ready else "degraded",
        "version": "2.1.0",
        "ai_ready": analyze_image is not None,
        "audit_ready": ready,
        "audit_error": audit_error,
    }


# ============================================================
# HEALTH
# ============================================================

@app.get("/api/health")
def health():
    ready, audit_error = audit_ready()
    ai_ready = analyze_image is not None

    return {
        "status": "ok" if ai_ready and ready else "degraded",
        "service": "fieldguard-ai",
        "ai_ready": ai_ready,
        "audit_ready": ready,
        "ai_root": str(AI_ROOT),
        "ai_error": AI_IMPORT_ERROR,
        "audit_error": audit_error,
    }


# ============================================================
# SENSOR SAMPLE API
# ============================================================

@app.get("/api/sensor/sample/{sample_id}")
def sensor_sample(sample_id: str):
    return load_sensor_sample(sample_id)


# ============================================================
# MAIN ANALYSIS API
# ============================================================

@app.post("/api/analyze")
async def analyze(
    file: Optional[UploadFile] = File(None),
    image: Optional[UploadFile] = File(None),
    sensor_readings: Optional[str] = Form(None),
    sample_id: Optional[str] = Form(None),
    sensor_sample_id: Optional[str] = Form(None),
    sensor_enabled: Optional[str] = Form("true"),
    operator_id: Optional[str] = Form("OFFICER-FG-44"),
):
    if analyze_image is None:
        raise HTTPException(
            status_code=503,
            detail=f"FieldGuard AI unavailable: {AI_IMPORT_ERROR}",
        )

    uploaded = file or image

    if uploaded is None:
        raise HTTPException(
            status_code=400,
            detail="No image was uploaded. Use form field 'file'.",
        )

    if uploaded.content_type and not uploaded.content_type.startswith("image/"):
        raise HTTPException(
            status_code=400,
            detail="Uploaded file must be an image.",
        )

    content = await uploaded.read()
    if not content:
        raise HTTPException(
            status_code=400,
            detail="Uploaded image is empty.",
        )

    try:
        pil_image = Image.open(BytesIO(content)).convert("RGB")
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Could not read uploaded image: {exc}",
        )

    # Sensor inputs are auxiliary. The frontend supplies the prototype sample.
    resolved_sample_id = sensor_sample_id or sample_id
    enabled = str(sensor_enabled).lower() not in {"false", "0", "no", "off"}

    readings = None
    if enabled:
        if sensor_readings:
            readings = parse_sensor(sensor_readings)
        elif resolved_sample_id:
            readings = load_sensor_sample(resolved_sample_id)["readings"]

    quality_metrics = calculate_image_quality(pil_image)
    image_sha256 = hashlib.sha256(content).hexdigest()

    try:
        result = analyze_image(
            pil_image,
            sensor_readings=readings,
        )
        payload = result_to_dict(result)
    except Exception as exc:
        print("\n========== FIELDGUARD AI ERROR ==========")
        print(repr(exc))
        print("==========================================\n")
        raise HTTPException(
            status_code=500,
            detail=f"FieldGuard AI analysis failed: {exc}",
        )

    if not isinstance(payload.get("vision"), dict):
        payload["vision"] = {}
    if not isinstance(payload.get("sensor"), dict):
        payload["sensor"] = {}

    payload["vision"]["quality_metrics"] = quality_metrics
    payload["quality_metrics"] = quality_metrics
    payload["image_sha256"] = image_sha256
    payload["sensor"]["readings"] = readings or []
    payload["sensor_sample_id"] = resolved_sample_id
    payload["operator_id"] = operator_id
    payload["image_filename"] = uploaded.filename or "field_test_image"
    payload["api_version"] = "2.1.0"

    now = datetime.now(timezone.utc)
    case_id = make_case_id()
    timestamp_utc = now.isoformat()

    try:
        audit = record_audit(
            payload,
            case_id=case_id,
            timestamp_utc=timestamp_utc,
            image_filename=uploaded.filename or "field_test_image",
            image_sha256=image_sha256,
            operator_id=operator_id,
            sensor_sample_id=resolved_sample_id,
        )

        payload["case_id"] = case_id
        payload["timestamp"] = timestamp_utc
        payload["audit"] = audit
        payload["audit_status"] = "RECORDED"

    except Exception as exc:
        payload["case_id"] = case_id
        payload["timestamp"] = timestamp_utc
        payload["audit"] = {
            "recorded": False,
            "case_id": case_id,
            "timestamp_utc": timestamp_utc,
            "operator_id": operator_id,
        }
        payload["audit_status"] = "NOT RECORDED"
        payload.setdefault("warnings", []).append(
            f"Audit persistence failed: {exc}"
        )

    return payload


# ============================================================
# DIRECT RUN
# ============================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
    )

