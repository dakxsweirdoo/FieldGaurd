import { useState, useEffect, useCallback } from 'react';
import type { Page, AnalysisResult, CaseRecord } from '@/types';

// Forensic Suite Pages
import { Dashboard } from '@/pages/Dashboard';
import { EvidenceRegistry } from '@/pages/EvidenceRegistry';
import { FieldTestingWizard } from '@/pages/FieldTestingWizard';
import { VerificationPage } from '@/pages/VerificationPage';
import { ChainOfCustodyPage } from '@/pages/ChainOfCustodyPage';
import { KitManagement } from '@/pages/KitManagement';
import { AuditPage } from '@/pages/AuditPage';
import { AnalyticsPage } from '@/pages/AnalyticsPage';
import { PublicVerify } from '@/pages/PublicVerify';

// Core & Legacy Pages
import { Overview } from '@/pages/Overview';
import { NewAnalysis } from '@/pages/NewAnalysis';
import { ResultView } from '@/pages/ResultView';
import { Cases } from '@/pages/Cases';
import { Reports } from '@/pages/Reports';
import { System } from '@/pages/System';
import { Login } from '@/pages/Login';
import { Header } from '@/components/Header';

import {
  analyzeImage,
  resultToCase,
  fetchSensorSample,
  checkApiHealth,
} from '@/lib/api';

import {
  DEMO_RESULTS,
  DEMO_SENSOR_READINGS,
  demoResultToCase,
} from '@/lib/demo-data';

import {
  fetchCases,
  fetchCaseById,
  saveCase,
} from '@/lib/cases';

type AppView = Page | 'result' | 'hero' | 'classic-analysis';

export default function App() {
  const [authenticated, setAuthenticated] = useState(true); // Default to authenticated for instant preview access
  const [view, setView] = useState<AppView>('dashboard');

  const [cases, setCases] = useState<CaseRecord[]>([]);
  const [loadingCases, setLoadingCases] = useState(true);

  const [demoMode, setDemoMode] = useState(false);
  const [apiOnline, setApiOnline] = useState(false);
  const [dbConnected, setDbConnected] = useState(true);

  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const [currentRecord, setCurrentRecord] = useState<CaseRecord | null>(null);
  const [currentImagePreview, setCurrentImagePreview] = useState<string | null>(null);
  const [selectedCase, setSelectedCase] = useState<CaseRecord | null>(null);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string | null>(null);

  /*
   * API health monitoring
   */
  useEffect(() => {
    checkApiHealth().then(setApiOnline);

    const interval = setInterval(() => {
      checkApiHealth().then(setApiOnline);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  /*
   * Load cases
   */
  const loadCases = useCallback(async () => {
    setLoadingCases(true);
    try {
      const data = await fetchCases();
      setCases(data);
      setDbConnected(true);
    } catch {
      setDbConnected(false);
    } finally {
      setLoadingCases(false);
    }
  }, []);

  useEffect(() => {
    if (authenticated) {
      loadCases();
    }
  }, [authenticated, loadCases]);

  /*
   * Navigation
   */
  const navigate = (page: Page | AppView) => {
    setSelectedCase(null);
    setCurrentResult(null);
    setView(page);
  };

  /*
   * Case selection
   */
  const handleSelectCase = async (caseId: string) => {
    const local = cases.find((c) => c.case_id === caseId);
    if (local) {
      setSelectedCase(local);
      setView('cases');
      return;
    }

    try {
      const c = await fetchCaseById(caseId);
      if (c) {
        setSelectedCase(c);
        setView('cases');
      }
    } catch {
      setDbConnected(false);
    }
  };

  /*
   * Live AI Analysis
   */
  const runLiveAnalysis = useCallback(
    async (imageBlob: Blob, imageFilename: string, sensorReadings: number[]) => {
      let sensorData = sensorReadings;
      const backendReadings = await fetchSensorSample('001');

      if (backendReadings && backendReadings.length === 31) {
        sensorData = backendReadings;
      }

      const result = await analyzeImage(imageBlob, sensorData, '001');
      const record = resultToCase(result, imageFilename, sensorData);

      try {
        await saveCase(record);
        setCases((prev) => [record, ...prev]);
      } catch {
        /* Ignore db save errors */
      }

      return { result, record };
    },
    []
  );

  /*
   * Demo Analysis
   */
  const runDemoAnalysis = useCallback(
    async (_imageBlob: Blob, _imageFilename: string, sensorReadings: number[]) => {
      await new Promise((resolve) => setTimeout(resolve, 800));
      const keys = Object.keys(DEMO_RESULTS);
      const demoKey = keys[Math.floor(Math.random() * keys.length)];
      const result = DEMO_RESULTS[demoKey];
      const record = demoResultToCase(result, sensorReadings);

      try {
        await saveCase(record);
        setCases((prev) => [record, ...prev]);
      } catch {
        /* Ignore demo database error */
      }

      return { result, record };
    },
    []
  );

  const handleDemoSelect = useCallback(
    async (demoKey: string) => {
      const result = DEMO_RESULTS[demoKey];
      if (!result) return;

      const record = demoResultToCase(result, DEMO_SENSOR_READINGS);
      try {
        await saveCase(record);
        setCases((prev) => [record, ...prev]);
      } catch {
        /* Ignore demo db error */
      }

      setCurrentResult(result);
      setCurrentRecord(record);
      setCurrentImagePreview(null);
      setView('result');
    },
    []
  );

  const handleAnalysisComplete = (
    result: AnalysisResult,
    record: CaseRecord,
    previewUrl?: string | null
  ) => {
    setCurrentResult(result);
    setCurrentRecord(record);
    setCurrentImagePreview(previewUrl ?? null);
    setView('result');
  };

  const handleNewAnalysis = () => {
    setCurrentResult(null);
    setCurrentRecord(null);
    setCurrentImagePreview(null);
    setView('analysis');
  };

  const toggleDemo = () => {
    setDemoMode((prev) => !prev);
  };

  const handleLogout = () => {
    setAuthenticated(false);
    setView('dashboard');
    setCurrentResult(null);
    setCurrentRecord(null);
    setCurrentImagePreview(null);
    setSelectedCase(null);
  };

  if (!authenticated) {
    return (
      <Login
        onLogin={() => {
          setAuthenticated(true);
          setView('dashboard');
        }}
      />
    );
  }

  const showResult = view === 'result' && currentResult && currentRecord;
  const showCasesDetail = view === 'cases' && selectedCase;
  const runAnalysis = demoMode ? runDemoAnalysis : runLiveAnalysis;

  // Render Public Verify standalone if verify route is active and requested in clean mode
  if (view === 'verify') {
    return (
      <div className="min-h-screen bg-canvas">
        <Header
          page="verify"
          onNavigate={navigate}
          demoMode={demoMode}
          onToggleDemo={toggleDemo}
          apiOnline={apiOnline}
        />
        <main className="pb-16">
          <PublicVerify
            initialEvidenceId={selectedEvidenceId}
            onNavigateHome={() => navigate('dashboard')}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas flex flex-col">
      <Header
        page={
          view === 'result' || view === 'hero' || view === 'classic-analysis'
            ? 'dashboard'
            : (view as Page)
        }
        onNavigate={navigate}
        demoMode={demoMode}
        onToggleDemo={toggleDemo}
        apiOnline={apiOnline}
      />

      <main className="flex-1 pb-16">
        {/* DASHBOARD */}
        {view === 'dashboard' && (
          <Dashboard
            onNavigate={navigate}
            onSelectEvidence={(evId) => {
              setSelectedEvidenceId(evId);
              navigate('evidence');
            }}
          />
        )}

        {/* EVIDENCE REGISTRY */}
        {view === 'evidence' && (
          <EvidenceRegistry
            onNavigate={navigate}
            initialSelectedId={selectedEvidenceId}
          />
        )}

        {/* 12-STEP FIELD TESTING WIZARD */}
        {view === 'analysis' && (
          <FieldTestingWizard
            onNavigate={navigate}
            onComplete={() => navigate('evidence')}
          />
        )}

        {/* VERIFICATION QUEUE */}
        {view === 'verification' && (
          <VerificationPage onNavigate={navigate} />
        )}

        {/* CHAIN OF CUSTODY LEDGER */}
        {view === 'custody' && (
          <ChainOfCustodyPage
            onNavigate={navigate}
            initialEvidenceId={selectedEvidenceId}
          />
        )}

        {/* KIT LOT MANAGEMENT */}
        {view === 'kits' && (
          <KitManagement onNavigate={navigate} />
        )}

        {/* IMMUTABLE AUDIT LOG */}
        {view === 'audit' && (
          <AuditPage onNavigate={navigate} />
        )}

        {/* OPERATIONAL ANALYTICS */}
        {view === 'analytics' && (
          <AnalyticsPage onNavigate={navigate} />
        )}

        {/* CASES VIEW */}
        {view === 'cases' && !showCasesDetail && (
          <Cases
            cases={cases}
            onSelectCase={handleSelectCase}
            onNavigate={navigate}
            selectedCase={null}
            onBack={() => setSelectedCase(null)}
            loading={loadingCases}
          />
        )}

        {showCasesDetail && selectedCase && (
          <Cases
            cases={cases}
            onSelectCase={handleSelectCase}
            onNavigate={navigate}
            selectedCase={selectedCase}
            onBack={() => setSelectedCase(null)}
            loading={loadingCases}
          />
        )}

        {/* CLASSIC ANALYSIS */}
        {view === 'classic-analysis' && (
          <NewAnalysis
            onAnalysisComplete={handleAnalysisComplete}
            runAnalysis={runAnalysis}
            demoMode={demoMode}
            onDemoSelect={handleDemoSelect}
            apiOnline={apiOnline}
          />
        )}

        {/* ANALYSIS RESULT VIEW */}
        {showResult && currentResult && currentRecord && (
          <ResultView
            result={currentResult}
            record={currentRecord}
            imagePreview={currentImagePreview}
            onNewAnalysis={handleNewAnalysis}
            onViewCases={() => navigate('cases')}
          />
        )}

        {/* LEGACY OVERVIEW */}
        {view === 'overview' && (
          <Overview
            cases={cases}
            onNavigate={navigate}
            onSelectCase={handleSelectCase}
            loading={loadingCases}
          />
        )}

        {/* LEGACY REPORTS */}
        {view === 'reports' && <Reports cases={cases} />}

        {/* SYSTEM STATUS */}
        {view === 'system' && (
          <System apiOnline={apiOnline} dbConnected={dbConnected} />
        )}
      </main>

      {/* Enterprise Footer */}
      <footer className="border-t border-line bg-surface mt-auto">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <span className="text-2xs text-ink-light font-mono">
              FIELDGUARD FORENSIC v2.4.0 · ISO/IEC 17025 Compliant
            </span>
            <span className="text-line">|</span>
            <span className="text-2xs text-emerald-700 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              SHA-256 Tamper Evident
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('audit')}
              className="text-2xs font-bold text-guard-700 hover:text-guard-800 uppercase tracking-wider"
            >
              Audit Log (/audit)
            </button>
            <button
              onClick={() => navigate('verify')}
              className="text-2xs font-bold text-guard-700 hover:text-guard-800 uppercase tracking-wider"
            >
              Public Verify
            </button>
            <button
              onClick={handleLogout}
              className="text-2xs font-semibold text-ink-muted hover:text-red-700"
            >
              Logout
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
