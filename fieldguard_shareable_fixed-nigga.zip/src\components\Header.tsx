import React from 'react';
import type { Page, UserRole } from '@/types';
import { useForensicStore } from '@/lib/forensicStore';
import {
  LayoutDashboard,
  FlaskConical,
  FolderOpen,
  FileCheck2,
  ShieldAlert,
  Boxes,
  ScrollText,
  LineChart,
  QrCode,
  Layers,
  Radio,
  Wifi,
  WifiOff,
  UserCheck,
  type LucideIcon,
} from 'lucide-react';

interface HeaderProps {
  page: Page;
  onNavigate: (page: Page) => void;
  demoMode: boolean;
  onToggleDemo: () => void;
  apiOnline: boolean;
}

export function Header({
  page,
  onNavigate,
  demoMode,
  onToggleDemo,
  apiOnline,
}: HeaderProps) {
  const { currentUser, switchRole, syncStatus, syncQueue, syncPendingItems } =
    useForensicStore();

  const navItems: { page: Page; label: string; icon: LucideIcon }[] = [
    { page: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { page: 'cases', label: 'Cases', icon: FolderOpen },
    { page: 'evidence', label: 'Evidence Registry', icon: Layers },
    { page: 'analysis', label: 'Field Test', icon: FlaskConical },
    { page: 'verification', label: 'Verification', icon: FileCheck2 },
    { page: 'custody', label: 'Custody Ledger', icon: ShieldAlert },
    { page: 'kits', label: 'Kit Lots', icon: Boxes },
    { page: 'audit', label: 'Audit Trail', icon: ScrollText },
    { page: 'analytics', label: 'Analytics', icon: LineChart },
    { page: 'verify', label: 'Verify Portal', icon: QrCode },
  ];

  const handleRoleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const role = e.target.value as UserRole;
    switchRole(role);
  };

  return (
    <header className="sticky top-0 z-40 bg-surface/95 backdrop-blur border-b border-line shadow-xs">
      {/* Top Bar: Brand, Role Switcher, System Telemetry */}
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-3 transition-opacity hover:opacity-85 text-left shrink-0"
              aria-label="FieldGuard Home"
            >
              <div className="w-10 h-10 rounded-xl bg-guard-700 text-white flex items-center justify-center shadow-md shadow-guard-700/20">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  <path d="M9 12l2 2 4-4" />
                </svg>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-base font-black tracking-tight text-ink">
                    FIELD<span className="text-guard-700">GUARD</span>
                  </span>
                  <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-guard-50 text-guard-800 border border-guard-200">
                    FORENSIC
                  </span>
                </div>
                <div className="text-[10px] font-semibold text-ink-light tracking-wider uppercase">
                  Digital Evidence Integrity Platform
                </div>
              </div>
            </button>
          </div>

          {/* Center/Right: Role Switcher, Offline Sync Badge, Demo/Live Toggle */}
          <div className="flex items-center gap-3">
            {/* Offline Sync Indicator */}
            <div
              className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border text-2xs font-bold uppercase tracking-wider transition-all ${
                syncStatus === 'OFFLINE'
                  ? 'bg-amber-50 border-amber-300 text-amber-800'
                  : syncStatus === 'SYNCING'
                  ? 'bg-blue-50 border-blue-300 text-blue-800'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-800'
              }`}
            >
              {syncStatus === 'OFFLINE' ? (
                <WifiOff size={13} className="text-amber-600 animate-pulse" />
              ) : (
                <Wifi size={13} className="text-emerald-600" />
              )}
              <span>{syncStatus}</span>
              {syncQueue.length > 0 && (
                <button
                  onClick={() => syncPendingItems()}
                  className="bg-amber-200 hover:bg-amber-300 text-amber-900 px-1.5 py-0.5 rounded text-[10px] font-mono"
                  title="Click to flush offline queue"
                >
                  {syncQueue.length} pending
                </button>
              )}
            </div>

            {/* Active User / Role Selector */}
            <div className="flex items-center gap-2 bg-canvas px-3 py-1 rounded-xl border border-line">
              <UserCheck size={14} className="text-guard-700 shrink-0" />
              <div className="text-left hidden lg:block">
                <div className="text-[10px] font-semibold text-ink-light uppercase">Active Role</div>
                <div className="text-xs font-bold text-ink truncate max-w-[110px]">
                  {currentUser?.full_name || currentUser?.name || 'Officer'}
                </div>
              </div>
              <select
                value={currentUser.role}
                onChange={handleRoleChange}
                className="bg-transparent text-xs font-bold text-guard-800 py-1 pl-1 pr-2 border-none focus:outline-none cursor-pointer"
                title="Switch role to simulate permissions"
              >
                <option value="FIELD_OFFICER">FIELD OFFICER</option>
                <option value="SUPERVISOR">SUPERVISOR</option>
                <option value="FORENSIC_ANALYST">ANALYST</option>
                <option value="AUDITOR">AUDITOR</option>
                <option value="ADMIN">ADMIN</option>
              </select>
            </div>

            {/* Live / Demo Mode Pill */}
            <button
              onClick={onToggleDemo}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                demoMode
                  ? 'bg-amber-500 border-amber-500 text-white shadow-sm'
                  : 'bg-surface border-line text-ink-muted hover:text-ink hover:border-guard-300'
              }`}
            >
              <Radio size={13} strokeWidth={2.5} />
              <span>{demoMode ? 'Demo Mode' : 'Live Mode'}</span>
            </button>
          </div>
        </div>

        {/* Primary Sub-Navigation Row */}
        <div className="flex items-center gap-1 pb-2 pt-1 overflow-x-auto scrollbar-none border-t border-line/60">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = page === item.page;

            return (
              <button
                key={item.page}
                onClick={() => onNavigate(item.page)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all duration-150 ${
                  active
                    ? 'bg-guard-700 text-white shadow-sm'
                    : 'text-ink-muted hover:text-ink hover:bg-canvas'
                }`}
              >
                <Icon size={14} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
export default Header;
