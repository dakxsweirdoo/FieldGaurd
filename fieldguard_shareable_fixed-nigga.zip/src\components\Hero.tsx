import { Camera, ScanLine, Eye, Radio, ShieldCheck, FileLock2, ArrowRight, Play } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface HeroProps {
  onStart: () => void;
  onViewCases: () => void;
}

const pipeline = [
  { icon: Camera, label: 'Capture', num: '01' },
  { icon: ScanLine, label: 'Quality', num: '02' },
  { icon: Eye, label: 'Vision', num: '03' },
  { icon: Radio, label: 'Sensor', num: '04' },
  { icon: ShieldCheck, label: 'Decision', num: '05' },
  { icon: FileLock2, label: 'Audit', num: '06' },
];

export function Hero({ onStart, onViewCases }: HeroProps) {
  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-10 sm:py-16 animate-fade-in">
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-ink">
          FIELD<span className="text-guard-600">GUARD</span>
        </h1>
        <p className="text-sm sm:text-base font-medium uppercase tracking-[0.2em] text-ink-muted mt-4">
          AI-Assisted Field Screening
        </p>
        <p className="text-base sm:text-lg text-ink-soft mt-6 leading-relaxed text-balance">
          From field evidence to explainable operational decisions.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
          <Button size="lg" onClick={onStart}>
            <Play size={18} fill="currentColor" />
            Start New Analysis
          </Button>
          <Button size="lg" variant="secondary" onClick={onViewCases}>
            View Cases
            <ArrowRight size={16} />
          </Button>
        </div>
      </div>

      <div className="mt-14 sm:mt-20">
        <div className="flex items-center justify-center gap-1 sm:gap-2 flex-wrap">
          {pipeline.map((step, i) => {
            const Icon = step.icon;
            return (
              <div key={step.label} className="flex items-center">
                <div className="flex flex-col items-center gap-2.5">
                  <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-[10px] bg-surface border border-line flex items-center justify-center">
                    <Icon size={22} className="text-guard-600" strokeWidth={1.8} />
                    <span className="absolute -top-1.5 -left-1.5 text-2xs font-mono font-bold text-ink-light bg-canvas px-1 rounded">
                      {step.num}
                    </span>
                  </div>
                  <span className="text-2xs font-semibold uppercase tracking-wider text-ink-muted">{step.label}</span>
                </div>
                {i < pipeline.length - 1 && (
                  <ArrowRight size={16} className="text-line-strong mx-1 sm:mx-2.5 hidden sm:block" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-14 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
        <div className="text-center p-4 border-t border-line-soft pt-5">
          <div className="w-9 h-9 rounded-lg bg-guard-50 flex items-center justify-center mx-auto mb-3">
            <ShieldCheck size={17} className="text-guard-600" />
          </div>
          <p className="text-sm font-semibold text-ink">Safety-First Decisions</p>
          <p className="text-xs text-ink-muted mt-1 leading-relaxed">Quality-gated results with decision policy layer</p>
        </div>
        <div className="text-center p-4 border-t border-line-soft pt-5">
          <div className="w-9 h-9 rounded-lg bg-guard-50 flex items-center justify-center mx-auto mb-3">
            <Eye size={17} className="text-guard-600" />
          </div>
          <p className="text-sm font-semibold text-ink">Explainable Evidence</p>
          <p className="text-xs text-ink-muted mt-1 leading-relaxed">Every result shows its reasoning and confidence</p>
        </div>
        <div className="text-center p-4 border-t border-line-soft pt-5">
          <div className="w-9 h-9 rounded-lg bg-guard-50 flex items-center justify-center mx-auto mb-3">
            <FileLock2 size={17} className="text-guard-600" />
          </div>
          <p className="text-sm font-semibold text-ink">Tamper-Traceable</p>
          <p className="text-xs text-ink-muted mt-1 leading-relaxed">SHA-256 hashed audit records for every case</p>
        </div>
      </div>
    </div>
  );
}

