import { ShieldCheck } from 'lucide-react';

export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const dims = {
    sm: { box: 'w-7 h-7', icon: 15, text: 'text-sm', sub: 'text-2xs' },
    md: { box: 'w-9 h-9', icon: 19, text: 'text-base', sub: 'text-2xs' },
    lg: { box: 'w-12 h-12', icon: 26, text: 'text-xl', sub: 'text-xs' },
  }[size];

  return (
    <div className="flex items-center gap-2.5">
      <div className={`${dims.box} rounded-[10px] bg-guard-700 flex items-center justify-center`}>
        <ShieldCheck size={dims.icon} className="text-white" strokeWidth={2.3} />
      </div>
      <div className="flex flex-col leading-none">
        <span className={`${dims.text} font-bold tracking-tight text-ink`}>
          FIELD<span className="text-guard-600">GUARD</span>
        </span>
        <span className={`${dims.sub} font-medium uppercase tracking-[0.16em] text-ink-light mt-0.5`}>
          AI-Assisted Field Screening
        </span>
      </div>
    </div>
  );
}

