import { AlertTriangle, Info, ShieldAlert, XCircle } from 'lucide-react';
import type { FinalResult } from '@/types';

interface SafetyNoticeProps {
  result: FinalResult;
}

export function SafetyNotice({ result }: SafetyNoticeProps) {
  if (result === 'PRESUMPTIVE POSITIVE') {
    return (
      <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-50 border border-amber-200">
        <div className="w-8 h-8 rounded-lg bg-amber-200 flex items-center justify-center shrink-0">
          <ShieldAlert size={16} className="text-amber-700" strokeWidth={2} />
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-amber-700">Preliminary Visual Screening</p>
          <p className="text-sm text-amber-700 mt-1 leading-relaxed">
            This result is not chemical, laboratory or forensic confirmation.
          </p>
        </div>
      </div>
    );
  }

  if (result === 'PRELIMINARY NEGATIVE') {
    return (
      <div className="flex items-start gap-3 p-4 rounded-xl bg-guard-50 border border-guard-200">
        <div className="w-8 h-8 rounded-lg bg-guard-200 flex items-center justify-center shrink-0">
          <Info size={16} className="text-guard-700" strokeWidth={2} />
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-guard-700">Preliminary Visual Screening</p>
          <p className="text-sm text-guard-700 mt-1 leading-relaxed">
            A negative visual screening result does not establish absence of a substance.
          </p>
        </div>
      </div>
    );
  }

  if (result === 'INCONCLUSIVE') {
    return (
      <div className="flex items-start gap-3 p-4 rounded-xl bg-info-50 border border-info-200">
        <div className="w-8 h-8 rounded-lg bg-info-200 flex items-center justify-center shrink-0">
          <AlertTriangle size={16} className="text-info-600" strokeWidth={2} />
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-info-600">Additional Evidence Required</p>
          <p className="text-sm text-info-600 mt-1 leading-relaxed">
            The current evidence does not meet the operational confidence/quality criteria.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-3 p-4 rounded-xl bg-alert-50 border border-alert-200">
      <div className="w-8 h-8 rounded-lg bg-alert-200 flex items-center justify-center shrink-0">
        <XCircle size={16} className="text-alert-700" strokeWidth={2} />
      </div>
      <div>
        <p className="text-xs font-bold uppercase tracking-wider text-alert-700">Invalid Input</p>
        <p className="text-sm text-alert-700 mt-1 leading-relaxed">
          The visual evidence is not suitable for this analysis.
        </p>
      </div>
    </div>
  );
}

