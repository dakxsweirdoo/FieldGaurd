import { Check } from 'lucide-react';
import type { WorkflowStep } from '@/types';

interface WorkflowProps {
  steps: WorkflowStep[];
  currentStep: number;
}

const stepLabels: Record<WorkflowStep, string> = {
  CAPTURE: 'Capture',
  QUALITY: 'Quality',
  VISION: 'Vision',
  SENSOR: 'Sensor',
  DECISION: 'Decision',
  AUDIT: 'Audit',
};

export function WorkflowIndicator({ steps, currentStep }: WorkflowProps) {
  return (
    <div className="w-full">
      <div className="flex items-center gap-0.5 sm:gap-1">
        {steps.map((step, i) => {
          const isComplete = i < currentStep;
          const isActive = i === currentStep;
          const isPending = i > currentStep;

          return (
            <div key={step} className="flex items-center flex-1 last:flex-none">
              <div className="flex flex-col items-center gap-1.5 min-w-0">
                <div
                  className={`flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-[10px] border-[1.5px] transition-all duration-200 shrink-0 ${
                    isComplete
                      ? 'bg-guard-600 border-guard-600'
                      : isActive
                        ? 'bg-surface border-guard-500 ring-[3px] ring-guard-50'
                        : 'bg-surface border-line-strong'
                  }`}
                >
                  {isComplete ? (
                    <Check size={14} className="text-white" strokeWidth={3} />
                  ) : (
                    <span
                      className={`text-2xs font-bold font-mono ${
                        isActive ? 'text-guard-600' : 'text-ink-light'
                      }`}
                    >
                      {String(i + 1).padStart(2, '0')}
                    </span>
                  )}
                </div>
                <span
                  className={`text-2xs font-semibold uppercase tracking-wider whitespace-nowrap transition-colors ${
                    isComplete || isActive ? 'text-ink-soft' : 'text-ink-light'
                  }`}
                >
                  {stepLabels[step]}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div
                  className={`flex-1 h-[1.5px] mx-1 sm:mx-1.5 mb-5 transition-colors duration-300 ${
                    isComplete ? 'bg-guard-400' : 'bg-line-strong'
                  }`}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface ProgressListProps {
  steps: { label: string; status: 'pending' | 'active' | 'complete' }[];
}

export function ProgressList({ steps }: ProgressListProps) {
  return (
    <div className="space-y-1">
      {steps.map((step, i) => (
        <div key={step.label} className="flex items-center gap-3 py-1.5">
          <div className="w-7 flex items-center justify-center shrink-0">
            {step.status === 'complete' && (
              <div className="w-5 h-5 rounded-full bg-guard-600 flex items-center justify-center animate-step-complete">
                <Check size={12} className="text-white" strokeWidth={3} />
              </div>
            )}
            {step.status === 'active' && (
              <div className="w-5 h-5 rounded-full border-2 border-guard-500 border-t-transparent animate-spin" />
            )}
            {step.status === 'pending' && (
              <div className="w-5 h-5 rounded-full border-[1.5px] border-line-strong" />
            )}
          </div>
          <span className="text-2xs font-mono font-bold text-ink-light w-6 shrink-0">
            {String(i + 1).padStart(2, '0')}
          </span>
          <span
            className={`text-sm transition-colors ${
              step.status === 'complete'
                ? 'text-ink-soft font-medium'
                : step.status === 'active'
                  ? 'text-ink font-semibold'
                  : 'text-ink-light'
            }`}
          >
            {step.label}
          </span>
        </div>
      ))}
    </div>
  );
}

