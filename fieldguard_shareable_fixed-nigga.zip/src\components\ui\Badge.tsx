import type { ReactNode } from 'react';

type Tone = 'guard' | 'amber' | 'alert' | 'info' | 'neutral';

const tones: Record<Tone, { bg: string; text: string; border: string; dot: string }> = {
  guard: { bg: 'bg-guard-50', text: 'text-guard-700', border: 'border-guard-200', dot: 'bg-guard-500' },
  amber: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', dot: 'bg-amber-400' },
  alert: { bg: 'bg-alert-50', text: 'text-alert-700', border: 'border-alert-200', dot: 'bg-alert-500' },
  info: { bg: 'bg-info-50', text: 'text-info-600', border: 'border-info-200', dot: 'bg-info-400' },
  neutral: { bg: 'bg-canvas-warm', text: 'text-ink-soft', border: 'border-line', dot: 'bg-ink-light' },
};

interface BadgeProps {
  tone?: Tone;
  children: ReactNode;
  dot?: boolean;
  pulse?: boolean;
  className?: string;
}

export function Badge({ tone = 'neutral', children, dot = false, pulse = false, className = '' }: BadgeProps) {
  const t = tones[tone];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-2xs font-bold uppercase tracking-wider border ${t.bg} ${t.text} ${t.border} ${className}`}>
      {dot && (
        <span className={`relative flex w-1.5 h-1.5 ${pulse ? '' : ''}`}>
          {pulse && <span className={`absolute inline-flex w-full h-full rounded-full ${t.dot} opacity-60 animate-ping`} />}
          <span className={`relative inline-flex w-1.5 h-1.5 rounded-full ${t.dot}`} />
        </span>
      )}
      {children}
    </span>
  );
}

export function StatusDot({ tone = 'guard', pulse = false }: { tone?: Tone; pulse?: boolean }) {
  const t = tones[tone];
  return (
    <span className="relative flex w-2 h-2">
      {pulse && <span className={`absolute inline-flex w-full h-full rounded-full ${t.dot} opacity-60 animate-ping`} />}
      <span className={`relative inline-flex w-2 h-2 rounded-full ${t.dot}`} />
    </span>
  );
}

