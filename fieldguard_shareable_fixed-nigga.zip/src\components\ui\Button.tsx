import type {
  ButtonHTMLAttributes,
  ReactNode,
} from 'react';

type Variant =
  | 'primary'
  | 'secondary'
  | 'ghost'
  | 'danger'
  | 'outline';

type Size =
  | 'sm'
  | 'md'
  | 'lg';

interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
}

const variants: Record<Variant, string> = {
  primary:
    'bg-guard-600 text-white hover:bg-guard-700 active:bg-guard-800 shadow-sm',

  secondary:
    'bg-surface border border-line-strong text-ink hover:bg-canvas-warm hover:border-ink-light shadow-sm',

  ghost:
    'text-ink-soft hover:bg-canvas-warm hover:text-ink',

  danger:
    'bg-alert-500 text-white hover:bg-alert-600 active:bg-alert-700 shadow-sm',

  outline:
    'border border-guard-300 text-guard-700 hover:bg-guard-50 hover:border-guard-400',
};

const sizes: Record<Size, string> = {
  sm:
    'px-3 py-1.5 text-xs rounded-lg gap-1.5',

  md:
    'px-4 py-2.5 text-sm rounded-lg gap-2',

  lg:
    'px-6 py-3.5 text-sm rounded-xl gap-2.5',
};

export function Button({
  variant = 'primary',
  size = 'md',
  children,
  className = '',
  disabled = false,
  ...props
}: ButtonProps) {
  return (
    <button
      type="button"
      className={[
        'inline-flex',
        'items-center',
        'justify-center',
        'font-semibold',
        'transition-all',
        'duration-150',

        variants[variant],
        sizes[size],

        disabled
          ? 'opacity-40 cursor-not-allowed pointer-events-none'
          : 'cursor-pointer',

        className,
      ].join(' ')}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
}
