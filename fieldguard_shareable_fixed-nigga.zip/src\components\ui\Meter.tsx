interface MeterProps {
  label: string;
  value: number;
  unit?: string;
  max?: number;
  tone?: 'auto' | 'guard' | 'amber' | 'alert';
}

export function Meter({ label, value, unit = '%', max = 100, tone = 'auto' }: MeterProps) {
  const pct = Math.min(100, (value / max) * 100);

  const resolvedTone =
    tone === 'auto'
      ? pct >= 70
        ? 'guard'
        : pct >= 40
          ? 'amber'
          : 'alert'
      : tone;

  const barColors: Record<string, string> = {
    guard: 'bg-guard-500',
    amber: 'bg-amber-400',
    alert: 'bg-alert-400',
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="data-label">{label}</span>
        <span className="text-xs font-mono font-semibold text-ink">
          {value.toFixed(0)}{unit}
        </span>
      </div>
      <div className="h-1.5 rounded-full bg-canvas-warm overflow-hidden">
        <div
          className={`h-full rounded-full ${barColors[resolvedTone]} transition-all duration-500`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

