import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';

interface PanelProps {
  children: ReactNode;
  className?: string;
  raised?: boolean;
}

export function Panel({ children, className = '', raised = false }: PanelProps) {
  return (
    <div className={`${raised ? 'panel-raised' : 'panel'} ${className}`}>
      {children}
    </div>
  );
}

interface PanelHeaderProps {
  icon?: LucideIcon;
  title: string;
  subtitle?: string;
  action?: ReactNode;
  className?: string;
}

export function PanelHeader({ icon: Icon, title, subtitle, action, className = '' }: PanelHeaderProps) {
  return (
    <div className={`flex items-start justify-between px-5 py-4 border-b border-line-soft ${className}`}>
      <div className="flex items-center gap-3">
        {Icon && (
          <div className="w-8 h-8 rounded-lg bg-guard-50 flex items-center justify-center shrink-0">
            <Icon size={16} className="text-guard-600" strokeWidth={2} />
          </div>
        )}
        <div>
          <h3 className="text-sm font-bold text-ink tracking-tight">{title}</h3>
          {subtitle && <p className="text-xs text-ink-muted mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

