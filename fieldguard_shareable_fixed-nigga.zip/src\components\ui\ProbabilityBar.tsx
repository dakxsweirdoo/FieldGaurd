interface ProbabilityBarProps {
  label: string;
  value: number;
  tone: 'guard' | 'amber' | 'alert' | 'info' | 'neutral';
}

const barTones: Record<string, string> = {
  guard: 'bg-guard-500',
  amber: 'bg-amber-400',
  alert: 'bg-alert-400',
  info: 'bg-info-400',
  neutral: 'bg-ink-light',
};

const textTones: Record<string, string> = {
  guard: 'text-guard-700',
  amber: 'text-amber-700',
  alert: 'text-alert-700',
  info: 'text-info-600',
  neutral: 'text-ink-soft',
};

export function ProbabilityBar({ label, value, tone }: ProbabilityBarProps) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-24 shrink-0">
        <span className={`text-xs font-bold tracking-wide ${textTones[tone]}`}>{label}</span>
      </div>
      <div className="flex-1 h-5 rounded-md bg-canvas-warm overflow-hidden relative">
        <div
          className={`h-full ${barTones[tone]} transition-all duration-700 ease-out flex items-center justify-end pr-2`}
          style={{ width: `${Math.max(value, 1)}%` }}
        >
          {value > 5 && (
            <span className="text-2xs font-bold text-white">{value.toFixed(2)}%</span>
          )}
        </div>
      </div>
      {value <= 5 && (
        <span className="text-xs font-mono text-ink-muted w-16 text-right">{value.toFixed(2)}%</span>
      )}
    </div>
  );
}

