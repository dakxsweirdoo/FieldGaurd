interface SensorGraphProps {
  readings: number[];
  width?: number;
  height?: number;
  className?: string;
}

export function SensorGraph({ readings, width = 500, height = 120, className = '' }: SensorGraphProps) {
  if (!readings || readings.length === 0) {
    return (
      <div className={`flex items-center justify-center bg-canvas-warm rounded-lg ${className}`} style={{ height }}>
        <span className="text-xs text-ink-light">No sensor data</span>
      </div>
    );
  }

  const padX = 8;
  const padY = 12;
  const innerW = width - padX * 2;
  const innerH = height - padY * 2;

  const min = Math.min(...readings);
  const max = Math.max(...readings);
  const range = max - min || 1;

  const points = readings.map((v, i) => {
    const x = padX + (i / (readings.length - 1)) * innerW;
    const y = padY + innerH - ((v - min) / range) * innerH;
    return { x, y };
  });

  const pathD = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');

  const areaD = `${pathD} L ${points[points.length - 1].x.toFixed(1)} ${padY + innerH} L ${points[0].x.toFixed(1)} ${padY + innerH} Z`;

  const gridLines = [0.25, 0.5, 0.75].map((f) => padY + innerH * f);

  return (
    <div className={className}>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="sensorGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#5A9F6B" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#5A9F6B" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {gridLines.map((y, i) => (
          <line
            key={i}
            x1={padX}
            y1={y}
            x2={width - padX}
            y2={y}
            stroke="#E0DED7"
            strokeWidth="0.5"
            strokeDasharray="3 3"
          />
        ))}
        <path d={areaD} fill="url(#sensorGrad)" />
        <path d={pathD} fill="none" stroke="#3D8452" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" />
        {points.map((p, i) => (
          i === 0 || i === points.length - 1 ? (
            <circle key={i} cx={p.x} cy={p.y} r="2.5" fill="#3D8452" />
          ) : null
        ))}
      </svg>
    </div>
  );
}

