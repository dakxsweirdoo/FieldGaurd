import type {
  AnalysisResult,
  CaseRecord,
  EvidenceMode,
  FinalResult,
  RawPrediction,
  QualityGate,
  SignalClass,
  QualityMetrics,
  Probabilities,
} from '@/types';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

const API_ROOT = `${API_BASE}/api`;

async function parseErrorResponse(response: Response): Promise<string> {
  try {
    const data = await response.json();

    if (typeof data?.detail === 'string') {
      return data.detail;
    }

    if (Array.isArray(data?.detail)) {
      return data.detail
        .map((item: unknown) => {
          if (item && typeof item === 'object' && 'msg' in item) {
            return String((item as { msg?: unknown }).msg ?? 'Request validation failed');
          }
          return JSON.stringify(item);
        })
        .join('; ');
    }

    if (data?.message) {
      return String(data.message);
    }

    return JSON.stringify(data);
  } catch {
    const text = await response.text().catch(() => '');
    return text || `Request failed with status ${response.status}`;
  }
}

// ============================================================
// HEALTH
// ============================================================

export async function checkApiHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${API_ROOT}/health`, {
      method: 'GET',
      cache: 'no-store',
    });

    if (!response.ok) {
      return false;
    }

    const data = await response.json();
    return data?.ai_ready === true;
  } catch (error) {
    console.error('Narcovex API health error:', error);
    return false;
  }
}

// ============================================================
// SENSOR SAMPLE
// ============================================================

interface SensorSampleResponse {
  sample_id: number;
  readings: number[];
  condition?: string;
  count: number;
}

export async function fetchSensorSample(
  sampleId: string,
): Promise<number[]> {
  const response = await fetch(
    `${API_ROOT}/sensor/sample/${encodeURIComponent(sampleId)}`,
    { cache: 'no-store' },
  );

  if (!response.ok) {
    throw new Error(await parseErrorResponse(response));
  }

  const data: SensorSampleResponse = await response.json();

  if (!Array.isArray(data.readings) || data.readings.length !== 31) {
    throw new Error(
      'Invalid sensor sample: exactly 31 readings are required.',
    );
  }

  return data.readings.map(Number);
}

// ============================================================
// ANALYZE IMAGE
// ============================================================

export async function analyzeImage(
  image: Blob,
  sensorReadings: number[],
  sampleId?: string,
): Promise<AnalysisResult> {
  if (sensorReadings.length !== 31) {
    throw new Error(
      'Narcovex requires exactly 31 sensor readings.',
    );
  }

  const formData = new FormData();

  // Backend accepts the field name "file".
  formData.append(
    'file',
    image,
    image instanceof File ? image.name : 'field-test-image.jpg',
  );

  formData.append(
    'sensor_readings',
    JSON.stringify(sensorReadings),
  );

  formData.append('sensor_enabled', 'true');
  formData.append('operator_id', 'OFFICER-FG-44');

  if (sampleId) {
    formData.append('sample_id', sampleId);
    formData.append('sensor_sample_id', sampleId);
  }

  let response: Response;

  try {
    response = await fetch(`${API_ROOT}/analyze`, {
      method: 'POST',
      body: formData,
    });
  } catch (error) {
    console.error('Narcovex API request error:', error);
    throw new Error(
      'NARCOVEX API UNAVAILABLE — could not connect to the AI backend',
    );
  }

  if (!response.ok) {
    throw new Error(await parseErrorResponse(response));
  }

  return await response.json();
}

// ============================================================
// SAFE QUALITY METRICS
// ============================================================

function getQualityMetrics(
  result: AnalysisResult,
): QualityMetrics {
  const metrics = result.vision?.quality_metrics;

  if (metrics) {
    return {
      brightness: Number(metrics.brightness ?? 0),
      contrast: Number(metrics.contrast ?? 0),
      sharpness: Number(metrics.sharpness ?? 0),
      resolution: String(metrics.resolution ?? '—'),
    };
  }

  return {
    brightness: 0,
    contrast: 0,
    sharpness: 0,
    resolution: '—',
  };
}

// ============================================================
// RESULT → CASE
// ============================================================

export function resultToCase(
  result: AnalysisResult,
  imageFilename: string,
  sensorReadings: number[],
): CaseRecord {
  const caseId =
    result.audit?.case_id ||
    result.case_id ||
    `FG-${Date.now()}`;

  const finalResult =
    result.final_result || 'INCONCLUSIVE';

  const rawClass =
    result.vision?.raw_class || 'INCONCLUSIVE';

  const rawPrediction = rawClass.toUpperCase() as RawPrediction;

  const qualityGate =
    result.vision?.quality_gate || ('ACCEPTABLE' as QualityGate);

  const qualityMetrics = getQualityMetrics(result);

  const sensorAvailable = result.sensor?.available ?? false;

  const sensorClass = result.sensor?.signal_class
    ? normalizeSignalClass(result.sensor.signal_class)
    : null;

  const probabilities: Probabilities = {
    POSITIVE: Number(
      result.vision?.probabilities?.POSITIVE ??
      0,
    ),
    NEGATIVE: Number(
      result.vision?.probabilities?.NEGATIVE ??
      0,
    ),
    INCONCLUSIVE: Number(
      result.vision?.probabilities?.INCONCLUSIVE ??
      0,
    ),
    INVALID: Number(
      result.vision?.probabilities?.INVALID ??
      0,
    ),
  };

  return {
    case_id: caseId,
    timestamp: result.audit?.timestamp_utc || new Date().toISOString(),
    image_filename: imageFilename || null,
    image_sha256: result.image_sha256 || null,
    final_result: finalResult as FinalResult,
    raw_prediction: rawPrediction,
    raw_confidence: Number(result.vision?.confidence ?? 0),
    quality_risk: Number(result.vision?.quality_risk ?? 0),
    quality_gate: qualityGate,
    quality_metrics: qualityMetrics,
    sensor_available: sensorAvailable,
    sensor_class: sensorClass,
    sensor_confidence: result.sensor?.confidence ?? null,
    sensor_readings: sensorReadings,
    evidence_mode: (result.evidence_mode || 'VISION_ONLY') as EvidenceMode,
    probabilities,
    reason: result.reason || 'Narcovex completed the screening analysis.',
    warnings: result.warnings || [],
    audit_status: result.audit?.recorded ? 'RECORDED' : 'NOT RECORDED',
  };
}

function normalizeSignalClass(value: string): SignalClass | null {
  const normalized = value.trim().toLowerCase();
  if (normalized === 'baseline') return 'Baseline';
  if (normalized === 'warming') return 'Warming';
  if (normalized === 'cooling') return 'Cooling';
  return null;
}

export function getApiBase(): string {
  return API_BASE;
}



