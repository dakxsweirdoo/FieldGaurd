import { supabase } from '@/lib/supabase';
import type { CaseRecord } from '@/types';
import { SEED_CASES } from '@/lib/demo-data';

function mapRow(row: Record<string, unknown>): CaseRecord {
  return {
    case_id: row.case_id as string,
    timestamp: row.timestamp as string,
    image_filename: row.image_filename as string | null,
    image_sha256: row.image_sha256 as string | null,
    final_result: row.final_result as CaseRecord['final_result'],
    raw_prediction: row.raw_prediction as CaseRecord['raw_prediction'],
    raw_confidence: Number(row.raw_confidence),
    quality_risk: Number(row.quality_risk),
    quality_gate: row.quality_gate as CaseRecord['quality_gate'],
    quality_metrics: row.quality_metrics as CaseRecord['quality_metrics'],
    sensor_available: row.sensor_available as boolean,
    sensor_class: row.sensor_class as CaseRecord['sensor_class'],
    sensor_confidence: row.sensor_confidence !== null ? Number(row.sensor_confidence) : null,
    sensor_readings: (row.sensor_readings as number[]) ?? [],
    evidence_mode: row.evidence_mode as CaseRecord['evidence_mode'],
    probabilities: row.probabilities as CaseRecord['probabilities'],
    reason: row.reason as string,
    warnings: (row.warnings as string[]) ?? [],
    audit_status: row.audit_status as string,
  };
}

export async function fetchCases(): Promise<CaseRecord[]> {
  const { data, error } = await supabase
    .from('cases')
    .select('*')
    .order('timestamp', { ascending: false });

  if (error) throw error;
  if (!data || data.length === 0) {
    await seedDemoCases();
    const { data: reloaded } = await supabase
      .from('cases')
      .select('*')
      .order('timestamp', { ascending: false });
    return (reloaded ?? []).map(mapRow);
  }
  return data.map(mapRow);
}

export async function fetchCaseById(caseId: string): Promise<CaseRecord | null> {
  const { data, error } = await supabase
    .from('cases')
    .select('*')
    .eq('case_id', caseId)
    .maybeSingle();

  if (error) throw error;
  if (!data) return null;
  return mapRow(data);
}

export async function saveCase(record: CaseRecord): Promise<void> {
  const { error } = await supabase.from('cases').insert({
    case_id: record.case_id,
    timestamp: record.timestamp,
    image_filename: record.image_filename,
    image_sha256: record.image_sha256,
    final_result: record.final_result,
    raw_prediction: record.raw_prediction,
    raw_confidence: record.raw_confidence,
    quality_risk: record.quality_risk,
    quality_gate: record.quality_gate,
    quality_metrics: record.quality_metrics,
    sensor_available: record.sensor_available,
    sensor_class: record.sensor_class,
    sensor_confidence: record.sensor_confidence,
    sensor_readings: record.sensor_readings,
    evidence_mode: record.evidence_mode,
    probabilities: record.probabilities,
    reason: record.reason,
    warnings: record.warnings,
    audit_status: record.audit_status,
  });
  if (error) throw error;
}

export async function seedDemoCases(): Promise<void> {
  for (const c of SEED_CASES) {
    const { error } = await supabase.from('cases').insert({
      case_id: c.case_id,
      timestamp: c.timestamp,
      image_filename: c.image_filename,
      image_sha256: c.image_sha256,
      final_result: c.final_result,
      raw_prediction: c.raw_prediction,
      raw_confidence: c.raw_confidence,
      quality_risk: c.quality_risk,
      quality_gate: c.quality_gate,
      quality_metrics: c.quality_metrics,
      sensor_available: c.sensor_available,
      sensor_class: c.sensor_class,
      sensor_confidence: c.sensor_confidence,
      sensor_readings: c.sensor_readings,
      evidence_mode: c.evidence_mode,
      probabilities: c.probabilities,
      reason: c.reason,
      warnings: c.warnings,
      audit_status: c.audit_status,
    }).select('case_id');
    if (error && !error.message.includes('duplicate')) {
      console.warn('Seed insert error:', error.message);
    }
  }
}

export async function getCaseCount(): Promise<number> {
  const { count, error } = await supabase
    .from('cases')
    .select('*', { count: 'exact', head: true });
  if (error) return 0;
  return count ?? 0;
}

