import type { EvidenceItem } from '@/types';

/**
 * Computes a standard SHA-256 hex digest using Web Crypto API.
 */
export async function computeSha256(data: string | ArrayBuffer): Promise<string> {
  let buffer: ArrayBuffer;
  if (typeof data === 'string') {
    const encoder = new TextEncoder();
    buffer = encoder.encode(data).buffer;
  } else {
    buffer = data;
  }

  // Use crypto.subtle if available
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  // Fallback simple bitwise SHA-256 implementation if crypto.subtle is unavailable (e.g. non-secure origins)
  return fallbackSha256(typeof data === 'string' ? data : new TextDecoder().decode(buffer));
}

/**
 * Deterministically canonicalizes evidence core properties to ensure
 * reproducible, tamper-traceable hashing across environments.
 */
export function canonicalizeEvidencePayload(evidence: Partial<EvidenceItem>): string {
  const canonical = {
    evidence_id: evidence.evidence_id || '',
    case_id: evidence.case_id || '',
    sample_id: evidence.sample_id || '',
    evidence_type: evidence.evidence_type || '',
    description: evidence.description || '',
    collected_by: evidence.collected_by || '',
    collection_timestamp: evidence.collection_timestamp || '',
    collection_location: evidence.collection_location || '',
    gps_lat: evidence.gps_coordinates?.lat ?? 0,
    gps_lng: evidence.gps_coordinates?.lng ?? 0,
    device_id: evidence.device_id || '',
    kit_batch_number: evidence.kit_batch_number || '',
    version: evidence.current_version ?? 1,
  };

  return JSON.stringify(canonical, Object.keys(canonical).sort());
}

/**
 * Generates an authentic SHA-256 hash for an evidence record.
 */
export async function generateEvidenceHash(evidence: Partial<EvidenceItem>): Promise<string> {
  const canonicalString = canonicalizeEvidencePayload(evidence);
  return await computeSha256(canonicalString);
}

export interface IntegrityVerificationResult {
  verified: boolean;
  storedHash: string;
  currentHash: string;
  algorithm: 'SHA-256';
  verifiedAt: string;
  isTampered: boolean;
  tamperedField?: string;
  originalValue?: unknown;
  currentValue?: unknown;
  statusText: string;
}

/**
 * Verifies live evidence integrity against the cryptographic stored hash.
 */
export async function verifyEvidenceIntegrity(evidence: EvidenceItem): Promise<IntegrityVerificationResult> {
  const currentHash = await generateEvidenceHash(evidence);
  const storedHash = evidence.sha256_hash;
  const verified = currentHash.toLowerCase() === storedHash.toLowerCase();

  return {
    verified,
    storedHash,
    currentHash,
    algorithm: 'SHA-256',
    verifiedAt: new Date().toISOString(),
    isTampered: !verified || !!evidence.is_tampered,
    tamperedField: evidence.tampered_field,
    originalValue: evidence.original_value,
    currentValue: evidence.tampered_value,
    statusText: verified && !evidence.is_tampered
      ? '✓ Evidence Integrity Verified (Cryptographic SHA-256 matches authentic forensic record)'
      : '⚠ Evidence Integrity Check Failed (Record altered: hash discrepancy detected)',
  };
}

/**
 * Public verification helper to check evidence validity and return status messages.
 */
export async function checkEvidenceIntegrity(evidence: EvidenceItem): Promise<{
  valid: boolean;
  storedHash: string;
  computedHash: string;
  message: string;
}> {
  const check = await verifyEvidenceIntegrity(evidence);
  return {
    valid: check.verified && !check.isTampered,
    storedHash: check.storedHash,
    computedHash: check.currentHash,
    message: check.statusText,
  };
}

/**
 * Pure TypeScript SHA-256 fallback in case Web Crypto is inaccessible.
 */
function fallbackSha256(ascii: string): string {
  function rightRotate(value: number, amount: number) {
    return (value >>> amount) | (value << (32 - amount));
  }

  const mathPow = Math.pow;
  const maxWord = mathPow(2, 32);
  let i = 0;
  let j = 0;
  let result = '';
  const words: number[] = [];
  const asciiBitLength = ascii.length * 8;

  let hash = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ];

  const k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ];

  let compositeClearHex = ascii;
  compositeClearHex += '\x80';
  while (compositeClearHex.length % 64 - 56) compositeClearHex += '\x00';

  for (i = 0; i < compositeClearHex.length; i++) {
    j = compositeClearHex.charCodeAt(i);
    words[i >> 2] |= j << ((3 - (i % 4)) * 8);
  }
  words[words.length] = (asciiBitLength / maxWord) | 0;
  words[words.length] = asciiBitLength;

  for (j = 0; j < words.length;) {
    const w = words.slice(j, (j += 16));
    const oldHash = hash.slice(0);

    for (i = 0; i < 64; i++) {
      const w15 = w[i - 15];
      const w2 = w[i - 2];

      const s0 = rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3);
      const s1 = rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10);

      const ch = (hash[4] & hash[5]) ^ (~hash[4] & hash[6]);
      const maj = (hash[0] & hash[1]) ^ (hash[0] & hash[2]) ^ (hash[1] & hash[2]);
      const temp1 = (hash[7] + (rightRotate(hash[4], 6) ^ rightRotate(hash[4], 11) ^ rightRotate(hash[4], 25)) + ch + k[i] + (w[i] = i < 16 ? w[i] : (w[i - 16] + s0 + w[i - 7] + s1) | 0)) | 0;
      const temp2 = ((rightRotate(hash[0], 2) ^ rightRotate(hash[0], 13) ^ rightRotate(hash[0], 22)) + maj) | 0;

      hash = [(temp1 + temp2) | 0, hash[0], hash[1], hash[2], (hash[3] + temp1) | 0, hash[4], hash[5], hash[6]];
    }

    for (i = 0; i < 8; i++) {
      hash[i] = (hash[i] + oldHash[i]) | 0;
    }
  }

  for (i = 0; i < 8; i++) {
    for (let b = 3; b >= 0; b--) {
      const byte = (hash[i] >> (b * 8)) & 255;
      result += (byte < 16 ? '0' : '') + byte.toString(16);
    }
  }
  return result;
}
