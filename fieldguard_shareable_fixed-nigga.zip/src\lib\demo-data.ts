import type { AnalysisResult, CaseRecord, SignalClass } from '@/types';

function genSensorReadings(seed: number, baseline: number, drift: number): number[] {
  const readings: number[] = [];
  for (let i = 0; i < 31; i++) {
    const t = i / 30;
    const noise = Math.sin(i * 1.7 + seed) * 0.08 + Math.sin(i * 0.4 + seed * 2) * 0.05;
    readings.push(baseline + drift * t + noise);
  }
  return readings;
}

export const DEMO_SENSOR_READINGS = genSensorReadings(42, 0.62, 0.08);

export const DEMO_SENSOR_WARMING = genSensorReadings(13, 0.55, 0.22);

export const DEMO_SENSOR_COOLING = genSensorReadings(77, 0.70, -0.15);

function sha256ish(): string {
  const chars = '0123456789abcdef';
  let hash = '';
  for (let i = 0; i < 64; i++) {
    hash += chars[Math.floor(Math.random() * 16)];
  }
  return hash;
}

function genCaseId(): string {
  const now = new Date();
  const date = `${now.getUTCFullYear()}${String(now.getUTCMonth() + 1).padStart(2, '0')}${String(now.getUTCDate()).padStart(2, '0')}`;
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `FG-${date}-${rand}`;
}

function makeResult(
  finalResult: AnalysisResult['final_result'],
  rawClass: AnalysisResult['vision']['raw_class'],
  confidence: number,
  qualityRisk: number,
  qualityGate: AnalysisResult['vision']['quality_gate'],
  signalClass: SignalClass,
  sensorAvailable: boolean,
  probs: { POSITIVE: number; NEGATIVE: number; INCONCLUSIVE: number; INVALID: number },
  reason: string,
  warnings: string[],
): AnalysisResult {
  return {
    final_result: finalResult,
    evidence_mode: sensorAvailable ? 'VISION_PLUS_AUXILIARY_SENSOR' : 'VISION_ONLY',
    reason,
    vision: {
      quality_risk: qualityRisk,
      quality_gate: qualityGate,
      quality_reason: qualityRisk > 35
        ? 'Image brightness and sharpness below acceptable threshold.'
        : 'Image meets quality control standards.',
      raw_class: rawClass,
      confidence,
      probabilities: probs,
      quality_metrics: {
        brightness: qualityRisk > 35 ? 38 + Math.random() * 10 : 68 + Math.random() * 12,
        contrast: qualityRisk > 35 ? 42 + Math.random() * 8 : 72 + Math.random() * 10,
        sharpness: qualityRisk > 35 ? 35 + Math.random() * 10 : 78 + Math.random() * 8,
        resolution: '1280×960',
      },
    },
    sensor: {
      available: sensorAvailable,
      signal_class: signalClass,
      confidence: sensorAvailable ? 92 + Math.random() * 7 : 0,
      status: sensorAvailable ? 'OK' : 'UNAVAILABLE',
      readings: sensorAvailable ? DEMO_SENSOR_READINGS : [],
    },
    image_sha256: sha256ish(),
    warnings,
  };
}

export const DEMO_RESULTS: Record<string, AnalysisResult> = {
  positive: makeResult(
    'PRESUMPTIVE POSITIVE',
    'POSITIVE',
    95.76,
    20.64,
    'ACCEPTABLE',
    'Baseline',
    true,
    { POSITIVE: 95.76, NEGATIVE: 0.08, INCONCLUSIVE: 4.14, INVALID: 0.02 },
    'Vision AI classified the image as POSITIVE with 95.76% confidence. The image passed the current prototype quality-risk threshold (20.64% risk, gate: ACCEPTABLE). The auxiliary sensor was available and recorded a BASELINE signal condition with 100% confidence. The sensor signal is treated as supporting evidence and does not override the visual classification. The operational result is therefore PRESUMPTIVE POSITIVE.',
    [],
  ),
  negative: makeResult(
    'PRELIMINARY NEGATIVE',
    'NEGATIVE',
    94.12,
    15.30,
    'ACCEPTABLE',
    'Baseline',
    true,
    { POSITIVE: 2.31, NEGATIVE: 94.12, INCONCLUSIVE: 3.45, INVALID: 0.12 },
    'Vision AI classified the image as NEGATIVE with 94.12% confidence. The image passed the quality-risk threshold (15.30% risk, gate: ACCEPTABLE). The auxiliary sensor was available and recorded a BASELINE signal condition. The sensor signal supports the visual classification. The operational result is PRELIMINARY NEGATIVE. A negative visual screening result does not establish the absence of a substance.',
    [],
  ),
  inconclusive: makeResult(
    'INCONCLUSIVE',
    'INCONCLUSIVE',
    52.40,
    28.70,
    'ACCEPTABLE',
    'Warming',
    true,
    { POSITIVE: 41.20, NEGATIVE: 6.40, INCONCLUSIVE: 52.40, INVALID: 0.00 },
    'Vision AI returned an INCONCLUSIVE classification with 52.40% confidence, which is below the operational confidence threshold. The image quality risk was 28.70% (gate: ACCEPTABLE). The auxiliary sensor recorded a WARMING signal condition. The combined evidence does not meet the operational confidence criteria for a presumptive positive or preliminary negative determination. The operational result is INCONCLUSIVE — additional evidence is required.',
    ['Confidence below operational threshold', 'Sensor signal condition shows warming trend'],
  ),
  invalid: makeResult(
    'INVALID',
    'INVALID',
    89.30,
    12.10,
    'ACCEPTABLE',
    'Baseline',
    true,
    { POSITIVE: 3.50, NEGATIVE: 5.20, INCONCLUSIVE: 2.00, INVALID: 89.30 },
    'Vision AI classified the input as INVALID with 89.30% confidence. The image does not appear to contain a valid field test result suitable for analysis. The image quality was acceptable (12.10% risk), but the content could not be interpreted as a field drug-test result. The operational result is INVALID.',
    ['Image content not recognized as a valid field test result'],
  ),
  poorquality: makeResult(
    'INCONCLUSIVE',
    'POSITIVE',
    87.50,
    58.40,
    'RETAKE RECOMMENDED',
    'Baseline',
    true,
    { POSITIVE: 87.50, NEGATIVE: 4.20, INCONCLUSIVE: 8.10, INVALID: 0.20 },
    'Vision AI classified the image as POSITIVE with 87.50% confidence. However, the image quality risk was 58.40%, exceeding the acceptable threshold (gate: RETAKE RECOMMENDED). Low-quality evidence is prevented from producing an overconfident operational result. The operational result is INCONCLUSIVE due to insufficient image quality. A retake is recommended.',
    ['Image quality below acceptable threshold — retake recommended', 'Quality gate blocked confident result'],
  ),
};

export function demoResultToCase(
  result: AnalysisResult,
  sensorReadings: number[],
): CaseRecord {
  return {
    case_id: genCaseId(),
    timestamp: new Date().toISOString(),
    image_filename: 'demo_image.jpg',
    image_sha256: result.image_sha256,
    final_result: result.final_result,
    raw_prediction: result.vision.raw_class,
    raw_confidence: result.vision.confidence,
    quality_risk: result.vision.quality_risk,
    quality_gate: result.vision.quality_gate,
    quality_metrics: result.vision.quality_metrics,
    sensor_available: result.sensor.available,
    sensor_class: result.sensor.available ? result.sensor.signal_class : null,
    sensor_confidence: result.sensor.available ? result.sensor.confidence : null,
    sensor_readings: sensorReadings,
    evidence_mode: result.evidence_mode,
    probabilities: result.vision.probabilities,
    reason: result.reason,
    warnings: result.warnings,
    audit_status: 'RECORDED',
  };
}

export const SEED_CASES: CaseRecord[] = [
  {
    case_id: 'FG-20260914-A3F291',
    timestamp: '2026-09-14T09:42:17.000Z',
    image_filename: 'field_test_001.jpg',
    image_sha256: 'a3f291c4d8e7b6102f5a3c8e1d9b7f0a4c2e6b8d1f3a5c7e9b0d2f4a6c8e1b3',
    final_result: 'PRESUMPTIVE POSITIVE',
    raw_prediction: 'POSITIVE',
    raw_confidence: 96.32,
    quality_risk: 18.45,
    quality_gate: 'ACCEPTABLE',
    quality_metrics: { brightness: 71, contrast: 74, sharpness: 80, resolution: '1280×960' },
    sensor_available: true,
    sensor_class: 'Baseline',
    sensor_confidence: 98.5,
    sensor_readings: DEMO_SENSOR_READINGS,
    evidence_mode: 'VISION_PLUS_AUXILIARY_SENSOR',
    probabilities: { POSITIVE: 96.32, NEGATIVE: 0.05, INCONCLUSIVE: 3.58, INVALID: 0.05 },
    reason: 'Vision AI classified the image as POSITIVE with 96.32% confidence. Image quality acceptable. Sensor recorded baseline condition. Result: PRESUMPTIVE POSITIVE.',
    warnings: [],
    audit_status: 'RECORDED',
  },
  {
    case_id: 'FG-20260914-B7E104',
    timestamp: '2026-09-14T08:15:33.000Z',
    image_filename: 'field_test_002.jpg',
    image_sha256: 'b7e104f2a8c3d6e9104b7f2a8c5d3e1b9f0a4c2e6b8d1f3a5c7e9b0d2f4a6',
    final_result: 'PRELIMINARY NEGATIVE',
    raw_prediction: 'NEGATIVE',
    raw_confidence: 93.87,
    quality_risk: 14.20,
    quality_gate: 'ACCEPTABLE',
    quality_metrics: { brightness: 75, contrast: 70, sharpness: 82, resolution: '1280×960' },
    sensor_available: true,
    sensor_class: 'Baseline',
    sensor_confidence: 97.2,
    sensor_readings: DEMO_SENSOR_READINGS,
    evidence_mode: 'VISION_PLUS_AUXILIARY_SENSOR',
    probabilities: { POSITIVE: 1.80, NEGATIVE: 93.87, INCONCLUSIVE: 4.20, INVALID: 0.13 },
    reason: 'Vision AI classified the image as NEGATIVE with 93.87% confidence. Image quality acceptable. Sensor recorded baseline condition. Result: PRELIMINARY NEGATIVE.',
    warnings: [],
    audit_status: 'RECORDED',
  },
  {
    case_id: 'FG-20260913-C2D587',
    timestamp: '2026-09-13T16:28:41.000Z',
    image_filename: 'field_test_003.jpg',
    image_sha256: 'c2d587a4b8e1f3c610d9b7f0a4c2e6b8d1f3a5c7e9b0d2f4a6c8e1b3d5e7f9',
    final_result: 'INCONCLUSIVE',
    raw_prediction: 'INCONCLUSIVE',
    raw_confidence: 48.30,
    quality_risk: 31.50,
    quality_gate: 'ACCEPTABLE',
    quality_metrics: { brightness: 58, contrast: 55, sharpness: 62, resolution: '1280×960' },
    sensor_available: true,
    sensor_class: 'Warming',
    sensor_confidence: 88.4,
    sensor_readings: DEMO_SENSOR_WARMING,
    evidence_mode: 'VISION_PLUS_AUXILIARY_SENSOR',
    probabilities: { POSITIVE: 38.40, NEGATIVE: 8.10, INCONCLUSIVE: 48.30, INVALID: 5.20 },
    reason: 'Vision AI returned INCONCLUSIVE with 48.30% confidence, below operational threshold. Sensor shows warming trend. Result: INCONCLUSIVE — additional evidence required.',
    warnings: ['Confidence below operational threshold', 'Sensor signal condition shows warming trend'],
    audit_status: 'RECORDED',
  },
  {
    case_id: 'FG-20260913-D9A422',
    timestamp: '2026-09-13T11:05:09.000Z',
    image_filename: 'field_test_004.jpg',
    image_sha256: 'd9a422e1b5c3f7a910d4b8f2a6c0e3d5b7f1a4c8e2d6b0f3a5c7e9b1d4f8a2',
    final_result: 'INVALID',
    raw_prediction: 'INVALID',
    raw_confidence: 91.20,
    quality_risk: 10.80,
    quality_gate: 'ACCEPTABLE',
    quality_metrics: { brightness: 72, contrast: 68, sharpness: 75, resolution: '1280×960' },
    sensor_available: true,
    sensor_class: 'Baseline',
    sensor_confidence: 96.8,
    sensor_readings: DEMO_SENSOR_READINGS,
    evidence_mode: 'VISION_PLUS_AUXILIARY_SENSOR',
    probabilities: { POSITIVE: 2.80, NEGATIVE: 4.10, INCONCLUSIVE: 1.90, INVALID: 91.20 },
    reason: 'Vision AI classified input as INVALID with 91.20% confidence. Image does not contain a valid field test result. Result: INVALID.',
    warnings: ['Image content not recognized as a valid field test result'],
    audit_status: 'RECORDED',
  },
  {
    case_id: 'FG-20260912-E5B873',
    timestamp: '2026-09-12T14:33:52.000Z',
    image_filename: 'field_test_005.jpg',
    image_sha256: 'e5b873f1a4c8e2d6b0f3a5c7e9b1d4f8a2c6e0b4d8f2a6c0e3d5b7f1a4c8e2',
    final_result: 'PRESUMPTIVE POSITIVE',
    raw_prediction: 'POSITIVE',
    raw_confidence: 92.15,
    quality_risk: 22.30,
    quality_gate: 'ACCEPTABLE',
    quality_metrics: { brightness: 65, contrast: 69, sharpness: 74, resolution: '1280×960' },
    sensor_available: false,
    sensor_class: null,
    sensor_confidence: null,
    sensor_readings: [],
    evidence_mode: 'VISION_ONLY',
    probabilities: { POSITIVE: 92.15, NEGATIVE: 1.20, INCONCLUSIVE: 6.50, INVALID: 0.15 },
    reason: 'Vision AI classified the image as POSITIVE with 92.15% confidence. Image quality acceptable. No auxiliary sensor data available. Evidence mode: VISION_ONLY. Result: PRESUMPTIVE POSITIVE.',
    warnings: ['Auxiliary sensor unavailable — vision-only evidence mode'],
    audit_status: 'RECORDED',
  },
  {
    case_id: 'FG-20260912-F1C906',
    timestamp: '2026-09-12T09:18:27.000Z',
    image_filename: 'field_test_006.jpg',
    image_sha256: 'f1c906a3b7e1d4c8f2a6b0e3d5b7f1a4c8e2d6b0f3a5c7e9b1d4f8a2c6e0b4',
    final_result: 'PRELIMINARY NEGATIVE',
    raw_prediction: 'NEGATIVE',
    raw_confidence: 95.60,
    quality_risk: 11.90,
    quality_gate: 'ACCEPTABLE',
    quality_metrics: { brightness: 78, contrast: 73, sharpness: 85, resolution: '1280×960' },
    sensor_available: true,
    sensor_class: 'Cooling',
    sensor_confidence: 94.1,
    sensor_readings: DEMO_SENSOR_COOLING,
    evidence_mode: 'VISION_PLUS_AUXILIARY_SENSOR',
    probabilities: { POSITIVE: 1.50, NEGATIVE: 95.60, INCONCLUSIVE: 2.80, INVALID: 0.10 },
    reason: 'Vision AI classified the image as NEGATIVE with 95.60% confidence. Image quality acceptable. Sensor recorded cooling condition. Result: PRELIMINARY NEGATIVE.',
    warnings: [],
    audit_status: 'RECORDED',
  },
];

