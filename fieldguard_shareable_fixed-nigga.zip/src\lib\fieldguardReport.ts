import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { AnalysisResult } from '@/types';

type ReportOptions = {
  result: AnalysisResult;
  imageBlob?: Blob | null;
  imageFilename?: string;
};

type AnyResult = AnalysisResult & {
  api_version?: string;
  operator_id?: string | null;
  sensor_sample_id?: string | number | null;
  timestamp?: string | null;
  image_filename?: string | null;
  audit_status?: string | null;
};

function safe(value: unknown, fallback = '—'): string {
  if (
    value === undefined ||
    value === null ||
    value === ''
  ) {
    return fallback;
  }

  return String(value);
}

function percent(value: unknown): string {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return '—';
  }

  return `${number.toFixed(2)}%`;
}

function formatConfidence(value: unknown): string {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return '—';
  }

  return `${(number * 100).toFixed(2)}%`;
}

function formatTimestamp(timestamp?: string): string {
  if (!timestamp) {
    return new Date().toLocaleString();
  }

  const date = new Date(timestamp);

  if (Number.isNaN(date.getTime())) {
    return timestamp;
  }

  return date.toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'medium',
  });
}

function getDecisionColor(
  result: string
): [number, number, number] {
  const normalized = result.toUpperCase();

  if (normalized.includes('PRESUMPTIVE POSITIVE')) {
    return [176, 48, 48];
  }

  if (normalized.includes('PRELIMINARY NEGATIVE')) {
    return [32, 120, 78];
  }

  if (normalized.includes('INCONCLUSIVE')) {
    return [180, 120, 25];
  }

  return [90, 96, 105];
}

async function blobToDataUrl(
  blob: Blob
): Promise<string> {

  return new Promise((resolve, reject) => {

    const reader = new FileReader();

    reader.onload = () => {
      resolve(String(reader.result));
    };

    reader.onerror = () => {
      reject(
        new Error('Could not read image for report.')
      );
    };

    reader.readAsDataURL(blob);
  });
}

function addPageFooter(
  doc: jsPDF,
  pageNumber: number,
  totalPages: number
) {
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  doc.setDrawColor(220, 224, 230);
  doc.line(
    18,
    pageHeight - 17,
    pageWidth - 18,
    pageHeight - 17
  );

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(110, 118, 128);

  doc.text(
    'NARCOVEX • AI-ASSISTED FIELD SCREENING',
    18,
    pageHeight - 9
  );

  doc.text(
    `Page ${pageNumber} of ${totalPages}`,
    pageWidth - 18,
    pageHeight - 9,
    {
      align: 'right',
    }
  );
}

function addSectionTitle(
  doc: jsPDF,
  title: string,
  y: number
): number {

  const pageWidth =
    doc.internal.pageSize.getWidth();

  doc.setFillColor(
    245,
    247,
    250
  );

  doc.roundedRect(
    18,
    y,
    pageWidth - 36,
    9,
    2,
    2,
    'F'
  );

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(10);

  doc.setTextColor(
    35,
    43,
    54
  );

  doc.text(
    title.toUpperCase(),
    23,
    y + 6.2
  );

  return y + 15;
}

export async function downloadNarcovexReport(
  options: ReportOptions
): Promise<void> {

  const result =
    options.result as AnyResult;

  const doc =
    new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

  const pageWidth =
    doc.internal.pageSize.getWidth();

  const pageHeight =
    doc.internal.pageSize.getHeight();

  const margin = 18;

  // ==========================================================
  // DATA
  // ==========================================================

  const finalResult =
    safe(
      result.final_result
    );

  const decisionColor =
    getDecisionColor(
      finalResult
    );

  const vision =
    result.vision ?? ({} as AnyResult['vision']);

  const sensor =
    result.sensor ?? ({} as AnyResult['sensor']);

  const quality =
    vision.quality_metrics ?? {
      brightness: 0,
      contrast: 0,
      sharpness: 0,
      resolution: '—',
    };

  // ==========================================================
  // HEADER
  // ==========================================================

  doc.setFillColor(
    19,
    31,
    48
  );

  doc.rect(
    0,
    0,
    pageWidth,
    38,
    'F'
  );

  doc.setTextColor(
    255,
    255,
    255
  );

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(19);

  doc.text(
    'NARCOVEX',
    margin,
    16
  );

  doc.setFont(
    'helvetica',
    'normal'
  );

  doc.setFontSize(8.5);

  doc.text(
    'AI-ASSISTED FIELD SCREENING REPORT',
    margin,
    23
  );

  doc.setFontSize(7.5);

  doc.text(
    'Decision-support prototype • Traceable analysis record',
    margin,
    29
  );

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(7);

  doc.text(
    'CONFIDENTIAL / OPERATIONAL RECORD',
    pageWidth - margin,
    16,
    {
      align: 'right',
    }
  );

  // ==========================================================
  // CASE IDENTIFICATION
  // ==========================================================

  let y = 48;

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(11);

  doc.setTextColor(
    30,
    39,
    50
  );

  doc.text(
    'Case Information',
    margin,
    y
  );

  y += 5;

  autoTable(doc, {
    startY: y,
    margin: {
      left: margin,
      right: margin,
    },

    theme: 'grid',

    styles: {
      font: 'helvetica',
      fontSize: 8.5,
      cellPadding: 3.2,
      textColor: [40, 47, 56],
      lineColor: [220, 224, 230],
      lineWidth: 0.2,
    },

    headStyles: {
      fillColor: [241, 244, 248],
      textColor: [45, 53, 63],
      fontStyle: 'bold',
    },

    columnStyles: {
      0: {
        cellWidth: 34,
        fontStyle: 'bold',
      },
      1: {
        cellWidth: 58,
      },
      2: {
        cellWidth: 34,
        fontStyle: 'bold',
      },
      3: {
        cellWidth: 'auto',
      },
    },

    body: [
      [
        'Case ID',
        safe(result.case_id ?? '—'),
        'Timestamp',
        formatTimestamp(
          result.timestamp ?? undefined
        ),
      ],
      [
        'Image',
        safe(
          options.imageFilename ??
          result.image_filename
        ),
        'Operator',
        safe(
          result.operator_id
        ),
      ],
      [
        'Sensor Sample',
        safe(
          result.sensor_sample_id
        ),
        'Audit Status',
        safe(
          result.audit_status
        ),
      ],
    ],
  });

  y =
    (doc as any).lastAutoTable.finalY + 10;

  // ==========================================================
  // FINAL DECISION
  // ==========================================================

  y = addSectionTitle(
    doc,
    'Final Screening Decision',
    y
  );

  doc.setFillColor(
    decisionColor[0],
    decisionColor[1],
    decisionColor[2]
  );

  doc.roundedRect(
    margin,
    y,
    pageWidth - margin * 2,
    24,
    3,
    3,
    'F'
  );

  doc.setTextColor(
    255,
    255,
    255
  );

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(16);

  doc.text(
    finalResult.toUpperCase(),
    pageWidth / 2,
    y + 11,
    {
      align: 'center',
    }
  );

  doc.setFont(
    'helvetica',
    'normal'
  );

  doc.setFontSize(7.5);

  const evidenceLabel =
    safe(
      result.evidence_mode
    );

  doc.text(
    evidenceLabel,
    pageWidth / 2,
    y + 18,
    {
      align: 'center',
    }
  );

  y += 32;

  // ==========================================================
  // INTERPRETATION
  // ==========================================================

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(9);

  doc.setTextColor(
    40,
    48,
    58
  );

  doc.text(
    'Interpretation',
    margin,
    y
  );

  y += 5;

  doc.setFont(
    'helvetica',
    'normal'
  );

  doc.setFontSize(8.5);

  const reasonText =
    safe(
      result.reason,
      'No additional interpretation was returned.'
    );

  const reasonLines =
    doc.splitTextToSize(
      reasonText,
      pageWidth - margin * 2
    );

  doc.text(
    reasonLines,
    margin,
    y
  );

  y +=
    reasonLines.length * 4.2 + 8;

  // ==========================================================
  // VISION AI
  // ==========================================================

  y = addSectionTitle(
    doc,
    'Vision Analysis',
    y
  );

  autoTable(doc, {
    startY: y,
    margin: {
      left: margin,
      right: margin,
    },

    theme: 'grid',

    styles: {
      font: 'helvetica',
      fontSize: 8.5,
      cellPadding: 3,
      textColor: [40, 47, 56],
      lineColor: [220, 224, 230],
      lineWidth: 0.2,
    },

    body: [
      [
        'Raw AI Prediction',
        safe(
          vision.raw_class
        ),
      ],
      [
        'Vision Confidence',
        formatConfidence(
          vision.confidence
        ),
      ],
      [
        'Quality Risk',
        percent(
          Number(
            vision.quality_risk
          ) * 100
        ),
      ],
      [
        'Quality Gate',
        safe(
          vision.quality_gate
        ),
      ],
      [
        'Evidence Mode',
        safe(
          result.evidence_mode
        ),
      ],
    ],

    columnStyles: {
      0: {
        cellWidth: 55,
        fontStyle: 'bold',
        fillColor: [247, 248, 250],
      },
    },
  });

  y =
    (doc as any).lastAutoTable.finalY + 8;

  // ==========================================================
  // VISION PROBABILITIES
  // ==========================================================

  const probabilities =
    vision.probabilities ?? {};

  const probabilityRows =
    Object.entries(
      probabilities
    ).map(
      ([label, value]) => [
        label.toUpperCase(),
        formatConfidence(value),
      ]
    );

  if (probabilityRows.length > 0) {

    y = addSectionTitle(
      doc,
      'Vision Class Probabilities',
      y
    );

    autoTable(doc, {
      startY: y,
      margin: {
        left: margin,
        right: margin,
      },

      theme: 'grid',

      head: [
        [
          'Class',
          'Model Confidence',
        ],
      ],

      body:
        probabilityRows,

      styles: {
        font: 'helvetica',
        fontSize: 8.2,
        cellPadding: 3,
        lineColor: [220, 224, 230],
        lineWidth: 0.2,
      },

      headStyles: {
        fillColor: [
          34,
          48,
          65,
        ],
        textColor: [
          255,
          255,
          255,
        ],
      },

      columnStyles: {
        0: {
          fontStyle: 'bold',
        },
      },
    });

    y =
      (doc as any).lastAutoTable.finalY + 8;
  }

  // ==========================================================
  // IMAGE QUALITY
  // ==========================================================

  y = addSectionTitle(
    doc,
    'Image Quality Assessment',
    y
  );

  autoTable(doc, {
    startY: y,
    margin: {
      left: margin,
      right: margin,
    },

    theme: 'grid',

    head: [
      [
        'Metric',
        'Value',
      ],
    ],

    body: [
      [
        'Brightness',
        `${safe(
          quality.brightness
        )}%`,
      ],
      [
        'Contrast',
        `${safe(
          quality.contrast
        )}%`,
      ],
      [
        'Sharpness',
        `${safe(
          quality.sharpness
        )}%`,
      ],
      [
        'Resolution',
        safe(
          quality.resolution
        ),
      ],
    ],

    styles: {
      font: 'helvetica',
      fontSize: 8.5,
      cellPadding: 3,
      lineColor: [220, 224, 230],
      lineWidth: 0.2,
    },

    headStyles: {
      fillColor: [
        34,
        48,
        65,
      ],
      textColor: [
        255,
        255,
        255,
      ],
    },

    columnStyles: {
      0: {
        fontStyle: 'bold',
        cellWidth: 60,
      },
    },
  });

  y =
    (doc as any).lastAutoTable.finalY + 8;

  // ==========================================================
  // SENSOR
  // ==========================================================

  y = addSectionTitle(
    doc,
    'Auxiliary Sensor Analysis',
    y
  );

  const sensorAvailable =
    sensor.available === true;

  const sensorRows = [
    [
      'Sensor Available',
      sensorAvailable
        ? 'YES'
        : 'NO',
    ],
    [
      'Signal Class',
      sensorAvailable
        ? safe(sensor.signal_class)
        : 'Unavailable',
    ],
    [
      'Sensor Confidence',
      sensorAvailable
        ? formatConfidence(
            sensor.confidence
          )
        : '—',
    ],
    [
      'Sample ID',
      safe(
        result.sensor_sample_id
      ),
    ],
  ];

  autoTable(doc, {
    startY: y,
    margin: {
      left: margin,
      right: margin,
    },

    theme: 'grid',

    body: sensorRows,

    styles: {
      font: 'helvetica',
      fontSize: 8.5,
      cellPadding: 3,
      textColor: [40, 47, 56],
      lineColor: [220, 224, 230],
      lineWidth: 0.2,
    },

    columnStyles: {
      0: {
        cellWidth: 55,
        fontStyle: 'bold',
        fillColor: [247, 248, 250],
      },
    },
  });

  y =
    (doc as any).lastAutoTable.finalY + 7;

  // ==========================================================
  // SENSOR SUMMARY
  // ==========================================================

  const readings =
    Array.isArray(
      sensor.readings
    )
      ? sensor.readings
          .map(Number)
          .filter(
            Number.isFinite
          )
      : [];

  if (readings.length > 0) {

    const minimum =
      Math.min(
        ...readings
      );

    const maximum =
      Math.max(
        ...readings
      );

    const average =
      readings.reduce(
        (sum, value) =>
          sum + value,
        0
      ) /
      readings.length;

    autoTable(doc, {
      startY: y,
      margin: {
        left: margin,
        right: margin,
      },

      theme: 'grid',

      head: [
        [
          'Readings',
          'Minimum',
          'Maximum',
          'Average',
        ],
      ],

      body: [
        [
          readings.length,
          minimum.toFixed(3),
          maximum.toFixed(3),
          average.toFixed(3),
        ],
      ],

      styles: {
        font: 'helvetica',
        fontSize: 8,
        cellPadding: 3,
        lineColor: [
          220,
          224,
          230,
        ],
        lineWidth: 0.2,
      },

      headStyles: {
        fillColor: [
          34,
          48,
          65,
        ],
        textColor: [
          255,
          255,
          255,
        ],
      },
    });

    y =
      (doc as any).lastAutoTable.finalY + 8;
  }

  // ==========================================================
  // INPUT IMAGE
  // ==========================================================

  if (options.imageBlob) {

    const imageData =
      await blobToDataUrl(
        options.imageBlob
      );

    if (y > pageHeight - 105) {
      doc.addPage();
      y = 22;
    }

    y = addSectionTitle(
      doc,
      'Submitted Test Image',
      y
    );

    try {

      const imageProperties =
        doc.getImageProperties(
          imageData
        );

      const maxWidth =
        pageWidth - margin * 2;

      const maxHeight = 78;

      let imageWidth =
        maxWidth;

      let imageHeight =
        (
          imageProperties.height /
          imageProperties.width
        ) * imageWidth;

      if (
        imageHeight >
        maxHeight
      ) {

        imageHeight =
          maxHeight;

        imageWidth =
          (
            imageProperties.width /
            imageProperties.height
          ) * imageHeight;
      }

      doc.addImage(
        imageData,
        imageProperties.fileType === 'PNG'
          ? 'PNG'
          : 'JPEG',
        (
          pageWidth -
          imageWidth
        ) / 2,
        y,
        imageWidth,
        imageHeight
      );

      y +=
        imageHeight + 8;

    } catch {
      // Image is optional.
    }
  }

  // ==========================================================
  // TRACEABILITY
  // ==========================================================

  if (
    y > pageHeight - 90
  ) {
    doc.addPage();
    y = 22;
  }

  y = addSectionTitle(
    doc,
    'Traceability & Audit',
    y
  );

  const imageHash =
    safe(
      result.image_sha256
    );

  autoTable(doc, {
    startY: y,
    margin: {
      left: margin,
      right: margin,
    },

    theme: 'grid',

    body: [
      [
        'Image SHA-256',
        imageHash,
      ],
      [
        'Vision Model',
        'fieldguard_v2.pt',
      ],
      [
        'Quality Gate Model',
        'fieldguard_quality_risk_gate.joblib',
      ],
      [
        'Sensor Model',
        'sensor_ai_v2_best.joblib',
      ],
      [
        'Evidence Mode',
        safe(
          result.evidence_mode
        ),
      ],
      [
        'Audit Status',
        safe(
          result.audit_status
        ),
      ],
      [
        'API Version',
        safe(
          result.api_version
        ),
      ],
    ],

    styles: {
      font: 'helvetica',
      fontSize: 7.5,
      cellPadding: 3,
      textColor: [40, 47, 56],
      lineColor: [220, 224, 230],
      lineWidth: 0.2,
    },

    columnStyles: {
      0: {
        cellWidth: 55,
        fontStyle: 'bold',
        fillColor: [
          247,
          248,
          250,
        ],
      },

      1: {
        fontSize: 7,
      },
    },
  });

  y =
    (doc as any).lastAutoTable.finalY + 9;

  // ==========================================================
  // WARNINGS
  // ==========================================================

  const warnings =
    Array.isArray(
      result.warnings
    )
      ? result.warnings
      : [];

  if (
    warnings.length > 0
  ) {

    if (
      y > pageHeight - 65
    ) {
      doc.addPage();
      y = 22;
    }

    y = addSectionTitle(
      doc,
      'Warnings',
      y
    );

    const warningRows =
      warnings.map(
        (warning) => [
          '•',
          safe(warning),
        ]
      );

    autoTable(doc, {
      startY: y,
      margin: {
        left: margin,
        right: margin,
      },

      theme: 'plain',

      body:
        warningRows,

      styles: {
        font: 'helvetica',
        fontSize: 8,
        cellPadding: 2.5,
        textColor: [
          85,
          67,
          25,
        ],
      },

      columnStyles: {
        0: {
          cellWidth: 8,
          fontStyle: 'bold',
        },
      },
    });

    y =
      (doc as any).lastAutoTable.finalY + 8;
  }

  // ==========================================================
  // PROTOTYPE NOTICE
  // ==========================================================

  if (
    y > pageHeight - 55
  ) {
    doc.addPage();
    y = 22;
  }

  doc.setFillColor(
    255,
    248,
    225
  );

  const noticeText =
    'NARCOVEX PROTOTYPE NOTICE: This report documents an AI-assisted field-screening prototype. A PRESUMPTIVE POSITIVE is not chemical or forensic confirmation, and a PRELIMINARY NEGATIVE does not establish absence. Sensor labels (baseline, warming, cooling) are prototype signal-condition labels and are not drug-result labels. Results should be interpreted within the validated operational procedure and applicable forensic requirements.';

  const noticeLines =
    doc.splitTextToSize(
      noticeText,
      pageWidth - margin * 2 - 12
    );

  const noticeHeight =
    noticeLines.length * 3.8 + 12;

  doc.roundedRect(
    margin,
    y,
    pageWidth - margin * 2,
    noticeHeight,
    2,
    2,
    'F'
  );

  doc.setFont(
    'helvetica',
    'bold'
  );

  doc.setFontSize(7.5);

  doc.setTextColor(
    97,
    73,
    20
  );

  doc.text(
    'IMPORTANT',
    margin + 5,
    y + 6
  );

  doc.setFont(
    'helvetica',
    'normal'
  );

  doc.setFontSize(7);

  doc.text(
    noticeLines,
    margin + 5,
    y + 11
  );

  // ==========================================================
  // FOOTERS
  // ==========================================================

  const totalPages =
    doc.getNumberOfPages();

  for (
    let page = 1;
    page <= totalPages;
    page++
  ) {

    doc.setPage(page);

    addPageFooter(
      doc,
      page,
      totalPages
    );
  }

  // ==========================================================
  // DOWNLOAD
  // ==========================================================

  const caseId =
    safe(
      result.case_id,
      `FG-${Date.now()}`
    )
      .replace(
        /[^a-zA-Z0-9_-]/g,
        '_'
      );

  doc.save(
    `Narcovex_Report_${caseId}.pdf`
  );
}
