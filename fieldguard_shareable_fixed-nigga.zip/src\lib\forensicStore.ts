import { useState, useEffect, useCallback } from 'react';
import type {
  User,
  UserRole,
  ForensicCase,
  EvidenceItem,
  EvidenceVersion,
  TestKit,
  CustodyEvent,
  AuditEvent,
  VerificationRecord,
  VerificationStage,
  VerificationDecision,
  SyncQueueItem,
  SyncStatus,
  CaseRecord,
  KitStatus,
} from '@/types';
import {
  SEED_USERS,
  SEED_KITS,
  SEED_CASES,
  SEED_EVIDENCE,
  SEED_CUSTODY_EVENTS,
  SEED_AUDIT_EVENTS,
  SEED_VERIFICATIONS,
} from './forensicSeed';
import { generateEvidenceHash, verifyEvidenceIntegrity } from './crypto';

const STORAGE_KEY_CASES = 'fg_cases_v2';
const STORAGE_KEY_EVIDENCE = 'fg_evidence_v2';
const STORAGE_KEY_KITS = 'fg_kits_v2';
const STORAGE_KEY_CUSTODY = 'fg_custody_v2';
const STORAGE_KEY_AUDIT = 'fg_audit_v2';
const STORAGE_KEY_USER = 'fg_active_user_v2';
const STORAGE_KEY_SYNC = 'fg_sync_queue_v2';
const STORAGE_KEY_VERIFICATIONS = 'fg_verifications_v2';

function loadStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function saveStored<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.warn('Storage save failed:', err);
  }
}

class ForensicRepository {
  private users: User[] = SEED_USERS;
  private currentUser: User = SEED_USERS[0]; // Field Officer Marcus Vance by default
  private cases: ForensicCase[] = [];
  private evidence: EvidenceItem[] = [];
  private kits: TestKit[] = [];
  private custodyEvents: CustodyEvent[] = [];
  private auditEvents: AuditEvent[] = [];
  private verifications: VerificationRecord[] = [];
  private syncQueue: SyncQueueItem[] = [];
  private syncStatus: SyncStatus = 'ONLINE';
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.init();
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange(true));
      window.addEventListener('offline', () => this.handleNetworkChange(false));
    }
  }

  private init() {
    this.cases = loadStored(STORAGE_KEY_CASES, SEED_CASES);
    this.evidence = loadStored(STORAGE_KEY_EVIDENCE, SEED_EVIDENCE);
    this.kits = loadStored(STORAGE_KEY_KITS, SEED_KITS);
    this.custodyEvents = loadStored(STORAGE_KEY_CUSTODY, SEED_CUSTODY_EVENTS);
    this.auditEvents = loadStored(STORAGE_KEY_AUDIT, SEED_AUDIT_EVENTS);
    this.verifications = loadStored(STORAGE_KEY_VERIFICATIONS, SEED_VERIFICATIONS);
    this.syncQueue = loadStored(STORAGE_KEY_SYNC, []);
    
    const savedUser = loadStored<User | null>(STORAGE_KEY_USER, null);
    if (savedUser) {
      this.currentUser = savedUser;
    }
  }

  private notify() {
    this.listeners.forEach((cb) => cb());
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private handleNetworkChange(isOnline: boolean) {
    this.syncStatus = isOnline ? 'ONLINE' : 'OFFLINE';
    if (isOnline && this.syncQueue.length > 0) {
      this.processSyncQueue();
    }
    this.notify();
  }

  // ========================================================
  // USER & ROLE MANAGEMENT
  // ========================================================

  public getCurrentUser(): User {
    return this.currentUser;
  }

  public getUsers(): User[] {
    return this.users;
  }

  public setCurrentUser(user: User) {
    const prev = this.currentUser;
    this.currentUser = user;
    saveStored(STORAGE_KEY_USER, user);
    this.recordAudit({
      action: 'ROLE_CHANGED',
      entity_type: 'USER',
      entity_id: user.user_id,
      previous_value: `${prev.full_name} (${prev.role})`,
      new_value: `${user.full_name} (${user.role})`,
    });
    this.notify();
  }

  public switchRole(role: UserRole) {
    const target = this.users.find((u) => u.role === role);
    if (target) {
      this.setCurrentUser(target);
    }
  }

  // ========================================================
  // AUDIT TRAIL (APPEND-ONLY)
  // ========================================================

  public recordAudit(params: {
    action: AuditEvent['action'];
    entity_type: AuditEvent['entity_type'];
    entity_id: string;
    previous_value?: string | null;
    new_value?: string | null;
    hash_reference?: string;
  }): AuditEvent {
    const event: AuditEvent = {
      event_id: `AUD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      user_id: this.currentUser.user_id,
      user_role: this.currentUser.role,
      action: params.action,
      entity_type: params.entity_type,
      entity_id: params.entity_id,
      timestamp: new Date().toISOString(),
      ip_address: '10.24.180.12',
      device_id: 'FG-OFFICER-MOBILE-04',
      previous_value: params.previous_value ?? null,
      new_value: params.new_value ?? null,
      hash_reference: params.hash_reference,
    };

    // Audit trail is append-only
    this.auditEvents = [event, ...this.auditEvents];
    saveStored(STORAGE_KEY_AUDIT, this.auditEvents);
    this.notify();
    return event;
  }

  public getAuditEvents(): AuditEvent[] {
    return this.auditEvents;
  }

  // ========================================================
  // CASE MANAGEMENT
  // ========================================================

  public getCases(): ForensicCase[] {
    return this.cases;
  }

  public getCaseById(caseId: string): ForensicCase | undefined {
    return this.cases.find((c) => c.case_id === caseId);
  }

  public createCase(data: {
    title?: string;
    case_type: string;
    description: string;
    priority: ForensicCase['priority'];
    location_name: string;
    gps_lat?: number;
    gps_lng?: number;
    assigned_officer?: string;
    supervisor?: string;
  }): ForensicCase {
    const year = new Date().getFullYear();
    const count = this.cases.length + 184;
    const caseId = `FG-${year}-${count.toString().padStart(6, '0')}`;
    const caseNumber = `CASE-${year}-${count.toString().padStart(4, '0')}`;

    const newCase: ForensicCase = {
      case_id: caseId,
      case_number: caseNumber,
      case_type: data.case_type,
      description: data.description,
      priority: data.priority,
      status: 'ACTIVE',
      created_by: `${this.currentUser.full_name} (${this.currentUser.badge_number})`,
      assigned_officer: data.assigned_officer || this.currentUser.full_name,
      supervisor: data.supervisor || 'Lt. Raymond Miller',
      location_name: data.location_name,
      gps_coordinates: {
        lat: data.gps_lat ?? 34.0522,
        lng: data.gps_lng ?? -118.2437,
      },
      evidence_count: 0,
      test_count: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    this.cases = [newCase, ...this.cases];
    saveStored(STORAGE_KEY_CASES, this.cases);

    this.recordAudit({
      action: 'CASE_CREATED',
      entity_type: 'CASE',
      entity_id: caseId,
      new_value: `Created case ${caseId} (${data.case_type})`,
    });

    this.notify();
    return newCase;
  }

  public updateCase(caseId: string, updates: Partial<ForensicCase>): ForensicCase {
    const existing = this.cases.find((c) => c.case_id === caseId);
    if (!existing) throw new Error(`Case ${caseId} not found`);

    const prevStatus = existing.status;
    const updated: ForensicCase = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString(),
    };

    this.cases = this.cases.map((c) => (c.case_id === caseId ? updated : c));
    saveStored(STORAGE_KEY_CASES, this.cases);

    this.recordAudit({
      action: 'CASE_UPDATED',
      entity_type: 'CASE',
      entity_id: caseId,
      previous_value: `Status: ${prevStatus}`,
      new_value: `Status: ${updated.status}`,
    });

    this.notify();
    return updated;
  }

  // ========================================================
  // EVIDENCE MANAGEMENT & CRYPTOGRAPHIC INTEGRITY
  // ========================================================

  public getEvidence(): EvidenceItem[] {
    return this.evidence;
  }

  public getEvidenceById(evidenceId: string): EvidenceItem | undefined {
    return this.evidence.find((e) => e.evidence_id === evidenceId);
  }

  public getEvidenceByCase(caseId: string): EvidenceItem[] {
    return this.evidence.filter((e) => e.case_id === caseId);
  }

  public async registerEvidence(data: {
    case_id: string;
    sample_id: string;
    evidence_type: string;
    description: string;
    collection_location: string;
    gps_lat?: number;
    gps_lng?: number;
    device_id?: string;
    test_kit_id?: string;
    kit_batch_number?: string;
    kit_expiry_date?: string;
    photo_url?: string;
  }): Promise<EvidenceItem> {
    const caseItems = this.evidence.filter((e) => e.case_id === data.case_id);
    const itemNum = (caseItems.length + 1).toString().padStart(2, '0');
    // Format: EV-FG26-000184-01
    const cleanCaseTag = data.case_id.replace('FG-', 'FG').replace('-000', '').replace('-00', '');
    const evidenceId = `EV-${cleanCaseTag}-${itemNum}`;

    const timestamp = new Date().toISOString();

    const partialItem: Partial<EvidenceItem> = {
      evidence_id: evidenceId,
      case_id: data.case_id,
      sample_id: data.sample_id,
      evidence_type: data.evidence_type,
      description: data.description,
      collected_by: `${this.currentUser.full_name} (${this.currentUser.badge_number})`,
      collection_timestamp: timestamp,
      collection_location: data.collection_location,
      gps_coordinates: {
        lat: data.gps_lat ?? 34.0522,
        lng: data.gps_lng ?? -118.2437,
      },
      device_id: data.device_id || 'FG-CAM-MOBILE-04',
      test_kit_id: data.test_kit_id,
      kit_batch_number: data.kit_batch_number,
      kit_expiry_date: data.kit_expiry_date,
      current_version: 1,
    };

    // Calculate cryptographic SHA-256 hash of immutable metadata
    const hash = await generateEvidenceHash(partialItem);

    const initialVersion: EvidenceVersion = {
      version_number: 1,
      timestamp,
      modified_by: this.currentUser.full_name,
      reason: 'Initial forensic evidence registration & SHA-256 cryptographic sealing',
      metadata_snapshot: { ...partialItem },
      sha256_hash: hash,
    };

    const newEvidence: EvidenceItem = {
      ...partialItem,
      status: 'COLLECTED',
      sha256_hash: hash,
      hash_algorithm: 'SHA-256',
      photo_url: data.photo_url,
      versions: [initialVersion],
      created_at: timestamp,
      updated_at: timestamp,
    } as EvidenceItem;

    this.evidence = [newEvidence, ...this.evidence];
    saveStored(STORAGE_KEY_EVIDENCE, this.evidence);

    // Update evidence count on case
    const targetCase = this.cases.find((c) => c.case_id === data.case_id);
    if (targetCase) {
      this.updateCase(data.case_id, {
        evidence_count: (targetCase.evidence_count || 0) + 1,
      });
    }

    // Append custody event
    this.recordCustodyEvent({
      evidence_id: evidenceId,
      case_id: data.case_id,
      from_user: this.currentUser.full_name,
      to_user: this.currentUser.full_name,
      from_location: data.collection_location,
      to_location: 'Mobile Forensic Unit',
      action: 'COLLECTED',
      reason: 'Physical specimen recovery and packaging',
    });

    // Record audit event
    this.recordAudit({
      action: 'EVIDENCE_REGISTERED',
      entity_type: 'EVIDENCE',
      entity_id: evidenceId,
      new_value: `Registered ${evidenceId} with SHA-256 ${hash.substring(0, 16)}...`,
      hash_reference: hash,
    });

    this.notify();
    return newEvidence;
  }

  /**
   * Versioning logic: Users cannot overwrite original evidence.
   * Modifying metadata generates a new Version (v1, v2, v3...)
   */
  public async createEvidenceVersion(
    evidenceId: string,
    updates: Partial<EvidenceItem>,
    reasonForChange: string,
  ): Promise<EvidenceItem> {
    const existing = this.evidence.find((e) => e.evidence_id === evidenceId);
    if (!existing) throw new Error(`Evidence ${evidenceId} not found`);

    const nextVersionNum = (existing.current_version || 1) + 1;
    const timestamp = new Date().toISOString();

    const merged = {
      ...existing,
      ...updates,
      current_version: nextVersionNum,
    };

    const newHash = await generateEvidenceHash(merged);

    const versionRecord: EvidenceVersion = {
      version_number: nextVersionNum,
      timestamp,
      modified_by: this.currentUser.full_name,
      reason: reasonForChange,
      metadata_snapshot: { ...updates },
      sha256_hash: newHash,
    };

    const updatedItem: EvidenceItem = {
      ...merged,
      sha256_hash: newHash,
      versions: [...existing.versions, versionRecord],
      updated_at: timestamp,
    };

    this.evidence = this.evidence.map((e) => (e.evidence_id === evidenceId ? updatedItem : e));
    saveStored(STORAGE_KEY_EVIDENCE, this.evidence);

    this.recordAudit({
      action: 'CASE_UPDATED',
      entity_type: 'EVIDENCE',
      entity_id: evidenceId,
      previous_value: `Version ${existing.current_version} (${existing.sha256_hash.substring(0, 12)}...)`,
      new_value: `Version ${nextVersionNum} (${newHash.substring(0, 12)}...) - Reason: ${reasonForChange}`,
      hash_reference: newHash,
    });

    this.notify();
    return updatedItem;
  }

  // ========================================================
  // TAMPER DEMO CAPABILITY (THE "WOW MOMENT")
  // ========================================================

  /**
   * Simulates an illicit modification in a field without updating the cryptographic hash,
   * immediately proving cryptographic tamper detection.
   */
  public simulateEvidenceTamper(evidenceId: string, field: keyof EvidenceItem, tamperedValue: unknown): EvidenceItem {
    const item = this.evidence.find((e) => e.evidence_id === evidenceId);
    if (!item) throw new Error('Evidence not found');

    const originalValue = item[field];
    const tampered: EvidenceItem = {
      ...item,
      [field]: tamperedValue,
      is_tampered: true,
      tampered_field: String(field),
      tampered_value: tamperedValue,
      original_value: originalValue,
    };

    this.evidence = this.evidence.map((e) => (e.evidence_id === evidenceId ? tampered : e));
    saveStored(STORAGE_KEY_EVIDENCE, this.evidence);

    this.recordAudit({
      action: 'EVIDENCE_TAMPER_SIMULATED',
      entity_type: 'EVIDENCE',
      entity_id: evidenceId,
      previous_value: `${String(field)} = ${JSON.stringify(originalValue)}`,
      new_value: `TAMPERED ${String(field)} = ${JSON.stringify(tamperedValue)}`,
      hash_reference: item.sha256_hash,
    });

    this.notify();
    return tampered;
  }

  /**
   * Restores the authentic state of tampered evidence.
   */
  public restoreAuthenticEvidence(evidenceId: string): EvidenceItem {
    const item = this.evidence.find((e) => e.evidence_id === evidenceId);
    if (!item || !item.is_tampered) return item || ({} as EvidenceItem);

    const restored: EvidenceItem = {
      ...item,
      [item.tampered_field as keyof EvidenceItem]: item.original_value,
      is_tampered: false,
      tampered_field: undefined,
      tampered_value: undefined,
      original_value: undefined,
    };

    this.evidence = this.evidence.map((e) => (e.evidence_id === evidenceId ? restored : e));
    saveStored(STORAGE_KEY_EVIDENCE, this.evidence);

    this.recordAudit({
      action: 'EVIDENCE_RESTORED',
      entity_type: 'EVIDENCE',
      entity_id: evidenceId,
      previous_value: 'Tampered State',
      new_value: 'Authentic Forensic Record Restored',
      hash_reference: item.sha256_hash,
    });

    this.notify();
    return restored;
  }

  // ========================================================
  // TEST KIT INVENTORY
  // ========================================================

  public getKits(): TestKit[] {
    return this.kits;
  }

  public getKitById(kitId: string): TestKit | undefined {
    return this.kits.find((k) => k.kit_id === kitId);
  }

  public isKitValid(kitId: string): { valid: boolean; reason?: string; warning?: string } {
    const kit = this.kits.find((k) => k.kit_id === kitId);
    if (!kit) return { valid: false, reason: 'Kit not found' };

    if (kit.status === 'EXPIRED') {
      return { valid: false, reason: 'Kit expired — field testing blocked by forensic policy.' };
    }
    if (kit.status === 'DEPLETED') {
      return { valid: false, reason: 'Kit inventory depleted.' };
    }
    if (kit.status === 'QUARANTINED') {
      return { valid: false, reason: 'Kit lot quarantined due to quality recall.' };
    }

    const expiry = new Date(kit.expiry_date).getTime();
    const now = Date.now();
    if (expiry < now) {
      return { valid: false, reason: 'Kit passed expiration date — testing prohibited.' };
    }

    const fourteenDaysMs = 14 * 24 * 60 * 60 * 1000;
    if (expiry - now < fourteenDaysMs) {
      const daysLeft = Math.max(1, Math.ceil((expiry - now) / (24 * 60 * 60 * 1000)));
      return { valid: true, warning: `Kit expires in ${daysLeft} days. Priority usage recommended.` };
    }

    return { valid: true };
  }

  public toggleKitQuarantine(kitId: string) {
    const kit = this.kits.find((k) => k.kit_id === kitId);
    if (!kit) return;
    const isQuarantined = kit.status === 'QUARANTINED' || !!kit.quarantined;
    const newStatus: KitStatus = isQuarantined ? 'AVAILABLE' : 'QUARANTINED';
    kit.status = newStatus;
    kit.quarantined = !isQuarantined;
    this.kits = [...this.kits];
    saveStored(STORAGE_KEY_KITS, this.kits);
    this.recordAudit({
      action: 'CASE_UPDATED',
      entity_type: 'KIT',
      entity_id: kitId,
      previous_value: isQuarantined ? 'QUARANTINED' : 'AVAILABLE',
      new_value: newStatus,
    });
    this.notify();
  }

  public addTestKit(kit: TestKit) {
    this.kits = [kit, ...this.kits];
    saveStored(STORAGE_KEY_KITS, this.kits);
    this.recordAudit({
      action: 'CASE_CREATED',
      entity_type: 'KIT',
      entity_id: kit.kit_id,
      new_value: `Added kit lot ${kit.lot_number || kit.batch_number}`,
    });
    this.notify();
  }

  // ========================================================
  // CHAIN OF CUSTODY
  // ========================================================

  public getCustodyEvents(evidenceId?: string): CustodyEvent[] {
    if (!evidenceId) return this.custodyEvents;
    return this.custodyEvents.filter((c) => c.evidence_id === evidenceId);
  }

  public recordCustodyEvent(params: {
    evidence_id: string;
    case_id: string;
    from_user: string;
    to_user: string;
    from_location: string;
    to_location: string;
    action: CustodyEvent['action'];
    reason: string;
  }): CustodyEvent {
    const timestamp = new Date().toISOString();
    const eventId = `CUST-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const rawHashInput = `${eventId}:${params.evidence_id}:${params.from_user}:${params.to_user}:${timestamp}:${params.action}`;
    
    // Quick deterministic hash for event chaining
    let hash = 0;
    for (let i = 0; i < rawHashInput.length; i++) {
      hash = (hash << 5) - hash + rawHashInput.charCodeAt(i);
      hash |= 0;
    }
    const eventHash = Math.abs(hash).toString(16).padStart(64, '0');

    const event: CustodyEvent = {
      event_id: eventId,
      evidence_id: params.evidence_id,
      case_id: params.case_id,
      from_user: params.from_user,
      to_user: params.to_user,
      from_location: params.from_location,
      to_location: params.to_location,
      action: params.action,
      timestamp,
      reason: params.reason,
      digital_acknowledgement: true,
      event_hash: eventHash,
    };

    this.custodyEvents = [event, ...this.custodyEvents];
    saveStored(STORAGE_KEY_CUSTODY, this.custodyEvents);

    this.recordAudit({
      action: 'EVIDENCE_TRANSFERRED',
      entity_type: 'EVIDENCE',
      entity_id: params.evidence_id,
      previous_value: `${params.from_user} (${params.from_location})`,
      new_value: `${params.to_user} (${params.to_location}) - ${params.reason}`,
      hash_reference: eventHash,
    });

    this.notify();
    return event;
  }

  public async recordCustodyTransfer(
    evidenceId: string,
    caseId: string,
    toUser: string,
    fromLocation: string,
    toLocation: string,
    action: CustodyEvent['action'] = 'TRANSFERRED',
    reason: string = 'Custody Transfer',
    digitalAcknowledgement: boolean = true
  ): Promise<CustodyEvent> {
    const fromUser = this.currentUser.full_name;
    const event = this.recordCustodyEvent({
      evidence_id: evidenceId,
      case_id: caseId,
      from_user: fromUser,
      to_user: toUser,
      from_location: fromLocation,
      to_location: toLocation,
      action,
      reason,
    });
    const ev = this.evidence.find((e) => e.evidence_id === evidenceId);
    if (ev) {
      ev.current_location = toLocation;
      ev.current_custodian = toUser;
      this.evidence = [...this.evidence];
      saveStored(STORAGE_KEY_EVIDENCE, this.evidence);
    }
    return event;
  }

  // ========================================================
  // VERIFICATION WORKFLOW (OFFICER & SUPERVISOR)
  // ========================================================

  public getVerifications(): VerificationRecord[] {
    return this.verifications;
  }

  public async recordVerification(
    evidenceId: string,
    caseId: string,
    stage: VerificationStage,
    decision: VerificationDecision,
    fullReason: string = ''
  ): Promise<VerificationRecord> {
    const record: VerificationRecord = {
      verification_id: `VER-${Date.now().toString(36).toUpperCase()}`,
      case_id: caseId,
      evidence_id: evidenceId,
      stage,
      reviewer_id: this.currentUser.user_id,
      reviewer_name: this.currentUser.full_name,
      decision,
      reason: fullReason,
      timestamp: new Date().toISOString(),
      discrepancy_flag: decision === 'REJECT',
    };

    this.verifications = [record, ...this.verifications];
    saveStored(STORAGE_KEY_VERIFICATIONS, this.verifications);

    const ev = this.evidence.find((e) => e.evidence_id === evidenceId);
    if (ev) {
      if (stage === 'OFFICER') {
        ev.officer_verification = record;
        if (decision === 'CONFIRM') {
          ev.status = 'PENDING_VERIFICATION';
        } else if (decision === 'REQUEST_RETEST') {
          ev.status = 'TESTED';
        }
      } else {
        ev.supervisor_signoff = record;
        if (decision === 'CONFIRM') {
          ev.status = 'VERIFIED';
        }
      }
      this.evidence = [...this.evidence];
      saveStored(STORAGE_KEY_EVIDENCE, this.evidence);
    }

    this.recordAudit({
      action: decision === 'CONFIRM' ? 'RESULT_VERIFIED' : 'RESULT_REJECTED',
      entity_type: 'EVIDENCE',
      entity_id: evidenceId,
      new_value: `${stage} verification: ${decision} - ${fullReason}`,
      hash_reference: ev?.sha256_hash,
    });

    this.notify();
    return record;
  }

  public verifyEvidence(params: {
    evidence_id: string;
    case_id: string;
    stage: 'OFFICER' | 'SUPERVISOR';
    decision: 'CONFIRM' | 'REJECT' | 'REQUEST_RETEST';
    reason?: string;
  }): EvidenceItem {
    const evidence = this.evidence.find((e) => e.evidence_id === params.evidence_id);
    if (!evidence) throw new Error('Evidence item not found');

    let newStatus: EvidenceItem['status'] = evidence.status;
    if (params.stage === 'OFFICER') {
      newStatus = params.decision === 'CONFIRM' ? 'PENDING_VERIFICATION' : 'REGISTERED';
    } else if (params.stage === 'SUPERVISOR') {
      newStatus = params.decision === 'CONFIRM' ? 'VERIFIED' : 'TESTED';
    }

    const updated: EvidenceItem = {
      ...evidence,
      status: newStatus,
      updated_at: new Date().toISOString(),
    };

    this.evidence = this.evidence.map((e) => (e.evidence_id === params.evidence_id ? updated : e));
    saveStored(STORAGE_KEY_EVIDENCE, this.evidence);

    this.recordAudit({
      action: params.decision === 'CONFIRM' ? 'RESULT_VERIFIED' : 'RESULT_REJECTED',
      entity_type: 'EVIDENCE',
      entity_id: params.evidence_id,
      previous_value: `Status: ${evidence.status}`,
      new_value: `${params.stage} ${params.decision}: ${params.reason || 'Verification recorded'}`,
      hash_reference: evidence.sha256_hash,
    });

    this.notify();
    return updated;
  }

  // ========================================================
  // OFFLINE SYNC MANAGEMENT
  // ========================================================

  public getSyncStatus(): SyncStatus {
    return this.syncStatus;
  }

  public getSyncQueue(): SyncQueueItem[] {
    return this.syncQueue;
  }

  public queueOfflineAction(action: SyncQueueItem['action'], payload: Record<string, unknown>) {
    const item: SyncQueueItem = {
      queue_id: `Q-${Date.now()}`,
      action,
      payload,
      timestamp: new Date().toISOString(),
      status: 'PENDING',
    };
    this.syncQueue.push(item);
    saveStored(STORAGE_KEY_SYNC, this.syncQueue);
    this.notify();
  }

  public async processSyncQueue() {
    if (this.syncQueue.length === 0) return;
    this.syncStatus = 'SYNCING';
    this.notify();

    // Simulate batch sync processing
    await new Promise((resolve) => setTimeout(resolve, 1200));

    this.syncQueue = [];
    saveStored(STORAGE_KEY_SYNC, this.syncQueue);
    this.syncStatus = 'SYNC COMPLETE';
    this.notify();

    setTimeout(() => {
      this.syncStatus = 'ONLINE';
      this.notify();
    }, 3000);
  }
}

// Global Singleton
export const forensicRepo = new ForensicRepository();

/**
 * React hook to reactively subscribe to repository state changes.
 */
export function useForensicStore() {
  const [, setTick] = useState(0);

  useEffect(() => {
    return forensicRepo.subscribe(() => setTick((t) => t + 1));
  }, []);

  const curUser = forensicRepo.getCurrentUser();

  return {
    currentUser: {
      ...curUser,
      name: curUser.full_name,
    },
    users: forensicRepo.getUsers(),
    setCurrentUser: (u: User | UserRole) => {
      if (typeof u === 'string') {
        forensicRepo.switchRole(u as UserRole);
      } else {
        forensicRepo.setCurrentUser(u);
      }
    },
    switchRole: (r: UserRole) => forensicRepo.switchRole(r),

    cases: forensicRepo.getCases(),
    getCaseById: (id: string) => forensicRepo.getCaseById(id),
    createCase: (data: Parameters<ForensicRepository['createCase']>[0]) => forensicRepo.createCase(data),
    updateCase: (id: string, updates: Partial<ForensicCase>) => forensicRepo.updateCase(id, updates),

    evidence: forensicRepo.getEvidence(),
    getEvidenceById: (id: string) => forensicRepo.getEvidenceById(id),
    getEvidenceByCase: (caseId: string) => forensicRepo.getEvidenceByCase(caseId),
    registerEvidence: (data: Parameters<ForensicRepository['registerEvidence']>[0]) => forensicRepo.registerEvidence(data),
    createEvidenceVersion: (id: string, updates: Partial<EvidenceItem>, reason: string) => forensicRepo.createEvidenceVersion(id, updates, reason),

    simulateTamper: (id: string, field: keyof EvidenceItem, val: unknown) => forensicRepo.simulateEvidenceTamper(id, field, val),
    restoreAuthentic: (id: string) => forensicRepo.restoreAuthenticEvidence(id),

    kits: forensicRepo.getKits(),
    testKits: forensicRepo.getKits(),
    getKitById: (id: string) => forensicRepo.getKitById(id),
    isKitValid: (kitId: string) => forensicRepo.isKitValid(kitId),
    toggleKitQuarantine: (kitId: string) => forensicRepo.toggleKitQuarantine(kitId),
    addTestKit: (kit: TestKit) => forensicRepo.addTestKit(kit),

    custodyEvents: forensicRepo.getCustodyEvents(),
    getCustodyEvents: (evidenceId?: string) => forensicRepo.getCustodyEvents(evidenceId),
    recordCustody: (params: Parameters<ForensicRepository['recordCustodyEvent']>[0]) => forensicRepo.recordCustodyEvent(params),
    recordCustodyTransfer: (
      evidenceId: string,
      caseId: string,
      toUser: string,
      fromLocation: string,
      toLocation: string,
      action?: CustodyEvent['action'],
      reason?: string,
      digitalAcknowledgement?: boolean
    ) => forensicRepo.recordCustodyTransfer(evidenceId, caseId, toUser, fromLocation, toLocation, action, reason, digitalAcknowledgement),

    verifications: forensicRepo.getVerifications(),
    verifyEvidence: (params: Parameters<ForensicRepository['verifyEvidence']>[0]) => forensicRepo.verifyEvidence(params),
    recordVerification: (
      evidenceId: string,
      caseId: string,
      stage: VerificationStage,
      decision: VerificationDecision,
      fullReason?: string
    ) => forensicRepo.recordVerification(evidenceId, caseId, stage, decision, fullReason || ''),

    auditEvents: forensicRepo.getAuditEvents(),
    recordAudit: (params: Parameters<ForensicRepository['recordAudit']>[0]) => forensicRepo.recordAudit(params),

    syncStatus: forensicRepo.getSyncStatus(),
    syncQueue: forensicRepo.getSyncQueue(),
    syncPendingItems: () => forensicRepo.processSyncQueue(),
    processSyncQueue: () => forensicRepo.processSyncQueue(),
  };
}
