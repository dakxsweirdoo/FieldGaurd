import type { FinalResult, QualityGate, RawPrediction } from '@/types';

export function resultColor(result: FinalResult): string {
  switch (result) {
    case 'PRESUMPTIVE POSITIVE': return 'text-amber-600';
    case 'PRELIMINARY NEGATIVE': return 'text-guard-600';
    case 'INCONCLUSIVE': return 'text-info-500';
    case 'INVALID': return 'text-alert-600';
  }
}

export function resultBg(result: FinalResult): string {
  switch (result) {
    case 'PRESUMPTIVE POSITIVE': return 'bg-amber-50 border-amber-200';
    case 'PRELIMINARY NEGATIVE': return 'bg-guard-50 border-guard-200';
    case 'INCONCLUSIVE': return 'bg-info-50 border-info-200';
    case 'INVALID': return 'bg-alert-50 border-alert-200';
  }
}

export function resultBadgeTone(result: FinalResult): 'guard' | 'amber' | 'alert' | 'info' | 'neutral' {
  switch (result) {
    case 'PRESUMPTIVE POSITIVE': return 'amber';
    case 'PRELIMINARY NEGATIVE': return 'guard';
    case 'INCONCLUSIVE': return 'info';
    case 'INVALID': return 'alert';
  }
}

export function rawTone(pred: RawPrediction): 'guard' | 'amber' | 'alert' | 'info' | 'neutral' {
  switch (pred) {
    case 'POSITIVE': return 'amber';
    case 'NEGATIVE': return 'guard';
    case 'INCONCLUSIVE': return 'info';
    case 'INVALID': return 'alert';
  }
}

export function qualityGateTone(gate: QualityGate): 'guard' | 'amber' {
  return gate === 'ACCEPTABLE' ? 'guard' : 'amber';
}

export function formatTimestamp(ts: string): string {
  const d = new Date(ts);
  return d.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}

export function formatDate(ts: string): string {
  const d = new Date(ts);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatTime(ts: string): string {
  const d = new Date(ts);
  return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
}

export function shortHash(hash: string | null): string {
  if (!hash) return '—';
  return hash.slice(0, 12) + '…' + hash.slice(-8);
}

