import React, { useState, useMemo } from 'react';
import { useForensicStore } from '@/lib/forensicStore';
import type { AuditAction, AuditEvent, UserRole } from '@/types';

interface AuditPageProps {
  onNavigate?: (page: any) => void;
}

export const AuditPage: React.FC<AuditPageProps> = () => {
  const { auditEvents, currentUser } = useForensicStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [entityFilter, setEntityFilter] = useState<string>('ALL');
  const [expandedEventId, setExpandedEventId] = useState<string | null>(null);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return auditEvents
      .filter((ev) => {
        if (actionFilter !== 'ALL' && ev.action !== actionFilter) return false;
        if (roleFilter !== 'ALL' && ev.user_role !== roleFilter) return false;
        if (entityFilter !== 'ALL' && ev.entity_type !== entityFilter) return false;
        if (searchTerm) {
          const q = searchTerm.toLowerCase();
          const match =
            ev.event_id.toLowerCase().includes(q) ||
            ev.user_id.toLowerCase().includes(q) ||
            ev.entity_id.toLowerCase().includes(q) ||
            ev.action.toLowerCase().includes(q) ||
            (ev.previous_value && ev.previous_value.toLowerCase().includes(q)) ||
            (ev.new_value && ev.new_value.toLowerCase().includes(q));
          if (!match) return false;
        }
        return true;
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [auditEvents, actionFilter, roleFilter, entityFilter, searchTerm]);

  // Export handlers
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(filteredEvents, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `fieldguard_audit_trail_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportCSV = () => {
    const headers = ['Event ID', 'Timestamp', 'User ID', 'Role', 'Action', 'Entity Type', 'Entity ID', 'Hash Reference'];
    const rows = filteredEvents.map((ev) => [
      ev.event_id,
      ev.timestamp,
      ev.user_id,
      ev.user_role,
      ev.action,
      ev.entity_type,
      ev.entity_id,
      ev.hash_reference || '',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.map((val) => `"${val}"`).join(','))].join('\n');

    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', encodeURI(csvContent));
    downloadAnchor.setAttribute('download', `fieldguard_audit_trail_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getActionBadge = (action: AuditAction) => {
    if (action.includes('TAMPER') || action.includes('FAILED')) {
      return 'bg-red-50 text-red-700 border-red-200';
    }
    if (action.includes('RESTORED') || action.includes('PASSED') || action.includes('VERIFIED')) {
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    }
    if (action.includes('CREATED') || action.includes('REGISTERED')) {
      return 'bg-blue-50 text-blue-700 border-blue-200';
    }
    if (action.includes('SEALED') || action.includes('REPORT')) {
      return 'bg-purple-50 text-purple-700 border-purple-200';
    }
    return 'bg-slate-50 text-slate-700 border-slate-200';
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Immutability Notice Banner */}
      <div className="p-4 rounded-xl bg-guard-50 border border-guard-200 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-guard-700 text-white flex items-center justify-center shrink-0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>
          <div>
            <div className="text-xs font-bold text-guard-900 uppercase">
              ISO/IEC 17025 Immutable Append-Only Ledger
            </div>
            <p className="text-2xs text-guard-800">
              This audit repository is write-once, tamper-evident, and cryptographically anchored. No entries may be edited or purged.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 rounded-lg border border-line bg-surface hover:bg-canvas text-xs font-semibold text-ink shadow-sm transition-all flex items-center gap-1.5"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Export CSV
          </button>
          <button
            onClick={handleExportJSON}
            className="px-3 py-1.5 rounded-lg border border-line bg-surface hover:bg-canvas text-xs font-semibold text-ink shadow-sm transition-all flex items-center gap-1.5"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Export JSON
          </button>
        </div>
      </div>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-line pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold tracking-[0.16em] uppercase text-guard-700">
            <span className="w-2 h-2 rounded-full bg-guard-600 animate-pulse" />
            Statutory Compliance Ledger
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-ink mt-1">
            System & Case Audit Trail
          </h1>
          <p className="text-sm text-ink-muted mt-1">
            Unbroken cryptographic record of every user action, AI analysis, verification, custody change, and security event.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-ink-muted">
          <div className="p-2.5 rounded-xl bg-surface border border-line text-center">
            <span className="text-ink-light block text-2xs uppercase">Active Entries</span>
            <span className="text-lg font-black text-ink">{auditEvents.length}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-surface border border-line text-center">
            <span className="text-ink-light block text-2xs uppercase">System State</span>
            <span className="text-lg font-black text-emerald-600">SEALED</span>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-xl bg-surface border border-line flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            placeholder="Search by event ID, officer, case number, or diff content..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3.5 py-2 text-sm border border-line rounded-lg bg-canvas focus:outline-none focus:ring-2 focus:ring-guard-500/20"
          />
        </div>

        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
        >
          <option value="ALL">All Actions ({auditEvents.length})</option>
          <option value="CASE_CREATED">CASE_CREATED</option>
          <option value="EVIDENCE_REGISTERED">EVIDENCE_REGISTERED</option>
          <option value="AI_ANALYSIS_COMPLETED">AI_ANALYSIS_COMPLETED</option>
          <option value="RESULT_VERIFIED">RESULT_VERIFIED</option>
          <option value="EVIDENCE_TRANSFERRED">EVIDENCE_TRANSFERRED</option>
          <option value="EVIDENCE_SEALED">EVIDENCE_SEALED</option>
          <option value="INTEGRITY_CHECK_PASSED">INTEGRITY_CHECK_PASSED</option>
          <option value="INTEGRITY_CHECK_FAILED">INTEGRITY_CHECK_FAILED</option>
          <option value="EVIDENCE_TAMPER_SIMULATED">EVIDENCE_TAMPER_SIMULATED</option>
          <option value="EVIDENCE_RESTORED">EVIDENCE_RESTORED</option>
        </select>

        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
        >
          <option value="ALL">All Roles</option>
          <option value="FIELD_OFFICER">FIELD_OFFICER</option>
          <option value="SUPERVISOR">SUPERVISOR</option>
          <option value="FORENSIC_ANALYST">FORENSIC_ANALYST</option>
          <option value="AUDITOR">AUDITOR</option>
          <option value="ADMIN">ADMIN</option>
        </select>

        <select
          value={entityFilter}
          onChange={(e) => setEntityFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
        >
          <option value="ALL">All Entities</option>
          <option value="CASE">CASE</option>
          <option value="EVIDENCE">EVIDENCE</option>
          <option value="TEST">TEST</option>
          <option value="REPORT">REPORT</option>
          <option value="KIT">KIT</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className="bg-surface border border-line rounded-2xl overflow-hidden shadow-sm">
        {filteredEvents.length === 0 ? (
          <div className="p-12 text-center">
            <svg className="w-12 h-12 mx-auto text-ink-light" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
            </svg>
            <p className="mt-3 text-sm font-semibold text-ink">No audit entries found</p>
            <p className="text-xs text-ink-muted mt-1">Adjust filters or search parameters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-canvas border-b border-line text-2xs font-bold uppercase tracking-wider text-ink-light">
                <tr>
                  <th className="px-5 py-3">Timestamp (UTC)</th>
                  <th className="px-5 py-3">Actor / Role</th>
                  <th className="px-5 py-3">Action</th>
                  <th className="px-5 py-3">Entity</th>
                  <th className="px-5 py-3">IP / Device</th>
                  <th className="px-5 py-3">Cryptographic Ref</th>
                  <th className="px-5 py-3 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line/60">
                {filteredEvents.map((ev) => {
                  const isExpanded = expandedEventId === ev.event_id;

                  return (
                    <React.Fragment key={ev.event_id}>
                      <tr
                        className={`hover:bg-canvas/50 transition-colors ${
                          ev.action.includes('TAMPER') ? 'bg-red-50/40' : ''
                        }`}
                      >
                        <td className="px-5 py-3.5 font-mono text-xs text-ink">
                          {new Date(ev.timestamp).toLocaleString()}
                        </td>

                        <td className="px-5 py-3.5">
                          <div className="font-semibold text-ink text-xs">{ev.user_id}</div>
                          <div className="text-2xs font-bold text-guard-700 uppercase tracking-wider">
                            {ev.user_role}
                          </div>
                        </td>

                        <td className="px-5 py-3.5">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-2xs font-extrabold border tracking-wider ${getActionBadge(
                              ev.action
                            )}`}
                          >
                            {ev.action}
                          </span>
                        </td>

                        <td className="px-5 py-3.5 font-mono text-xs">
                          <span className="font-bold text-ink">{ev.entity_type}:</span>{' '}
                          <span className="text-ink-muted">{ev.entity_id}</span>
                        </td>

                        <td className="px-5 py-3.5 font-mono text-2xs text-ink-muted">
                          <div>{ev.ip_address || '127.0.0.1'}</div>
                          <div className="text-ink-light">{ev.device_id || 'FG-CONSOLE-01'}</div>
                        </td>

                        <td className="px-5 py-3.5 font-mono text-2xs text-ink-muted">
                          <span className="bg-canvas px-1.5 py-0.5 rounded border border-line">
                            {ev.hash_reference ? ev.hash_reference.slice(0, 16) + '...' : 'SEALED'}
                          </span>
                        </td>

                        <td className="px-5 py-3.5 text-right">
                          {(ev.previous_value || ev.new_value) && (
                            <button
                              onClick={() =>
                                setExpandedEventId(isExpanded ? null : ev.event_id)
                              }
                              className="text-xs font-semibold text-guard-700 hover:text-guard-900"
                            >
                              {isExpanded ? 'Hide Diff' : 'View Diff'}
                            </button>
                          )}
                        </td>
                      </tr>

                      {/* Expandable Diff Row */}
                      {isExpanded && (
                        <tr className="bg-canvas/80 border-b border-line">
                          <td colSpan={7} className="px-6 py-4">
                            <div className="p-4 rounded-xl bg-surface border border-line space-y-3">
                              <div className="text-xs font-bold text-ink uppercase tracking-wider">
                                State Transition Snapshot · {ev.event_id}
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                                <div>
                                  <span className="text-2xs font-bold uppercase text-ink-light block mb-1">
                                    Previous State Value
                                  </span>
                                  <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-900 break-all">
                                    {ev.previous_value || 'None (Initial Registration)'}
                                  </div>
                                </div>
                                <div>
                                  <span className="text-2xs font-bold uppercase text-ink-light block mb-1">
                                    New State Value
                                  </span>
                                  <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 break-all">
                                    {ev.new_value || 'None'}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
export default AuditPage;
