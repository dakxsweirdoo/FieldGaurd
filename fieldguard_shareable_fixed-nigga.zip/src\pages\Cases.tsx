import { useState, useMemo } from 'react';
import { Search, ArrowLeft, Download, FileLock2 } from 'lucide-react';
import type { CaseRecord, Page } from '@/types';
import { Panel } from '@/components/ui/Panel';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ProbabilityBar } from '@/components/ui/ProbabilityBar';
import { SensorGraph } from '@/components/ui/SensorGraph';
import { SafetyNotice } from '@/components/SafetyNotice';
import { resultBadgeTone, rawTone, resultColor, formatTimestamp, shortHash } from '@/lib/result-helpers';

interface CasesProps {
  cases: CaseRecord[];
  onSelectCase: (caseId: string) => void;
  onNavigate: (page: Page) => void;
  selectedCase: CaseRecord | null;
  onBack: () => void;
  loading: boolean;
}

const filters: { key: string; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'PRESUMPTIVE POSITIVE', label: 'Presumptive Positive' },
  { key: 'PRELIMINARY NEGATIVE', label: 'Preliminary Negative' },
  { key: 'INCONCLUSIVE', label: 'Inconclusive' },
  { key: 'INVALID', label: 'Invalid' },
];

export function Cases({ cases, onSelectCase, onNavigate, selectedCase, onBack, loading }: CasesProps) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = useMemo(() => {
    return cases.filter((c) => {
      if (filter !== 'all' && c.final_result !== filter) return false;
      if (search && !c.case_id.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [cases, search, filter]);

  if (selectedCase) {
    return <CaseDetail caseRecord={selectedCase} onBack={onBack} />;
  }

  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5 animate-fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-ink">Case Registry</h1>
        <p className="text-sm text-ink-muted mt-1">{cases.length} case records on file</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-light" />
          <input
            type="text"
            placeholder="Search by Case ID…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-line bg-surface text-sm text-ink placeholder:text-ink-light focus:outline-none focus:border-guard-400 focus:ring-2 focus:ring-guard-50"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {filters.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                filter === f.key
                  ? 'bg-guard-600 text-white'
                  : 'bg-surface border border-line text-ink-muted hover:text-ink hover:border-ink-light'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <Panel className="p-8 text-center">
          <div className="inline-flex w-6 h-6 rounded-full border-2 border-guard-500 border-t-transparent animate-spin" />
          <p className="text-sm text-ink-muted mt-3">Loading case records…</p>
        </Panel>
      ) : filtered.length === 0 ? (
        <Panel className="p-8 text-center">
          <p className="text-sm text-ink-muted">No cases match the current filter.</p>
        </Panel>
      ) : (
        <Panel className="overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line bg-canvas-warm">
                  <th className="text-left px-4 py-3 section-label">Case ID</th>
                  <th className="text-left px-4 py-3 section-label">Date</th>
                  <th className="text-left px-4 py-3 section-label">Decision</th>
                  <th className="text-left px-4 py-3 section-label">Raw AI</th>
                  <th className="text-right px-4 py-3 section-label">Confidence</th>
                  <th className="text-left px-4 py-3 section-label">Quality</th>
                  <th className="text-left px-4 py-3 section-label">Sensor</th>
                  <th className="text-left px-4 py-3 section-label">Audit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line-soft">
                {filtered.map((c) => (
                  <tr
                    key={c.case_id}
                    onClick={() => onSelectCase(c.case_id)}
                    className="hover:bg-canvas-warm cursor-pointer transition-colors"
                  >
                    <td className="px-4 py-3 font-mono text-xs font-bold text-ink whitespace-nowrap">{c.case_id}</td>
                    <td className="px-4 py-3 text-xs text-ink-muted whitespace-nowrap">{formatTimestamp(c.timestamp)}</td>
                    <td className="px-4 py-3"><Badge tone={resultBadgeTone(c.final_result)}>{c.final_result}</Badge></td>
                    <td className="px-4 py-3"><Badge tone={rawTone(c.raw_prediction)}>{c.raw_prediction}</Badge></td>
                    <td className="px-4 py-3 text-right font-mono font-semibold text-ink whitespace-nowrap">{c.raw_confidence.toFixed(2)}%</td>
                    <td className="px-4 py-3 text-xs text-ink-soft whitespace-nowrap">{c.quality_gate}</td>
                    <td className="px-4 py-3 text-xs">
                      {c.sensor_available ? (
                        <span className="text-guard-600 font-medium">{c.sensor_class ?? 'Available'}</span>
                      ) : (
                        <span className="text-ink-light">N/A</span>
                      )}
                    </td>
                    <td className="px-4 py-3"><Badge tone="guard">{c.audit_status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      )}
    </div>
  );
}

function CaseDetail({ caseRecord, onBack }: { caseRecord: CaseRecord; onBack: () => void }) {
  const c = caseRecord;
  const probEntries = [
    { label: 'POSITIVE', value: c.probabilities.POSITIVE, tone: 'amber' as const },
    { label: 'INCONCLUSIVE', value: c.probabilities.INCONCLUSIVE, tone: 'info' as const },
    { label: 'NEGATIVE', value: c.probabilities.NEGATIVE, tone: 'guard' as const },
    { label: 'INVALID', value: c.probabilities.INVALID, tone: 'alert' as const },
  ].sort((a, b) => b.value - a.value);

  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5 animate-fade-in">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="w-9 h-9 rounded-lg border border-line bg-surface flex items-center justify-center hover:bg-canvas-warm transition-colors min-h-[44px] min-w-[44px]">
          <ArrowLeft size={16} className="text-ink-soft" />
        </button>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-ink font-mono">{c.case_id}</h1>
          <p className="text-xs text-ink-muted mt-0.5">{formatTimestamp(c.timestamp)}</p>
        </div>
      </div>

      <div className={`rounded-xl border-2 p-5 ${c.final_result === 'PRESUMPTIVE POSITIVE' ? 'bg-amber-50 border-amber-200' : c.final_result === 'PRELIMINARY NEGATIVE' ? 'bg-guard-50 border-guard-200' : c.final_result === 'INCONCLUSIVE' ? 'bg-info-50 border-info-200' : 'bg-alert-50 border-alert-200'}`}>
        <span className="section-label">Final Operational Decision</span>
        <p className={`text-2xl sm:text-3xl font-bold mt-1 ${resultColor(c.final_result)}`}>
          {c.final_result}
        </p>
        <div className="mt-4 pt-4 border-t border-current/10 flex items-baseline gap-3 flex-wrap">
          <span className="section-label">Raw AI Prediction</span>
          <span className="text-base font-bold text-ink">{c.raw_prediction}</span>
          <Badge tone={rawTone(c.raw_prediction)}>{c.raw_confidence.toFixed(2)}%</Badge>
        </div>
      </div>

      <SafetyNotice result={c.final_result} />

      <Panel className="p-5">
        <span className="section-label">Explanation</span>
        <p className="text-sm text-ink-soft leading-relaxed mt-2">{c.reason}</p>
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Panel className="p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-bold text-ink">Vision AI</span>
            <Badge tone={rawTone(c.raw_prediction)}>{c.raw_prediction}</Badge>
          </div>
          <div className="space-y-2.5">
            {probEntries.map((p) => (
              <ProbabilityBar key={p.label} label={p.label} value={p.value} tone={p.tone} />
            ))}
          </div>
        </Panel>

        <Panel className="p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-bold text-ink">Quality Control</span>
            <Badge tone={c.quality_gate === 'ACCEPTABLE' ? 'guard' : 'amber'}>{c.quality_gate}</Badge>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="data-label">Risk</span><p className="font-mono font-semibold text-ink mt-0.5">{c.quality_risk.toFixed(2)}%</p></div>
            <div><span className="data-label">Resolution</span><p className="font-mono text-ink mt-0.5">{c.quality_metrics.resolution}</p></div>
            <div><span className="data-label">Brightness</span><p className="font-mono text-ink mt-0.5">{c.quality_metrics.brightness.toFixed(0)}%</p></div>
            <div><span className="data-label">Contrast</span><p className="font-mono text-ink mt-0.5">{c.quality_metrics.contrast.toFixed(0)}%</p></div>
          </div>
        </Panel>
      </div>

      {c.sensor_available && (
        <Panel className="p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-bold text-ink">Auxiliary Sensor</span>
            <div className="flex items-center gap-3">
              <Badge tone="guard">{c.sensor_class ?? 'Available'}</Badge>
              <span className="text-xs font-mono text-ink-muted">{c.sensor_confidence?.toFixed(1)}%</span>
            </div>
          </div>
          <SensorGraph readings={c.sensor_readings} height={100} />
        </Panel>
      )}

      <Panel className="p-5">
        <span className="section-label">Traceability</span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-0 mt-3">
          <div className="flex items-center justify-between py-2 border-b border-line-soft">
            <span className="data-label">Image SHA-256</span>
            <span className="text-xs font-mono font-semibold text-ink">{shortHash(c.image_sha256)}</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-line-soft">
            <span className="data-label">Evidence Mode</span>
            <span className="text-xs font-semibold text-ink">{c.evidence_mode.replace(/_/g, ' ')}</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-line-soft">
            <span className="data-label">Vision Model</span>
            <span className="text-xs font-mono text-ink">fieldguard_v2.pt</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-line-soft">
            <span className="data-label">Audit Status</span>
            <Badge tone="guard">{c.audit_status}</Badge>
          </div>
        </div>
        {c.warnings.length > 0 && (
          <div className="mt-4 p-3 rounded-lg bg-amber-50 border border-amber-100">
            <p className="text-2xs font-bold uppercase tracking-wider text-amber-700 mb-1.5">Warnings</p>
            <ul className="space-y-1">
              {c.warnings.map((w, i) => (
                <li key={i} className="text-xs text-amber-700 flex items-start gap-1.5">
                  <span className="mt-1.5 w-1 h-1 rounded-full bg-amber-500 shrink-0" />{w}
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="flex gap-2 mt-5 pt-5 border-t border-line-soft">
          <Button size="sm" variant="secondary"><Download size={14} /> Download Report</Button>
          <Button size="sm" variant="secondary"><FileLock2 size={14} /> View Audit Record</Button>
        </div>
      </Panel>
    </div>
  );
}

