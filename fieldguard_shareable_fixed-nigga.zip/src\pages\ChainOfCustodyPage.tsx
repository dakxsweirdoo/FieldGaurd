import React, { useState, useMemo } from 'react';
import { useForensicStore } from '@/lib/forensicStore';
import type { CustodyAction, CustodyEvent, UserRole } from '@/types';

interface ChainOfCustodyPageProps {
  onNavigate?: (page: any) => void;
  initialEvidenceId?: string | null;
}

export const ChainOfCustodyPage: React.FC<ChainOfCustodyPageProps> = ({
  initialEvidenceId,
}) => {
  const {
    custodyEvents,
    evidence,
    cases,
    currentUser,
    recordCustodyTransfer,
  } = useForensicStore();

  const [selectedCaseId, setSelectedCaseId] = useState<string>('ALL');
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string>(
    initialEvidenceId || 'ALL'
  );
  const [actionFilter, setActionFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // Modal State
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferEvidenceId, setTransferEvidenceId] = useState(
    evidence[0]?.evidence_id || ''
  );
  const [toUser, setToUser] = useState('');
  const [toRole, setToRole] = useState<UserRole>('SUPERVISOR');
  const [fromLocation, setFromLocation] = useState('Evidence Locker A-4');
  const [toLocation, setToLocation] = useState('Central Forensic Vault - Shelf 12');
  const [reason, setReason] = useState('Transfer for supervisor secondary forensic review');
  const [digitalAcknowledgement, setDigitalAcknowledgement] = useState(false);
  const [transferSuccess, setTransferSuccess] = useState<string | null>(null);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return custodyEvents
      .filter((ev) => {
        if (selectedCaseId !== 'ALL' && ev.case_id !== selectedCaseId) return false;
        if (selectedEvidenceId !== 'ALL' && ev.evidence_id !== selectedEvidenceId) return false;
        if (actionFilter !== 'ALL' && ev.action !== actionFilter) return false;
        if (searchTerm) {
          const q = searchTerm.toLowerCase();
          const match =
            ev.evidence_id.toLowerCase().includes(q) ||
            ev.case_id.toLowerCase().includes(q) ||
            ev.from_user.toLowerCase().includes(q) ||
            ev.to_user.toLowerCase().includes(q) ||
            ev.reason.toLowerCase().includes(q) ||
            ev.from_location.toLowerCase().includes(q) ||
            ev.to_location.toLowerCase().includes(q);
          if (!match) return false;
        }
        return true;
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [custodyEvents, selectedCaseId, selectedEvidenceId, actionFilter, searchTerm]);

  // Handle Transfer
  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!digitalAcknowledgement) {
      alert('Digital acknowledgement must be confirmed to execute transfer.');
      return;
    }
    if (!toUser.trim()) {
      alert('Recipient name is required.');
      return;
    }

    const targetEv = evidence.find((ev) => ev.evidence_id === transferEvidenceId);
    if (!targetEv) return;

    await recordCustodyTransfer(
      targetEv.evidence_id,
      targetEv.case_id,
      toUser,
      fromLocation,
      toLocation,
      'TRANSFERRED',
      reason,
      true
    );

    setTransferSuccess(`Custody of ${targetEv.evidence_id} successfully transferred to ${toUser}.`);
    setIsTransferModalOpen(false);
    setDigitalAcknowledgement(false);
    setTimeout(() => setTransferSuccess(null), 5000);
  };

  const getActionBadge = (action: CustodyAction) => {
    switch (action) {
      case 'COLLECTED':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'TESTED':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'VERIFIED':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'TRANSFERRED':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'RECEIVED':
        return 'bg-teal-50 text-teal-700 border-teal-200';
      case 'SEALED':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'ARCHIVED':
        return 'bg-slate-100 text-slate-700 border-slate-300';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-line pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold tracking-[0.16em] uppercase text-guard-700">
            <span className="w-2 h-2 rounded-full bg-guard-600 animate-pulse" />
            ISO/IEC 17025 Compliant Forensic Trail
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-ink mt-1">
            Chain of Custody Ledger
          </h1>
          <p className="text-sm text-ink-muted mt-1">
            Tamper-evident, cryptographically linked timeline of evidence transfers and handling.
          </p>
        </div>

        <button
          onClick={() => setIsTransferModalOpen(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-guard-700 hover:bg-guard-800 text-white font-semibold shadow-sm transition-all text-sm shrink-0"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M16 3h5v5M4 20L20.2 3.8M21 16v5h-5M15 15l5.1 5.1M4 4l5 5" />
          </svg>
          Transfer Custody
        </button>
      </div>

      {transferSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <polyline points="22 4 12 14.01 9 11.01" />
          </svg>
          <span className="text-sm font-semibold">{transferSuccess}</span>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Total Transfers</div>
          <div className="text-2xl font-black text-ink mt-1">{custodyEvents.length}</div>
          <div className="text-2xs text-emerald-600 font-medium mt-1">100% SHA-256 Sealed</div>
        </div>
        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Active Evidence</div>
          <div className="text-2xl font-black text-ink mt-1">{evidence.length}</div>
          <div className="text-2xs text-ink-muted font-medium mt-1">Tracked across all vaults</div>
        </div>
        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Custodians on Record</div>
          <div className="text-2xl font-black text-ink mt-1">7</div>
          <div className="text-2xs text-guard-700 font-medium mt-1">Authorized personnel</div>
        </div>
        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Chain Integrity</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">VERIFIED</div>
          <div className="text-2xs text-emerald-700 font-medium mt-1">Zero broken links</div>
        </div>
      </div>

      {/* Filter Controls */}
      <div className="p-4 rounded-xl bg-surface border border-line flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            placeholder="Search by case, evidence, officer, or vault..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3.5 py-2 text-sm border border-line rounded-lg bg-canvas focus:outline-none focus:ring-2 focus:ring-guard-500/20"
          />
        </div>

        <select
          value={selectedCaseId}
          onChange={(e) => setSelectedCaseId(e.target.value)}
          className="px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
        >
          <option value="ALL">All Cases ({cases.length})</option>
          {cases.map((c) => (
            <option key={c.case_id} value={c.case_id}>
              {c.case_number} ({c.title})
            </option>
          ))}
        </select>

        <select
          value={selectedEvidenceId}
          onChange={(e) => setSelectedEvidenceId(e.target.value)}
          className="px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
        >
          <option value="ALL">All Evidence ({evidence.length})</option>
          {evidence.map((ev) => (
            <option key={ev.evidence_id} value={ev.evidence_id}>
              {ev.evidence_number} - {ev.substance_claimed || ev.type}
            </option>
          ))}
        </select>

        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
        >
          <option value="ALL">All Actions</option>
          <option value="COLLECTED">COLLECTED</option>
          <option value="TESTED">TESTED</option>
          <option value="VERIFIED">VERIFIED</option>
          <option value="TRANSFERRED">TRANSFERRED</option>
          <option value="RECEIVED">RECEIVED</option>
          <option value="SEALED">SEALED</option>
        </select>
      </div>

      {/* Timeline View */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-ink-muted px-2">
          <span>Chronological Audit Trail ({filteredEvents.length} events)</span>
          <span className="font-mono text-2xs">Latest first</span>
        </div>

        {filteredEvents.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-surface border border-line">
            <svg className="w-12 h-12 mx-auto text-ink-light" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <p className="mt-3 text-sm font-semibold text-ink">No custody events match your filters</p>
            <p className="text-xs text-ink-muted mt-1">Try resetting your filters or search query.</p>
          </div>
        ) : (
          <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-line">
            {filteredEvents.map((ev) => {
              const evRecord = evidence.find((e) => e.evidence_id === ev.evidence_id);
              const caseRecord = cases.find((c) => c.case_id === ev.case_id);

              return (
                <div key={ev.event_id} className="relative group">
                  {/* Timeline dot */}
                  <div className="absolute -left-6 sm:-left-8 top-4 w-4 h-4 rounded-full border-2 border-surface bg-guard-600 shadow" />

                  <div className="p-5 rounded-xl bg-surface border border-line hover:border-guard-300 transition-all shadow-sm space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 pb-3">
                      <div className="flex items-center gap-2.5">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-2xs font-extrabold border tracking-wider ${getActionBadge(
                            ev.action
                          )}`}
                        >
                          {ev.action}
                        </span>
                        <span className="font-mono text-xs font-bold text-ink">
                          {evRecord ? evRecord.evidence_number : ev.evidence_id}
                        </span>
                        <span className="text-xs text-ink-muted">·</span>
                        <span className="text-xs font-semibold text-guard-800">
                          {caseRecord ? caseRecord.case_number : ev.case_id}
                        </span>
                      </div>

                      <div className="text-xs text-ink-muted font-mono flex items-center gap-2">
                        <span>{new Date(ev.timestamp).toLocaleString()}</span>
                        {ev.digital_acknowledgement && (
                          <span className="inline-flex items-center gap-1 text-2xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            ✓ SIGNED
                          </span>
                        )}
                      </div>
                    </div>

                    {/* From / To Handover */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm bg-canvas/60 p-3 rounded-lg border border-line/40">
                      <div>
                        <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                          Released By / Origin
                        </span>
                        <div className="font-semibold text-ink mt-0.5">{ev.from_user}</div>
                        <div className="text-xs text-ink-muted">{ev.from_location}</div>
                      </div>

                      <div className="md:border-l md:border-line/60 md:pl-4">
                        <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                          Received By / Destination
                        </span>
                        <div className="font-semibold text-ink mt-0.5">{ev.to_user}</div>
                        <div className="text-xs text-ink-muted">{ev.to_location}</div>
                      </div>
                    </div>

                    {/* Reason */}
                    <div className="text-xs">
                      <span className="font-semibold text-ink-muted">Purpose: </span>
                      <span className="text-ink">{ev.reason}</span>
                    </div>

                    {/* Cryptographic Footprint */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-line/40 text-2xs">
                      <div className="flex items-center gap-2 font-mono text-ink-light">
                        <span>SHA-256:</span>
                        <span className="bg-surface px-2 py-0.5 rounded border border-line text-ink-muted">
                          {ev.event_hash}
                        </span>
                      </div>
                      <span className="text-emerald-700 font-bold">✓ Immutable Record</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Transfer Modal */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 bg-ink/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-surface border border-line rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-line pb-4">
              <div>
                <h2 className="text-lg font-black text-ink">Transfer Evidence Custody</h2>
                <p className="text-xs text-ink-muted">Record formal physical handover of forensic evidence</p>
              </div>
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="text-ink-muted hover:text-ink text-xl p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleExecuteTransfer} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-ink uppercase block mb-1">
                  Evidence Item to Transfer
                </label>
                <select
                  value={transferEvidenceId}
                  onChange={(e) => setTransferEvidenceId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-canvas font-medium"
                >
                  {evidence.map((ev) => (
                    <option key={ev.evidence_id} value={ev.evidence_id}>
                      {ev.evidence_number} · {ev.substance_claimed || ev.type} ({ev.current_location})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">
                    Current Custodian (From)
                  </label>
                  <input
                    type="text"
                    disabled
                    value={currentUser.name}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-canvas text-ink-muted font-medium cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">
                    Recipient Custodian (To)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sgt. Marcus Vance"
                    value={toUser}
                    onChange={(e) => setToUser(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium focus:ring-2 focus:ring-guard-500/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">
                    From Location
                  </label>
                  <input
                    type="text"
                    required
                    value={fromLocation}
                    onChange={(e) => setFromLocation(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">
                    To Location / Vault
                  </label>
                  <input
                    type="text"
                    required
                    value={toLocation}
                    onChange={(e) => setToLocation(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-ink uppercase block mb-1">
                  Reason for Transfer
                </label>
                <textarea
                  rows={2}
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-guard-50 border border-guard-200">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={digitalAcknowledgement}
                    onChange={(e) => setDigitalAcknowledgement(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-guard-700 focus:ring-guard-500"
                  />
                  <div className="text-xs text-guard-900 leading-snug">
                    <span className="font-bold block">Digital Transfer Attestation</span>
                    I hereby attest under penalty of perjury that physical control and seal integrity of this evidence package was transferred in strict adherence with evidentiary protocols.
                  </div>
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-line">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-line text-sm font-semibold hover:bg-canvas text-ink"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!digitalAcknowledgement}
                  className="px-5 py-2 rounded-lg bg-guard-700 hover:bg-guard-800 disabled:opacity-50 text-white text-sm font-semibold shadow-sm transition-all"
                >
                  Sign & Execute Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default ChainOfCustodyPage;
