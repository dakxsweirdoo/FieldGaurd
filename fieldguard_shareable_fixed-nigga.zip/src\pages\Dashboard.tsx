import { useState, useMemo } from 'react';
import {
  FolderKanban,
  ShieldCheck,
  AlertTriangle,
  FileCheck2,
  Clock,
  Radio,
  FileLock2,
  Boxes,
  TrendingUp,
  Search,
  Filter,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Plus,
} from 'lucide-react';
import { useForensicStore } from '@/lib/forensicStore';
import type { Page, ForensicCase } from '@/types';
import { Panel, PanelHeader } from '@/components/ui/Panel';
import { Badge, StatusDot } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

interface DashboardProps {
  onNavigate: (page: any) => void;
  onSelectCase?: (caseId: string) => void;
  onSelectEvidence?: (evidenceId: string) => void;
}

export function Dashboard({ onNavigate, onSelectCase, onSelectEvidence }: DashboardProps) {
  const { cases, evidence, kits, auditEvents, currentUser } = useForensicStore();

  const [dateFilter, setDateFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Computed Metrics
  const totalCases = cases.length;
  const activeCases = cases.filter((c) => c.status === 'ACTIVE' || c.status === 'TESTING').length;
  const pendingVerification = cases.filter((c) => c.status === 'PENDING_VERIFICATION').length;
  const verifiedCases = cases.filter((c) => c.status === 'VERIFIED').length;
  const sealedEvidence = evidence.filter((e) => e.status === 'SEALED').length;
  const totalAuditEvents = auditEvents.length;
  const totalTests = cases.reduce((acc, c) => acc + (c.test_count || 0), 0);
  const retestRate = '4.2%';
  const aiDisagreementRate = '2.8%';

  // Filtered cases for the dashboard overview table
  const filteredCases = useMemo(() => {
    return cases.filter((c) => {
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (
        searchQuery &&
        !c.case_id.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !c.location_name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !c.assigned_officer.toLowerCase().includes(searchQuery.toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [cases, statusFilter, searchQuery]);

  const recentCases = filteredCases.slice(0, 5);
  const recentAudit = auditEvents.slice(0, 6);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 animate-fade-in">
      {/* COMMAND DASHBOARD HEADER */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-line pb-5">
        <div>
          <div className="flex items-center gap-2 text-2xs font-mono font-bold text-guard-700 tracking-wider uppercase">
            <span className="w-2 h-2 rounded-full bg-guard-600 animate-pulse" />
            Operational Command Center · Station 4 Division
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-ink mt-1">
            Forensic Command Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-ink-muted mt-1">
            Real-time digital evidence integrity monitoring, case progress, and quality-risk oversight.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button size="md" onClick={() => onNavigate('analysis')} className="shadow-sm">
            <Plus size={16} strokeWidth={2.5} />
            Start Field Test
          </Button>
          <Button size="md" variant="secondary" onClick={() => onNavigate('evidence')}>
            <FileLock2 size={16} />
            Evidence Registry
          </Button>
        </div>
      </div>

      {/* 8 PRIMARY COMMAND METRIC CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <MetricCard label="TOTAL CASES" value={totalCases} tone="neutral" />
        <MetricCard label="ACTIVE CASES" value={activeCases} tone="guard" pulse />
        <MetricCard label="PENDING VERIFY" value={pendingVerification} tone="amber" />
        <MetricCard label="VERIFIED" value={verifiedCases} tone="guard" />
        <MetricCard label="RETEST RATE" value={retestRate} tone="neutral" />
        <MetricCard label="AI DISAGREE" value={aiDisagreementRate} tone="info" />
        <MetricCard label="SEALED EVIDENCE" value={sealedEvidence} tone="guard" />
        <MetricCard label="AUDIT EVENTS" value={totalAuditEvents} tone="neutral" />
      </div>

      {/* FORENSIC VISUALIZATION GRIDS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* CHART 1: Test Results Distribution */}
        <Panel className="p-5">
          <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
            <div>
              <span className="section-label">Classification Outcomes</span>
              <h3 className="text-sm font-bold text-ink">Field Test Results Distribution</h3>
            </div>
            <Badge tone="guard">Current Cycle</Badge>
          </div>

          <div className="space-y-3.5">
            <div>
              <div className="flex justify-between text-xs font-semibold text-ink mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" /> Presumptive Positive
                </span>
                <span className="font-mono">58% (7 tests)</span>
              </div>
              <div className="h-2 w-full bg-canvas-warm rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: '58%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-ink mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-guard-600" /> Preliminary Negative
                </span>
                <span className="font-mono">33% (4 tests)</span>
              </div>
              <div className="h-2 w-full bg-canvas-warm rounded-full overflow-hidden">
                <div className="h-full bg-guard-600 rounded-full" style={{ width: '33%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-ink mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-info-500" /> Inconclusive
                </span>
                <span className="font-mono">8% (1 test)</span>
              </div>
              <div className="h-2 w-full bg-canvas-warm rounded-full overflow-hidden">
                <div className="h-full bg-info-500 rounded-full" style={{ width: '8%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-ink mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-alert-500" /> Invalid (Quality Gate)
                </span>
                <span className="font-mono">1% (0 tests)</span>
              </div>
              <div className="h-2 w-full bg-canvas-warm rounded-full overflow-hidden">
                <div className="h-full bg-alert-500 rounded-full" style={{ width: '2%' }} />
              </div>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-line text-2xs text-ink-muted flex items-center justify-between">
            <span>Average Inference Latency: 1.2s</span>
            <span className="font-mono font-semibold text-guard-700">Model: v1.4.2</span>
          </div>
        </Panel>

        {/* CHART 2: Officer Workload & Verification */}
        <Panel className="p-5">
          <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
            <div>
              <span className="section-label">Field Execution</span>
              <h3 className="text-sm font-bold text-ink">Tests by Assigned Officer</h3>
            </div>
            <span className="text-xs font-mono font-semibold text-ink-muted">5 Active</span>
          </div>

          <div className="space-y-3">
            {[
              { name: 'Marcus Vance', badge: 'FG-401', count: 6, verified: '100%' },
              { name: 'Elena Rostova', badge: 'FG-402', count: 4, verified: '100%' },
              { name: 'Sarah Jenkins', badge: 'FG-404', count: 3, verified: '100%' },
              { name: 'Jordan Blake', badge: 'FG-403', count: 2, verified: '100%' },
              { name: 'David Chen', badge: 'FG-405', count: 2, verified: '100%' },
            ].map((officer) => (
              <div key={officer.badge} className="flex items-center justify-between p-2 rounded-lg bg-canvas-warm">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-md bg-surface border border-line flex items-center justify-center text-xs font-bold text-guard-800">
                    {officer.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-ink">{officer.name}</div>
                    <div className="text-2xs font-mono text-ink-light">Badge #{officer.badge}</div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-ink">{officer.count} tests</span>
                  <div className="text-2xs text-guard-600 font-semibold">{officer.verified} Verified</div>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        {/* CHART 3: Kit Inventory & Expiry Health */}
        <Panel className="p-5">
          <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
            <div>
              <span className="section-label">Lot Compliance</span>
              <h3 className="text-sm font-bold text-ink">Test Kit Batch & Expiry Health</h3>
            </div>
            <button
              onClick={() => onNavigate('kits')}
              className="text-xs font-bold text-guard-700 hover:text-guard-800"
            >
              Manage Kits →
            </button>
          </div>

          <div className="space-y-3">
            {kits.slice(0, 4).map((kit) => {
              const isExpired = kit.status === 'EXPIRED';
              return (
                <div
                  key={kit.kit_id}
                  className={`p-3 rounded-lg border ${isExpired ? 'border-alert-200 bg-alert-50/50' : 'border-line bg-surface'
                    }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-ink truncate max-w-[170px]">{kit.kit_type}</span>
                    <Badge tone={isExpired ? 'alert' : kit.status === 'IN_USE' ? 'amber' : 'guard'}>
                      {kit.status}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-2xs text-ink-muted mt-2 font-mono">
                    <span>Batch: {kit.batch_number}</span>
                    <span>Qty: {kit.quantity}</span>
                  </div>
                  <div className="mt-1 flex items-center justify-between text-2xs">
                    <span className={isExpired ? 'text-alert-600 font-bold' : 'text-ink-light'}>
                      Exp: {kit.expiry_date}
                    </span>
                    {isExpired ? (
                      <span className="text-alert-600 font-bold">BLOCKED</span>
                    ) : (
                      <span className="text-guard-600 font-semibold">VALIDATED</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>
      </div>

      {/* FILTER & ACTIVE CASES REGISTRY */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-ink tracking-tight">Active Cases & Field Records</h2>
            <p className="text-xs text-ink-muted">Forensic cases registered in FieldGuard system.</p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-light" />
              <input
                type="text"
                placeholder="Search case, location, officer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-line bg-surface text-ink placeholder:text-ink-light focus:outline-none focus:border-guard-500"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs rounded-lg border border-line bg-surface text-ink font-medium focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="TESTING">Testing</option>
              <option value="PENDING_VERIFICATION">Pending Verification</option>
              <option value="VERIFIED">Verified</option>
              <option value="SEALED">Sealed</option>
            </select>
          </div>
        </div>

        <Panel className="overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-line bg-canvas-warm text-ink-muted">
                  <th className="px-4 py-3 font-bold uppercase tracking-wider">Case ID</th>
                  <th className="px-4 py-3 font-bold uppercase tracking-wider">Type</th>
                  <th className="px-4 py-3 font-bold uppercase tracking-wider">Location</th>
                  <th className="px-4 py-3 font-bold uppercase tracking-wider">Assigned Officer</th>
                  <th className="px-4 py-3 font-bold uppercase tracking-wider">Supervisor</th>
                  <th className="px-4 py-3 font-bold uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 font-bold uppercase tracking-wider text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line-soft">
                {recentCases.map((c) => (
                  <tr
                    key={c.case_id}
                    onClick={() => (onSelectCase ? onSelectCase(c.case_id) : onNavigate('cases'))}
                    className="hover:bg-canvas-warm cursor-pointer transition-colors"
                  >
                    <td className="px-4 py-3 font-mono font-bold text-guard-800">{c.case_id}</td>
                    <td className="px-4 py-3 font-medium text-ink">{c.case_type}</td>
                    <td className="px-4 py-3 text-ink-muted truncate max-w-[220px]">{c.location_name}</td>
                    <td className="px-4 py-3 text-ink">{c.assigned_officer}</td>
                    <td className="px-4 py-3 text-ink-muted">{c.supervisor}</td>
                    <td className="px-4 py-3">
                      <Badge
                        tone={
                          c.status === 'VERIFIED'
                            ? 'guard'
                            : c.status === 'SEALED'
                              ? 'guard'
                              : c.status === 'PENDING_VERIFICATION'
                                ? 'amber'
                                : c.status === 'TESTING'
                                  ? 'info'
                                  : 'neutral'
                        }
                      >
                        {c.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="inline-flex items-center gap-1 text-guard-700 font-semibold hover:underline">
                        Open <ArrowRight size={12} />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>

      {/* RECENT AUDIT TRAIL FEED */}
      <Panel className="p-5">
        <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
          <div className="flex items-center gap-2">
            <FileLock2 size={18} className="text-guard-700" />
            <div>
              <h3 className="text-sm font-bold text-ink">Immutable Audit Trail (Real-Time Feed)</h3>
              <p className="text-2xs text-ink-muted">Cryptographically chained forensic events</p>
            </div>
          </div>
          <Button size="sm" variant="secondary" onClick={() => onNavigate('audit')}>
            View Full Audit Log (/audit)
          </Button>
        </div>

        <div className="space-y-2">
          {recentAudit.map((evt) => (
            <div
              key={evt.event_id}
              className="flex items-center justify-between p-2.5 rounded-lg bg-canvas-warm text-xs font-mono"
            >
              <div className="flex items-center gap-3">
                <span className="w-1.5 h-1.5 rounded-full bg-guard-600" />
                <span className="font-bold text-ink">{evt.action}</span>
                <span className="text-ink-muted">[{evt.entity_id}]</span>
                <span className="hidden md:inline text-ink-soft truncate max-w-md">{evt.new_value}</span>
              </div>
              <div className="text-right text-ink-light shrink-0">
                {new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function MetricCard({
  label,
  value,
  tone = 'neutral',
  pulse = false,
}: {
  label: string;
  value: string | number;
  tone?: 'guard' | 'amber' | 'alert' | 'info' | 'neutral';
  pulse?: boolean;
}) {
  const toneClasses = {
    guard: 'border-guard-200 bg-guard-50/50 text-guard-900',
    amber: 'border-amber-200 bg-amber-50/50 text-amber-900',
    alert: 'border-alert-200 bg-alert-50/50 text-alert-900',
    info: 'border-info-200 bg-info-50/50 text-info-900',
    neutral: 'border-line bg-surface text-ink',
  };

  return (
    <div className={`rounded-xl border p-3 flex flex-col justify-between ${toneClasses[tone]}`}>
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-mono font-bold tracking-wider text-ink-muted uppercase">{label}</span>
        {pulse && <span className="w-1.5 h-1.5 rounded-full bg-guard-600 animate-ping" />}
      </div>
      <div className="text-xl sm:text-2xl font-black font-mono tracking-tight mt-1">{value}</div>
    </div>
  );
}
