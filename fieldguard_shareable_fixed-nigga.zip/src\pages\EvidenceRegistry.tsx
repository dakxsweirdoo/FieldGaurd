import { useState, useMemo } from 'react';
import {
  FileLock2,
  ShieldCheck,
  AlertTriangle,
  History,
  QrCode,
  ArrowRight,
  RefreshCw,
  Eye,
  CheckCircle2,
  XCircle,
  Copy,
  ExternalLink,
  Plus,
  Radio,
  FileCheck,
} from 'lucide-react';
import { useForensicStore } from '@/lib/forensicStore';
import { verifyEvidenceIntegrity } from '@/lib/crypto';
import type { EvidenceItem, Page } from '@/types';
import { Panel, PanelHeader } from '@/components/ui/Panel';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

interface EvidenceRegistryProps {
  onNavigate: (page: any) => void;
  onOpenPublicVerify?: (evidenceId: string) => void;
  selectedEvidenceId?: string | null;
  initialSelectedId?: string | null;
}

export function EvidenceRegistry({
  onNavigate,
  onOpenPublicVerify,
  selectedEvidenceId,
  initialSelectedId: passedInitialId,
}: EvidenceRegistryProps) {
  const initialSelectedId = passedInitialId || selectedEvidenceId;
  const {
    evidence,
    cases,
    registerEvidence,
    createEvidenceVersion,
    simulateTamper,
    restoreAuthentic,
    recordCustody,
    currentUser,
  } = useForensicStore();

  const [selectedId, setSelectedId] = useState<string>(
    initialSelectedId || evidence[0]?.evidence_id || '',
  );
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<{
    verified: boolean;
    storedHash: string;
    currentHash: string;
    statusText: string;
    verifiedAt?: string;
  } | null>(null);

  const [showVersionModal, setShowVersionModal] = useState(false);
  const [versionReason, setVersionReason] = useState('');
  const [versionWeight, setVersionWeight] = useState('');

  const [showTransferModal, setShowTransferModal] = useState(false);
  const [transferRecipient, setTransferRecipient] = useState('Lt. Raymond Miller');
  const [transferLocation, setTransferLocation] = useState('Central Forensics Vault');
  const [transferReason, setTransferReason] = useState('Custody transfer for chemical validation');

  const selectedItem = useMemo(() => {
    return evidence.find((e) => e.evidence_id === selectedId) || evidence[0];
  }, [evidence, selectedId]);

  const filteredEvidence = useMemo(() => {
    return evidence.filter((item) => {
      if (filterStatus !== 'all' && item.status !== filterStatus) return false;
      if (
        search &&
        !item.evidence_id.toLowerCase().includes(search.toLowerCase()) &&
        !item.case_id.toLowerCase().includes(search.toLowerCase()) &&
        !item.description.toLowerCase().includes(search.toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [evidence, filterStatus, search]);

  const runIntegrityCheck = async () => {
    if (!selectedItem) return;
    setIsVerifying(true);
    // Simulate brief cryptographic check animation
    await new Promise((r) => setTimeout(r, 450));
    const res = await verifyEvidenceIntegrity(selectedItem);
    setVerificationResult(res);
    setIsVerifying(false);
  };

  const handleSimulateTamper = () => {
    if (!selectedItem) return;
    simulateTamper(
      selectedItem.evidence_id,
      'description',
      'TAMPERED: 50.0g Unidentified powder (Altered illicitly without updating SHA-256 seal)',
    );
    setVerificationResult(null);
  };

  const handleRestore = () => {
    if (!selectedItem) return;
    restoreAuthentic(selectedItem.evidence_id);
    setVerificationResult(null);
  };

  const handleCreateVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem || !versionReason) return;
    await createEvidenceVersion(
      selectedItem.evidence_id,
      {
        description: `${selectedItem.description} [Amendment: Net weight verified as ${versionWeight || 'recalibrated'}]`,
      },
      versionReason,
    );
    setShowVersionModal(false);
    setVersionReason('');
    setVersionWeight('');
    setVerificationResult(null);
  };

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;
    recordCustody({
      evidence_id: selectedItem.evidence_id,
      case_id: selectedItem.case_id,
      from_user: currentUser.full_name,
      to_user: transferRecipient,
      from_location: selectedItem.collection_location,
      to_location: transferLocation,
      action: 'TRANSFERRED',
      reason: transferReason,
    });
    setShowTransferModal(false);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 animate-fade-in">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-line pb-4">
        <div>
          <div className="flex items-center gap-2 text-2xs font-mono font-bold text-guard-700 tracking-wider uppercase">
            <ShieldCheck size={14} />
            Cryptographic Integrity Subsystem · SHA-256 Engine
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-ink mt-1">
            Forensic Evidence Registry
          </h1>
          <p className="text-xs sm:text-sm text-ink-muted mt-1">
            Tamper-traceable evidence registry with immutable versions, cryptographic hashes, and custody chaining.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button size="md" variant="secondary" onClick={() => onNavigate('custody')}>
            View Custody Timeline
          </Button>
          <Button size="md" onClick={() => onNavigate('analysis')}>
            <Plus size={16} strokeWidth={2.5} />
            New Field Test
          </Button>
        </div>
      </div>

      {/* REGISTRY LAYOUT: MASTER-DETAIL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: EVIDENCE LIST */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search evidence ID, case, substance..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-line bg-surface text-ink placeholder:text-ink-light focus:outline-none focus:border-guard-500"
            />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-2.5 py-2 text-xs rounded-lg border border-line bg-surface text-ink focus:outline-none"
            >
              <option value="all">All</option>
              <option value="VERIFIED">Verified</option>
              <option value="SEALED">Sealed</option>
              <option value="TESTED">Tested</option>
              <option value="COLLECTED">Collected</option>
            </select>
          </div>

          <div className="space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto scrollbar-thin pr-1">
            {filteredEvidence.map((item) => {
              const isSelected = item.evidence_id === selectedItem?.evidence_id;
              return (
                <button
                  key={item.evidence_id}
                  onClick={() => {
                    setSelectedId(item.evidence_id);
                    setVerificationResult(null);
                  }}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                    isSelected
                      ? 'border-guard-600 bg-guard-50/40 shadow-sm'
                      : 'border-line bg-surface hover:border-line-strong'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-guard-800">{item.evidence_id}</span>
                    <Badge
                      tone={
                        item.is_tampered
                          ? 'alert'
                          : item.status === 'SEALED' || item.status === 'VERIFIED'
                          ? 'guard'
                          : 'amber'
                      }
                    >
                      {item.is_tampered ? 'TAMPER ALERT' : item.status}
                    </Badge>
                  </div>

                  <p className="text-xs font-semibold text-ink mt-1 truncate">{item.evidence_type}</p>

                  <div className="flex items-center justify-between text-2xs text-ink-muted mt-2 font-mono">
                    <span>Case: {item.case_id}</span>
                    <span>Version v{item.current_version}</span>
                  </div>

                  <div className="mt-2 pt-2 border-t border-line-soft flex items-center justify-between text-2xs text-ink-light font-mono">
                    <span className="truncate max-w-[200px]">SHA-256: {item.sha256_hash.substring(0, 16)}...</span>
                    <span>{new Date(item.collection_timestamp).toLocaleDateString()}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: EVIDENCE DETAIL & INTEGRITY CHECK PANEL */}
        {selectedItem ? (
          <div className="lg:col-span-7 space-y-5">
            {/* EVIDENCE RECORD HEADER */}
            <Panel className="p-5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-line pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-black font-mono tracking-tight text-ink">
                      {selectedItem.evidence_id}
                    </h2>
                    <Badge
                      tone={
                        selectedItem.is_tampered
                          ? 'alert'
                          : selectedItem.status === 'SEALED'
                          ? 'guard'
                          : 'neutral'
                      }
                    >
                      {selectedItem.is_tampered ? 'INTEGRITY COMPROMISED' : selectedItem.status}
                    </Badge>
                    <span className="text-2xs font-mono font-bold px-2 py-0.5 rounded bg-canvas-warm text-ink-muted border border-line">
                      v{selectedItem.current_version}
                    </span>
                  </div>
                  <p className="text-xs text-ink-muted mt-1">
                    Associated Case: <span className="font-mono font-bold text-guard-800">{selectedItem.case_id}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      onOpenPublicVerify
                        ? onOpenPublicVerify(selectedItem.evidence_id)
                        : onNavigate('verify')
                    }
                  >
                    <QrCode size={14} />
                    Public QR Verification
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => setShowTransferModal(true)}>
                    Transfer Custody
                  </Button>
                </div>
              </div>

              {/* LIVE INTEGRITY VERIFICATION BANNER */}
              <div className="mt-4">
                {selectedItem.is_tampered ? (
                  <div className="p-4 rounded-xl border-2 border-alert-400 bg-alert-50/80 animate-slide-up">
                    <div className="flex items-start gap-3">
                      <XCircle size={22} className="text-alert-600 shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-black tracking-wide text-alert-700 uppercase">
                            ⚠ EVIDENCE INTEGRITY CHECK FAILED
                          </h4>
                          <span className="text-2xs font-mono px-2 py-0.5 rounded bg-alert-200 text-alert-800 font-bold">
                            HASH MISMATCH DETECTED
                          </span>
                        </div>
                        <p className="text-xs text-alert-700 mt-1 leading-relaxed">
                          Cryptographic recalculation does not match the stored SHA-256 seal. Forensic record
                          tampering has been simulated or detected on field:{' '}
                          <span className="font-mono font-bold">[{selectedItem.tampered_field}]</span>.
                        </p>

                        <div className="mt-3 p-2.5 rounded-lg bg-white/80 border border-alert-200 text-2xs font-mono space-y-1">
                          <div className="text-ink-muted">
                            Authentic Hash: <span className="text-guard-700">{selectedItem.sha256_hash}</span>
                          </div>
                          <div className="text-alert-700 font-bold">
                            Recalculated:{' '}
                            <span>9f9872bc194a02... (Cryptographic hash corrupted by modification)</span>
                          </div>
                        </div>

                        <div className="mt-3 flex items-center gap-2">
                          <Button size="sm" variant="secondary" onClick={handleRestore}>
                            Restore Authentic Forensic Record
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : verificationResult?.verified ? (
                  <div className="p-4 rounded-xl border border-guard-400 bg-guard-50/80 animate-slide-up flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 size={22} className="text-guard-600 shrink-0" />
                      <div>
                        <h4 className="text-xs font-bold text-guard-800 uppercase tracking-wide">
                          ✓ Evidence Integrity Verified
                        </h4>
                        <p className="text-2xs text-guard-700 font-mono mt-0.5">
                          Cryptographic SHA-256 matches authentic stored forensic record.
                        </p>
                      </div>
                    </div>
                    <span className="text-2xs font-mono text-guard-800 font-bold">
                      {new Date(verificationResult.verifiedAt || Date.now()).toLocaleTimeString()}
                    </span>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl border border-line bg-canvas-warm flex items-center justify-between">
                    <div className="flex items-center gap-2.5 text-xs text-ink-muted">
                      <FileLock2 size={16} className="text-guard-700" />
                      <span>Stored Seal:</span>
                      <span className="font-mono font-bold text-ink truncate max-w-sm">
                        {selectedItem.sha256_hash}
                      </span>
                    </div>

                    <Button size="sm" variant="secondary" onClick={runIntegrityCheck} disabled={isVerifying}>
                      <RefreshCw size={13} className={isVerifying ? 'animate-spin' : ''} />
                      Verify Integrity Live
                    </Button>
                  </div>
                )}
              </div>

              {/* EVIDENCE ATTRIBUTES GRID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 mt-5 pt-5 border-t border-line text-xs">
                <div>
                  <span className="data-label">Sample ID</span>
                  <p className="font-mono font-bold text-ink mt-0.5">{selectedItem.sample_id}</p>
                </div>
                <div>
                  <span className="data-label">Evidence Type</span>
                  <p className="font-semibold text-ink mt-0.5">{selectedItem.evidence_type}</p>
                </div>
                <div>
                  <span className="data-label">Collected By</span>
                  <p className="text-ink mt-0.5">{selectedItem.collected_by}</p>
                </div>
                <div>
                  <span className="data-label">Collection Timestamp</span>
                  <p className="font-mono text-ink mt-0.5">{new Date(selectedItem.collection_timestamp).toLocaleString()}</p>
                </div>
                <div>
                  <span className="data-label">Location & Coordinates</span>
                  <p className="text-ink mt-0.5">
                    {selectedItem.collection_location}
                    <span className="font-mono text-2xs text-ink-light block">
                      GPS: {selectedItem.gps_coordinates.lat.toFixed(4)}, {selectedItem.gps_coordinates.lng.toFixed(4)}
                    </span>
                  </p>
                </div>
                <div>
                  <span className="data-label">Device Hardware ID</span>
                  <p className="font-mono text-ink mt-0.5">{selectedItem.device_id}</p>
                </div>
                <div>
                  <span className="data-label">Kit Lot & Batch</span>
                  <p className="font-mono text-ink mt-0.5">{selectedItem.kit_batch_number || 'N/A'}</p>
                </div>
                <div>
                  <span className="data-label">Hash Algorithm</span>
                  <p className="font-mono font-bold text-guard-700 mt-0.5">{selectedItem.hash_algorithm}</p>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-line">
                <span className="data-label">Description & Physical Characteristics</span>
                <p className="text-xs text-ink-soft leading-relaxed mt-1 p-3 rounded-lg bg-canvas-warm border border-line-soft">
                  {selectedItem.description}
                </p>
              </div>

              {/* DEMO TAMPER TRIGGER ("WOW MOMENT" DEMO) */}
              <div className="mt-5 p-4 rounded-xl border border-amber-300 bg-amber-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 uppercase tracking-wide">
                    <AlertTriangle size={14} className="text-amber-600" />
                    Forensic Proof: Interactive Tamper Demonstration
                  </div>
                  <p className="text-2xs text-amber-800 mt-0.5">
                    Demonstrates system detecting any unauthorized modification against the SHA-256 seal.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {!selectedItem.is_tampered ? (
                    <button
                      onClick={handleSimulateTamper}
                      className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors shadow-sm"
                    >
                      Simulate Tampering
                    </button>
                  ) : (
                    <button
                      onClick={handleRestore}
                      className="px-3 py-1.5 rounded-lg bg-guard-700 hover:bg-guard-800 text-white text-xs font-bold transition-colors shadow-sm"
                    >
                      Restore Authentic
                    </button>
                  )}
                </div>
              </div>
            </Panel>

            {/* VERSION HISTORY PANEL (IMMUTABLE) */}
            <Panel className="p-5">
              <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <History size={16} className="text-guard-700" />
                  <div>
                    <h3 className="text-sm font-bold text-ink">Immutable Version Audit Trail</h3>
                    <p className="text-2xs text-ink-muted">Original records are never deleted or overwritten</p>
                  </div>
                </div>

                <Button size="sm" variant="secondary" onClick={() => setShowVersionModal(true)}>
                  <Plus size={13} />
                  Add Amended Version
                </Button>
              </div>

              <div className="space-y-3">
                {selectedItem.versions.map((v) => (
                  <div key={v.version_number} className="p-3 rounded-lg border border-line bg-canvas-warm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-guard-800">Version v{v.version_number}</span>
                        <span className="text-2xs text-ink-muted font-semibold">by {v.modified_by}</span>
                      </div>
                      <span className="text-2xs font-mono text-ink-light">{new Date(v.timestamp).toLocaleString()}</span>
                    </div>

                    <p className="text-xs text-ink mt-1.5 font-medium">{v.reason}</p>

                    <div className="mt-2 text-2xs font-mono text-ink-muted bg-surface p-1.5 rounded border border-line-soft truncate">
                      SHA-256 Seal: {v.sha256_hash}
                    </div>
                  </div>
                ))}
              </div>
            </Panel>
          </div>
        ) : (
          <div className="lg:col-span-7 flex items-center justify-center p-12 border border-line rounded-xl bg-surface">
            <p className="text-sm text-ink-muted">Select an evidence item from the registry</p>
          </div>
        )}
      </div>

      {/* AMENDED VERSION MODAL */}
      {showVersionModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-surface border border-line rounded-2xl p-6 max-w-md w-full shadow-xl space-y-4">
            <h3 className="text-base font-bold text-ink">Create Amended Evidence Version</h3>
            <p className="text-xs text-ink-muted leading-relaxed">
              Forensic standards require that the original evidence record is never altered. Adding a correction
              generates Version v{(selectedItem?.current_version || 1) + 1} with a new cryptographic hash while
              preserving previous versions.
            </p>

            <form onSubmit={handleCreateVersion} className="space-y-3">
              <div>
                <label className="data-label block mb-1">Reason for Amendment / Correction</label>
                <textarea
                  required
                  placeholder="e.g. Lab confirmation added secondary net weight verification..."
                  value={versionReason}
                  onChange={(e) => setVersionReason(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
                  rows={3}
                />
              </div>

              <div>
                <label className="data-label block mb-1">Calibrated Net Weight (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. 24.62g"
                  value={versionWeight}
                  onChange={(e) => setVersionWeight(e.target.value)}
                  className="w-full p-2 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button size="sm" variant="ghost" type="button" onClick={() => setShowVersionModal(false)}>
                  Cancel
                </Button>
                <Button size="sm" type="submit">
                  Seal Version v{(selectedItem?.current_version || 1) + 1}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TRANSFER CUSTODY MODAL */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-surface border border-line rounded-2xl p-6 max-w-md w-full shadow-xl space-y-4">
            <h3 className="text-base font-bold text-ink">Record Chain of Custody Transfer</h3>
            <p className="text-xs text-ink-muted leading-relaxed">
              Transfers create an auditable, cryptographically sealed custody transaction in the permanent evidence log.
            </p>

            <form onSubmit={handleTransfer} className="space-y-3">
              <div>
                <label className="data-label block mb-1">Receiving Officer / Custodian</label>
                <input
                  required
                  type="text"
                  value={transferRecipient}
                  onChange={(e) => setTransferRecipient(e.target.value)}
                  className="w-full p-2 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
                />
              </div>

              <div>
                <label className="data-label block mb-1">Destination Facility / Locker</label>
                <input
                  required
                  type="text"
                  value={transferLocation}
                  onChange={(e) => setTransferLocation(e.target.value)}
                  className="w-full p-2 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
                />
              </div>

              <div>
                <label className="data-label block mb-1">Reason for Custody Transfer</label>
                <input
                  required
                  type="text"
                  value={transferReason}
                  onChange={(e) => setTransferReason(e.target.value)}
                  className="w-full p-2 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button size="sm" variant="ghost" type="button" onClick={() => setShowTransferModal(false)}>
                  Cancel
                </Button>
                <Button size="sm" type="submit">
                  Execute Digital Transfer
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
