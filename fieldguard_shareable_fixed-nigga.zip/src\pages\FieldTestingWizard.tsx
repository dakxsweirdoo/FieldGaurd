import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  Upload,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Play,
  ArrowRight,
  ArrowLeft,
  ScanLine,
  Sliders,
  ShieldCheck,
  Check,
  RotateCcw,
  Sparkles,
  QrCode,
  Download,
  AlertCircle,
  FileCheck2,
} from 'lucide-react';
import { useForensicStore } from '@/lib/forensicStore';
import { generateEvidenceHash } from '@/lib/crypto';
import { downloadNarcovexReport } from '@/lib/fieldguardReport';
import type {
  Page,
  ForensicCase,
  EvidenceItem,
  TestKit,
  QualityCheckStatus,
  ImageQualityReport,
  ColorCalibration,
  AnalysisResult,
  CaseRecord,
} from '@/types';
import { Panel, PanelHeader } from '@/components/ui/Panel';
import { Badge, StatusDot } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

interface FieldTestingWizardProps {
  onNavigate: (page: any) => void;
  onOpenPublicVerify?: (evidenceId: string) => void;
  onComplete?: () => void;
  apiOnline?: boolean;
}

const STEPS = [
  'Case Select',
  'Evidence Select',
  'Kit Select',
  'Batch Check',
  'Expiry Check',
  'Capture Image',
  'Quality Check',
  'Calibration',
  'AI Analysis',
  'Officer Review',
  'Supervisor Sign',
  'Finalize & Seal',
];

export function FieldTestingWizard({ onNavigate, onOpenPublicVerify, apiOnline }: FieldTestingWizardProps) {
  const { cases, evidence, kits, currentUser, updateCase, verifyEvidence, recordCustody, recordAudit } =
    useForensicStore();

  const [currentStep, setCurrentStep] = useState(1);

  // Step 1: Case
  const [selectedCaseId, setSelectedCaseId] = useState<string>(cases[0]?.case_id || '');

  // Step 2: Evidence
  const availableEvidence = evidence.filter((e) => e.case_id === selectedCaseId);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string>(
    availableEvidence[0]?.evidence_id || evidence[0]?.evidence_id || '',
  );

  // Step 3, 4, 5: Kit
  const [selectedKitId, setSelectedKitId] = useState<string>(kits[0]?.kit_id || '');
  const selectedKit = kits.find((k) => k.kit_id === selectedKitId);
  const [batchConfirmed, setBatchConfirmed] = useState(false);

  // Step 6: Image Capture
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Step 7: Image Quality
  const [qualityReport, setQualityReport] = useState<ImageQualityReport | null>(null);
  const [isCheckingQuality, setIsCheckingQuality] = useState(false);

  // Step 8: Color Calibration
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibrationData, setCalibrationData] = useState<ColorCalibration | null>(null);

  // Step 9: AI Analysis
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState<{
    classification: string;
    confidence: number;
    model: string;
    modelVersion: string;
    decisionNotice: string;
    probabilities: Record<string, number>;
  } | null>(null);

  // Step 10: Officer Review
  const [officerDecision, setOfficerDecision] = useState<'CONFIRM' | 'REJECT' | 'REQUEST_RETEST'>('CONFIRM');
  const [officerReason, setOfficerReason] = useState('');

  // Step 11: Supervisor Verification
  const [supervisorDecision, setSupervisorDecision] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [supervisorNotes, setSupervisorNotes] = useState('');

  // Step 12: Finalized State
  const [isFinalized, setIsFinalized] = useState(false);
  const [finalizedHash, setFinalizedHash] = useState('');

  // Update selected evidence when case changes
  useEffect(() => {
    const items = evidence.filter((e) => e.case_id === selectedCaseId);
    if (items.length > 0 && !items.find((i) => i.evidence_id === selectedEvidenceId)) {
      setSelectedEvidenceId(items[0].evidence_id);
    }
  }, [selectedCaseId, evidence, selectedEvidenceId]);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
      setImageFile(file);
    };
    reader.readAsDataURL(file);
  };

  // Perform Image Quality Check (Step 7)
  const runQualityCheck = async () => {
    setIsCheckingQuality(true);
    await new Promise((r) => setTimeout(r, 600));

    // Automated quality metrics
    const report: ImageQualityReport = {
      overall: 'GOOD',
      resolution_ok: true,
      lighting_ok: true,
      blur_ok: true,
      color_reference_ok: true,
      metrics: {
        brightness: 74,
        contrast: 82,
        sharpness: 91,
        resolution: '1920 × 1080 px',
      },
      message: 'Image satisfies all forensic sharpness, contrast, and color-reference standards.',
    };

    setQualityReport(report);
    setIsCheckingQuality(false);
  };

  // Perform Color Calibration (Step 8)
  const runCalibration = async () => {
    setIsCalibrating(true);
    await new Promise((r) => setTimeout(r, 700));

    setCalibrationData({
      calibration_id: `CAL-${Date.now().toString(36).toUpperCase()}`,
      reference_profile: 'Standard D65 Forensic Reference Card #04',
      lighting_condition: '5500K Daylight Normalized',
      white_balance: 'Auto-Calibrated (ΔE < 1.2)',
      exposure: 'Ev +0.00 (Neutral)',
      image_hash: '9a87bf104829104c8102938471029384',
      timestamp: new Date().toISOString(),
    });

    setIsCalibrating(false);
  };

  // Perform AI Analysis (Step 9)
  const runAiAnalysis = async () => {
    setIsAnalyzing(true);
    await new Promise((r) => setTimeout(r, 850));

    setAiResult({
      classification: 'PRESUMPTIVE POSITIVE',
      confidence: 91.4,
      model: 'FieldGuard Vision',
      modelVersion: '1.4.2',
      decisionNotice:
        'FieldGuard Vision provides preliminary decision support for field personnel. A presumptive positive is not a legal or chemical confirmation.',
      probabilities: {
        'Presumptive Positive': 0.914,
        'Preliminary Negative': 0.052,
        Inconclusive: 0.034,
      },
    });

    setIsAnalyzing(false);
  };

  // Finalize Test (Step 12)
  const handleFinalize = async () => {
    const timestamp = new Date().toISOString();
    const hash = await generateEvidenceHash({
      evidence_id: selectedEvidenceId,
      case_id: selectedCaseId,
      kit_batch_number: selectedKit?.batch_number,
    });

    setFinalizedHash(hash);
    setIsFinalized(true);

    // Update case status to VERIFIED
    updateCase(selectedCaseId, { status: 'VERIFIED' });

    // Update evidence verification
    verifyEvidence({
      evidence_id: selectedEvidenceId,
      case_id: selectedCaseId,
      stage: 'SUPERVISOR',
      decision: 'CONFIRM',
      reason: 'Dual officer and supervisor forensic verification finalized and sealed.',
    });

    // Record custody sealing event
    recordCustody({
      evidence_id: selectedEvidenceId,
      case_id: selectedCaseId,
      from_user: currentUser.full_name,
      to_user: 'Central Evidence Vault',
      from_location: 'Mobile Forensic Unit',
      to_location: 'Station 4 Secure Vault',
      action: 'SEALED',
      reason: 'Forensic field test finalized with cryptographic SHA-256 seal',
    });

    // Record audit event
    recordAudit({
      action: 'EVIDENCE_SEALED',
      entity_type: 'EVIDENCE',
      entity_id: selectedEvidenceId,
      new_value: `Finalized test with SHA-256: ${hash}`,
      hash_reference: hash,
    });
  };

  const handleDownloadPdf = async () => {
    const activeCase = cases.find((c) => c.case_id === selectedCaseId);
    const mockCaseRecord: CaseRecord = {
      case_id: selectedCaseId,
      timestamp: new Date().toISOString(),
      image_filename: imageFile?.name || 'field_specimen_0184.jpg',
      image_sha256: finalizedHash || '8a72c4f0391d4e21a8d0e72bf8910041ac8479e19d71c4974910a34b22c98d01',
      final_result: 'PRESUMPTIVE POSITIVE',
      raw_prediction: 'POSITIVE',
      raw_confidence: 91.4,
      quality_risk: 4.8,
      quality_gate: 'ACCEPTABLE',
      quality_metrics: {
        brightness: 74,
        contrast: 82,
        sharpness: 91,
        resolution: '1920 × 1080',
      },
      sensor_available: false,
      sensor_class: null,
      sensor_confidence: null,
      sensor_readings: [],
      evidence_mode: 'VISION_ONLY',
      probabilities: {
        POSITIVE: 0.914,
        NEGATIVE: 0.052,
        INCONCLUSIVE: 0.034,
        INVALID: 0.0,
      },
      reason:
        'Optical spectral colorimetric analysis matches positive cobalt/reagent standard reaction with 91.4% model confidence.',
      warnings: [],
      audit_status: 'RECORDED',
    };

    let blob: Blob | null = null;
    if (imagePreview) {
      const resp = await fetch(imagePreview);
      blob = await resp.blob();
    }

    await downloadNarcovexReport({
      result: {
        final_result: 'PRESUMPTIVE POSITIVE',
        evidence_mode: 'VISION_ONLY',
        reason: mockCaseRecord.reason,
        vision: {
          quality_risk: 0.048,
          quality_gate: 'ACCEPTABLE',
          quality_reason: 'Quality standards met',
          raw_class: 'POSITIVE',
          confidence: 0.914,
          probabilities: mockCaseRecord.probabilities,
          quality_metrics: mockCaseRecord.quality_metrics,
        },
        sensor: {
          available: false,
          signal_class: null,
          confidence: null,
          status: 'UNAVAILABLE',
          readings: [],
        },
        image_sha256: mockCaseRecord.image_sha256 || '',
        warnings: [],
        case_id: selectedCaseId,
      },
      imageBlob: blob,
      imageFilename: imageFile?.name || 'field_specimen_0184.jpg',
    });
  };

  const isKitExpired = selectedKit?.status === 'EXPIRED';

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-6 space-y-6 animate-fade-in">
      {/* WIZARD HEADER */}
      <div className="border-b border-line pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-2xs font-mono font-bold text-guard-700 uppercase tracking-wider">
            <ScanLine size={14} />
            Forensic Field Protocol · Guided 12-Step Chain
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-ink mt-1">
            Guided Field Testing Workflow
          </h1>
          <p className="text-xs sm:text-sm text-ink-muted mt-1">
            Step-by-step verifiable testing protocol ensuring batch validity, quality gating, and dual verification.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge tone="guard">Step {currentStep} of 12</Badge>
          <span className="text-xs font-mono font-bold text-ink-muted">{STEPS[currentStep - 1]}</span>
        </div>
      </div>

      {/* STEP PROGRESS BAR */}
      <div className="bg-surface border border-line rounded-xl p-3 overflow-x-auto scrollbar-thin">
        <div className="flex items-center gap-1.5 min-w-[800px]">
          {STEPS.map((name, idx) => {
            const stepNum = idx + 1;
            const isDone = stepNum < currentStep;
            const isCurrent = stepNum === currentStep;
            return (
              <div key={name} className="flex-1 flex items-center">
                <div
                  className={`w-full py-1.5 px-2 rounded-lg text-center text-2xs font-mono font-bold transition-all ${
                    isDone
                      ? 'bg-guard-100 text-guard-800'
                      : isCurrent
                      ? 'bg-guard-700 text-white shadow-sm'
                      : 'bg-canvas-warm text-ink-light'
                  }`}
                >
                  <span className="mr-1">{stepNum.toString().padStart(2, '0')}</span>
                  <span className="truncate hidden sm:inline">{name}</span>
                </div>
                {idx < STEPS.length - 1 && <div className="w-1 h-0.5 bg-line mx-0.5" />}
              </div>
            );
          })}
        </div>
      </div>

      {/* STEP CONTAINER */}
      <Panel className="p-6 min-h-[440px] flex flex-col justify-between">
        {/* STEP 1: SELECT CASE */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 01</span>
              <h2 className="text-lg font-bold text-ink">Select Active Case File</h2>
              <p className="text-xs text-ink-muted mt-1">Choose the case to which field evidence belongs.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {cases.slice(0, 6).map((c) => (
                <button
                  key={c.case_id}
                  onClick={() => setSelectedCaseId(c.case_id)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    selectedCaseId === c.case_id
                      ? 'border-guard-600 bg-guard-50/50 shadow-sm'
                      : 'border-line bg-surface hover:border-line-strong'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-guard-800">{c.case_id}</span>
                    <Badge tone="guard">{c.status}</Badge>
                  </div>
                  <div className="text-xs font-semibold text-ink mt-1">{c.case_type}</div>
                  <p className="text-2xs text-ink-muted mt-1 truncate">{c.location_name}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 2: SELECT EVIDENCE */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 02</span>
              <h2 className="text-lg font-bold text-ink">Select Evidence Item</h2>
              <p className="text-xs text-ink-muted mt-1">
                Selected Case: <span className="font-mono font-bold text-guard-800">{selectedCaseId}</span>
              </p>
            </div>

            {availableEvidence.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-line rounded-xl">
                <p className="text-xs text-ink-muted">No evidence registered under this case yet.</p>
                <Button size="sm" className="mt-3" onClick={() => onNavigate('evidence')}>
                  Register Evidence
                </Button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {availableEvidence.map((e) => (
                  <button
                    key={e.evidence_id}
                    onClick={() => setSelectedEvidenceId(e.evidence_id)}
                    className={`w-full p-4 rounded-xl border text-left transition-all ${
                      selectedEvidenceId === e.evidence_id
                        ? 'border-guard-600 bg-guard-50/50 shadow-sm'
                        : 'border-line bg-surface hover:border-line-strong'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-guard-800">{e.evidence_id}</span>
                      <Badge tone="guard">{e.status}</Badge>
                    </div>
                    <div className="text-xs font-semibold text-ink mt-1">{e.evidence_type}</div>
                    <p className="text-2xs text-ink-muted mt-1">{e.description}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* STEP 3: SELECT TEST KIT */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 03</span>
              <h2 className="text-lg font-bold text-ink">Select Colorimetric Test Kit</h2>
              <p className="text-xs text-ink-muted mt-1">
                Select from verified inventory kits. Expired or depleted kits are blocked automatically.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {kits.map((kit) => (
                <button
                  key={kit.kit_id}
                  onClick={() => setSelectedKitId(kit.kit_id)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    selectedKitId === kit.kit_id
                      ? 'border-guard-600 bg-guard-50/50 shadow-sm'
                      : 'border-line bg-surface hover:border-line-strong'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-ink">{kit.kit_type}</span>
                    <Badge tone={kit.status === 'EXPIRED' ? 'alert' : 'guard'}>{kit.status}</Badge>
                  </div>
                  <div className="text-2xs text-ink-muted mt-1 font-mono">
                    Batch: {kit.batch_number} · Exp: {kit.expiry_date}
                  </div>
                  <p className="text-2xs text-ink-light mt-1">{kit.target_substance}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 4: VERIFY KIT BATCH */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 04</span>
              <h2 className="text-lg font-bold text-ink">Verify Test Kit Batch & Lot Integrity</h2>
              <p className="text-xs text-ink-muted mt-1">
                Compare physical vial labeling against system batch records.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-canvas-warm border border-line space-y-3">
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <span className="data-label">Selected Kit</span>
                  <p className="font-bold text-ink mt-0.5">{selectedKit?.kit_type}</p>
                </div>
                <div>
                  <span className="data-label">Manufacturer</span>
                  <p className="text-ink mt-0.5">{selectedKit?.manufacturer}</p>
                </div>
                <div>
                  <span className="data-label">Batch Number</span>
                  <p className="font-bold text-guard-800 mt-0.5">{selectedKit?.batch_number}</p>
                </div>
                <div>
                  <span className="data-label">Lot Number</span>
                  <p className="font-bold text-ink mt-0.5">{selectedKit?.lot_number}</p>
                </div>
              </div>

              <div className="pt-3 border-t border-line-soft">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={batchConfirmed}
                    onChange={(e) => setBatchConfirmed(e.target.checked)}
                    className="w-4 h-4 rounded border-line text-guard-600 focus:ring-guard-500"
                  />
                  <span className="text-xs font-semibold text-ink">
                    I confirm that the physical ampoule batch number matches {selectedKit?.batch_number}
                  </span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: VERIFY KIT EXPIRY */}
        {currentStep === 5 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 05</span>
              <h2 className="text-lg font-bold text-ink">Enforce Kit Shelf-Life Policy</h2>
              <p className="text-xs text-ink-muted mt-1">
                System validates that testing reagents remain chemically active.
              </p>
            </div>

            {isKitExpired ? (
              <div className="p-5 rounded-xl border-2 border-alert-400 bg-alert-50 text-alert-800 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-alert-700">
                  <XCircle size={18} />
                  KIT EXPIRED — FIELD TESTING BLOCKED
                </div>
                <p className="text-xs leading-relaxed">
                  Kit <span className="font-mono font-bold">{selectedKit?.kit_id}</span> expired on{' '}
                  <span className="font-mono font-bold">{selectedKit?.expiry_date}</span>. Testing with expired
                  reagents produces unscientific, legally inadmissible results.
                </p>
                <div className="pt-2">
                  <Button size="sm" variant="secondary" onClick={() => setCurrentStep(3)}>
                    Return & Select Valid Kit
                  </Button>
                </div>
              </div>
            ) : (
              <div className="p-5 rounded-xl border border-guard-300 bg-guard-50 text-guard-900 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-guard-800">
                  <CheckCircle2 size={18} className="text-guard-600" />
                  KIT VALIDATED — EXPIRATION VERIFIED
                </div>
                <p className="text-xs leading-relaxed font-mono">
                  Expiry Date: {selectedKit?.expiry_date} · Status: ACTIVE · Storage: Validated
                </p>
              </div>
            )}
          </div>
        )}

        {/* STEP 6: CAPTURE IMAGE */}
        {currentStep === 6 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 06</span>
              <h2 className="text-lg font-bold text-ink">Capture Field Reaction Image</h2>
              <p className="text-xs text-ink-muted mt-1">
                Photograph reaction vial against neutral card or upload camera file.
              </p>
            </div>

            {!imagePreview ? (
              <div className="border-2 border-dashed border-line rounded-xl p-8 text-center bg-canvas-warm space-y-3">
                <div className="w-12 h-12 rounded-xl bg-surface border border-line flex items-center justify-center mx-auto text-ink-muted">
                  <Camera size={22} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-ink">Take high-resolution photo of reaction vial</p>
                  <p className="text-2xs text-ink-muted mt-0.5">Ensure color reference card is visible</p>
                </div>

                <div className="flex items-center justify-center gap-2">
                  <Button size="sm" onClick={() => fileInputRef.current?.click()}>
                    <Upload size={14} /> Browse Photo
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => cameraInputRef.current?.click()}>
                    <Camera size={14} /> Camera Capture
                  </Button>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                />
                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                />
              </div>
            ) : (
              <div className="p-4 rounded-xl border border-line bg-canvas-warm flex flex-col sm:flex-row items-center gap-4">
                <img src={imagePreview} alt="Captured specimen" className="w-48 h-36 object-contain rounded-lg border bg-surface" />
                <div className="space-y-2 flex-1">
                  <Badge tone="guard">Image Loaded</Badge>
                  <p className="text-xs font-mono text-ink-muted">{imageFile?.name || 'captured_reaction.jpg'}</p>
                  <Button size="sm" variant="ghost" onClick={() => setImagePreview(null)}>
                    Recapture
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 7: IMAGE QUALITY ANALYSIS */}
        {currentStep === 7 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 07</span>
              <h2 className="text-lg font-bold text-ink">Image Quality Analysis</h2>
              <p className="text-xs text-ink-muted mt-1">
                Automated pre-inference gate for blur, lighting, exposure, and color reference card.
              </p>
            </div>

            {!qualityReport ? (
              <div className="p-8 text-center border border-line rounded-xl bg-canvas-warm space-y-3">
                <p className="text-xs text-ink-muted">Run quality analysis before AI processing</p>
                <Button size="sm" onClick={runQualityCheck} disabled={isCheckingQuality}>
                  <Sparkles size={14} className={isCheckingQuality ? 'animate-spin' : ''} />
                  {isCheckingQuality ? 'Analyzing Quality...' : 'Run Image Quality Check'}
                </Button>
              </div>
            ) : (
              <div className="space-y-3 animate-slide-up">
                <div className="p-4 rounded-xl border border-guard-300 bg-guard-50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={18} className="text-guard-700" />
                    <span className="text-xs font-bold text-guard-900 uppercase tracking-wide">
                      Overall Quality: {qualityReport.overall}
                    </span>
                  </div>
                  <span className="text-2xs font-mono font-bold text-guard-800">Gating: APPROVED</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-2xs font-mono">
                  <div className="p-3 rounded-lg border border-line bg-surface">
                    <span className="text-ink-muted">Resolution</span>
                    <p className="font-bold text-ink mt-0.5">✓ 1920×1080</p>
                  </div>
                  <div className="p-3 rounded-lg border border-line bg-surface">
                    <span className="text-ink-muted">Brightness</span>
                    <p className="font-bold text-ink mt-0.5">✓ 74% (Optimal)</p>
                  </div>
                  <div className="p-3 rounded-lg border border-line bg-surface">
                    <span className="text-ink-muted">Contrast</span>
                    <p className="font-bold text-ink mt-0.5">✓ 82% (Optimal)</p>
                  </div>
                  <div className="p-3 rounded-lg border border-line bg-surface">
                    <span className="text-ink-muted">Color Reference</span>
                    <p className="font-bold text-ink mt-0.5">✓ Card Detected</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 8: COLOR CALIBRATION */}
        {currentStep === 8 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 08</span>
              <h2 className="text-lg font-bold text-ink">Color Card Calibration & Normalization</h2>
              <p className="text-xs text-ink-muted mt-1">
                Normalizes lighting and white balance against standard reference profile.
              </p>
            </div>

            {!calibrationData ? (
              <div className="p-8 text-center border border-line rounded-xl bg-canvas-warm space-y-3">
                <p className="text-xs text-ink-muted">Normalize camera chromatic bias before classification</p>
                <Button size="sm" onClick={runCalibration} disabled={isCalibrating}>
                  <Sliders size={14} className={isCalibrating ? 'animate-spin' : ''} />
                  {isCalibrating ? 'Calibrating Chromatophores...' : 'Execute Color Calibration'}
                </Button>
              </div>
            ) : (
              <div className="p-4 rounded-xl border border-line bg-surface space-y-3 animate-slide-up">
                <div className="flex items-center justify-between border-b border-line pb-2">
                  <span className="text-xs font-bold text-guard-800">Calibration Profile Locked</span>
                  <span className="text-2xs font-mono text-ink-muted">{calibrationData.calibration_id}</span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                  <div>
                    <span className="data-label">Reference</span>
                    <p className="text-ink mt-0.5">{calibrationData.reference_profile}</p>
                  </div>
                  <div>
                    <span className="data-label">Lighting Condition</span>
                    <p className="text-ink mt-0.5">{calibrationData.lighting_condition}</p>
                  </div>
                  <div>
                    <span className="data-label">White Balance</span>
                    <p className="text-ink mt-0.5">{calibrationData.white_balance}</p>
                  </div>
                  <div>
                    <span className="data-label">Exposure</span>
                    <p className="text-ink mt-0.5">{calibrationData.exposure}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 9: AI ANALYSIS */}
        {currentStep === 9 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 09</span>
              <h2 className="text-lg font-bold text-ink">AI Decision-Support Inference</h2>
              <p className="text-xs text-ink-muted mt-1">
                Evaluates colorimetric spectral profile with FieldGuard Vision CNN.
              </p>
            </div>

            {!aiResult ? (
              <div className="p-8 text-center border border-line rounded-xl bg-canvas-warm space-y-3">
                <p className="text-xs text-ink-muted">Ready for neural inference pipeline</p>
                <Button size="sm" onClick={runAiAnalysis} disabled={isAnalyzing}>
                  <Play size={14} fill="currentColor" />
                  {isAnalyzing ? 'Running FieldGuard Vision...' : 'Run AI Analysis'}
                </Button>
              </div>
            ) : (
              <div className="space-y-4 animate-slide-up">
                <div className="p-5 rounded-xl border-2 border-amber-300 bg-amber-50/50">
                  <span className="section-label text-amber-800">AI PREDICTIVE CLASSIFICATION</span>
                  <div className="text-2xl font-black text-amber-900 mt-1">{aiResult.classification}</div>
                  <div className="text-xs font-mono font-bold text-amber-800 mt-1">
                    Confidence: {aiResult.confidence}% · Model: {aiResult.model} v{aiResult.modelVersion}
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-info-200 bg-info-50 flex items-start gap-2.5">
                  <AlertCircle size={16} className="text-info-700 shrink-0 mt-0.5" />
                  <p className="text-2xs text-info-800 leading-relaxed">
                    <span className="font-bold">FORENSIC DISCLAIMER:</span> {aiResult.decisionNotice}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 10: OFFICER REVIEW */}
        {currentStep === 10 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 10</span>
              <h2 className="text-lg font-bold text-ink">Field Officer Human Verification</h2>
              <p className="text-xs text-ink-muted mt-1">
                Human-in-the-loop review. Confirm or reject machine assessment.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex gap-2">
                <button
                  onClick={() => setOfficerDecision('CONFIRM')}
                  className={`flex-1 p-3 rounded-xl border text-center font-bold text-xs transition-all ${
                    officerDecision === 'CONFIRM'
                      ? 'border-guard-600 bg-guard-50 text-guard-800'
                      : 'border-line bg-surface text-ink-muted'
                  }`}
                >
                  ✓ CONFIRM RESULT
                </button>
                <button
                  onClick={() => setOfficerDecision('REJECT')}
                  className={`flex-1 p-3 rounded-xl border text-center font-bold text-xs transition-all ${
                    officerDecision === 'REJECT'
                      ? 'border-alert-600 bg-alert-50 text-alert-800'
                      : 'border-line bg-surface text-ink-muted'
                  }`}
                >
                  ✗ REJECT RESULT
                </button>
                <button
                  onClick={() => setOfficerDecision('REQUEST_RETEST')}
                  className={`flex-1 p-3 rounded-xl border text-center font-bold text-xs transition-all ${
                    officerDecision === 'REQUEST_RETEST'
                      ? 'border-amber-600 bg-amber-50 text-amber-800'
                      : 'border-line bg-surface text-ink-muted'
                  }`}
                >
                  ↻ REQUEST RETEST
                </button>
              </div>

              <div>
                <label className="data-label block mb-1">
                  Officer Notes {officerDecision !== 'CONFIRM' && '(Mandatory)'}
                </label>
                <textarea
                  value={officerReason}
                  onChange={(e) => setOfficerReason(e.target.value)}
                  placeholder="Record verification notes, observations, or rejection justification..."
                  rows={3}
                  className="w-full p-2.5 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 11: SUPERVISOR SIGN-OFF */}
        {currentStep === 11 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 11</span>
              <h2 className="text-lg font-bold text-ink">Supervisor Verification Sign-Off</h2>
              <p className="text-xs text-ink-muted mt-1">
                Supervisor oversight validating protocol compliance and evidence integrity.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-line bg-canvas-warm space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-line-soft pb-2">
                <span className="font-bold text-ink">Officer Confirmation:</span>
                <Badge tone="guard">{officerDecision}</Badge>
              </div>
              <p className="text-ink-soft">
                {officerReason || 'Visual color reaction conforms with presumptive positive standard.'}
              </p>
            </div>

            <div>
              <label className="data-label block mb-1">Supervisor Final Approval Notes</label>
              <textarea
                value={supervisorNotes}
                onChange={(e) => setSupervisorNotes(e.target.value)}
                placeholder="Supervisor sign-off notes (e.g. Approved for custody vault transfer)..."
                rows={2}
                className="w-full p-2 text-xs rounded-lg border border-line bg-canvas text-ink focus:outline-none"
              />
            </div>
          </div>
        )}

        {/* STEP 12: FINALIZE TEST & GENERATE ARTIFACTS */}
        {currentStep === 12 && (
          <div className="space-y-4">
            <div>
              <span className="section-label">Step 12</span>
              <h2 className="text-lg font-bold text-ink">Finalize, Cryptographically Seal & Report</h2>
              <p className="text-xs text-ink-muted mt-1">
                Computes canonical SHA-256 seal, locks evidence version, generates QR code and PDF report.
              </p>
            </div>

            {!isFinalized ? (
              <div className="p-8 text-center border border-line rounded-xl bg-canvas-warm space-y-3">
                <FileCheck2 size={24} className="mx-auto text-guard-700" />
                <div>
                  <h4 className="text-sm font-bold text-ink">Ready to Seal Evidence</h4>
                  <p className="text-xs text-ink-muted mt-1">
                    Once sealed, evidence record cannot be altered without generating an amended version.
                  </p>
                </div>
                <Button size="md" onClick={handleFinalize}>
                  Execute Cryptographic Seal
                </Button>
              </div>
            ) : (
              <div className="p-6 rounded-xl border-2 border-guard-400 bg-guard-50 space-y-4 animate-slide-up">
                <div className="flex items-center gap-3">
                  <CheckCircle2 size={24} className="text-guard-700" />
                  <div>
                    <h4 className="text-base font-black text-guard-900">EVIDENCE SUCCESSFULLY SEALED</h4>
                    <p className="text-xs text-guard-700 font-mono">
                      SHA-256: {finalizedHash}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 pt-2 border-t border-guard-200">
                  <Button
                    size="sm"
                    onClick={() =>
                      onOpenPublicVerify
                        ? onOpenPublicVerify(selectedEvidenceId)
                        : onNavigate('verify')
                    }
                  >
                    <QrCode size={14} /> Open QR Verification
                  </Button>
                  <Button size="sm" variant="secondary" onClick={handleDownloadPdf}>
                    <Download size={14} /> Download Forensic PDF Report
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => onNavigate('dashboard')}>
                    Return to Dashboard
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* NAVIGATION CONTROLS */}
        <div className="flex items-center justify-between border-t border-line pt-4 mt-6">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setCurrentStep((s) => Math.max(1, s - 1))}
            disabled={currentStep === 1 || isFinalized}
          >
            <ArrowLeft size={14} /> Previous Step
          </Button>

          {currentStep < 12 && (
            <Button
              size="sm"
              onClick={() => setCurrentStep((s) => Math.min(12, s + 1))}
              disabled={
                (currentStep === 4 && !batchConfirmed) ||
                (currentStep === 5 && isKitExpired) ||
                (currentStep === 6 && !imagePreview)
              }
            >
              Next Step <ArrowRight size={14} />
            </Button>
          )}
        </div>
      </Panel>
    </div>
  );
}
