import React, { useState, useMemo } from 'react';
import { useForensicStore } from '@/lib/forensicStore';
import type { TestKit } from '@/types';

interface KitManagementProps {
  onNavigate?: (page: any) => void;
}

export const KitManagement: React.FC<KitManagementProps> = () => {
  const { testKits, toggleKitQuarantine, addTestKit, evidence } = useForensicStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'VALID' | 'EXPIRING' | 'EXPIRED' | 'QUARANTINED'>('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [barcodeSearch, setBarcodeSearch] = useState('');
  const [barcodeScanResult, setBarcodeScanResult] = useState<TestKit | null>(null);

  // New Kit Form State
  const [newKitType, setNewKitType] = useState('NARK II - Scott Reagent (Cocaine)');
  const [newManufacturer, setNewManufacturer] = useState('Sirchie Forensic');
  const [newLotNumber, setNewLotNumber] = useState('SR-2026-904');
  const [newExpiryDate, setNewExpiryDate] = useState('2027-12-31');
  const [newRemainingTests, setNewRemainingTests] = useState(25);
  const [newTargetSubstances, setNewTargetSubstances] = useState('Cocaine HCl, Crack');

  const now = new Date();

  // Helper to compute kit status
  const getKitStatus = (kit: TestKit) => {
    if (kit.quarantined) return 'QUARANTINED';
    const expiry = new Date(kit.expiry_date);
    const diffDays = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays <= 0) return 'EXPIRED';
    if (diffDays <= 30) return 'EXPIRING';
    return 'VALID';
  };

  const filteredKits = useMemo(() => {
    return testKits.filter((kit: TestKit) => {
      const status = getKitStatus(kit);
      if (filterStatus !== 'ALL' && status !== filterStatus) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const kitName = (kit.kit_name || kit.kit_type || '').toLowerCase();
        const lot = (kit.lot_number || kit.batch_number || '').toLowerCase();
        const mfg = (kit.manufacturer || '').toLowerCase();
        const targets = (kit.target_substances || [kit.target_substance]).map((s: string) => s.toLowerCase());
        const match =
          kitName.includes(q) ||
          lot.includes(q) ||
          mfg.includes(q) ||
          targets.some((s: string) => s.includes(q));
        if (!match) return false;
      }
      return true;
    });
  }, [testKits, filterStatus, searchTerm, now]);

  // Handle Barcode Simulation Lookup
  const handleBarcodeLookup = (e: React.FormEvent) => {
    e.preventDefault();
    const found = testKits.find(
      (k: TestKit) =>
        (k.lot_number && k.lot_number.toLowerCase() === barcodeSearch.trim().toLowerCase()) ||
        (k.batch_number && k.batch_number.toLowerCase() === barcodeSearch.trim().toLowerCase()) ||
        k.kit_id.toLowerCase() === barcodeSearch.trim().toLowerCase()
    );
    setBarcodeScanResult(found || null);
  };

  // Handle Add Kit
  const handleAddKit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetList = newTargetSubstances.split(',').map((s: string) => s.trim());
    const newKit: TestKit = {
      kit_id: `kit-${Date.now()}`,
      kit_name: newKitType,
      kit_type: newKitType,
      manufacturer: newManufacturer,
      target_substance: targetList[0] || 'Target Substance',
      target_substances: targetList,
      batch_number: `BATCH-${Date.now().toString(36).toUpperCase()}`,
      lot_number: newLotNumber,
      expiry_date: newExpiryDate,
      received_date: new Date().toISOString().split('T')[0],
      quantity: Number(newRemainingTests),
      remaining_tests: Number(newRemainingTests),
      storage_location: 'Station 4 Secure Vault',
      status: 'AVAILABLE',
      quarantined: false,
    };
    addTestKit(newKit);
    setIsAddModalOpen(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'VALID':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-2xs font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            VALID
          </span>
        );
      case 'EXPIRING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-2xs font-extrabold bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
            EXPIRING &lt; 30d
          </span>
        );
      case 'EXPIRED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-2xs font-extrabold bg-red-50 text-red-700 border border-red-200">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
            EXPIRED (LOCKED)
          </span>
        );
      case 'QUARANTINED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-2xs font-extrabold bg-purple-50 text-purple-700 border border-purple-200">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            QUARANTINED
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-line pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold tracking-[0.16em] uppercase text-guard-700">
            <span className="w-2 h-2 rounded-full bg-guard-600 animate-pulse" />
            Reagent Lot & Quality Compliance
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-ink mt-1">
            Chemical Test Kit Inventory
          </h1>
          <p className="text-sm text-ink-muted mt-1">
            Lot tracking, manufacturer verification, expiry alerts, and automated quarantine enforcement.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-guard-700 hover:bg-guard-800 text-white font-semibold shadow-sm transition-all text-sm shrink-0"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 5v14M5 12h14" />
          </svg>
          Register Kit Lot
        </button>
      </div>

      {/* Barcode & Lot Scanner Lookup Bar */}
      <div className="p-4 rounded-xl bg-surface border border-line flex flex-col md:flex-row items-center gap-4">
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-guard-50 text-guard-700 flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 5v14M8 5v14M12 5v14M17 5v14M21 5v14" />
            </svg>
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-ink">Field Lot Verification Scanner</div>
            <div className="text-2xs text-ink-muted">Scan barcode or enter lot code before testing</div>
          </div>
        </div>

        <form onSubmit={handleBarcodeLookup} className="flex-1 flex gap-2 w-full">
          <input
            type="text"
            placeholder="Scan barcode or enter lot number (e.g., SR-2026-901 or kit-scott-01)..."
            value={barcodeSearch}
            onChange={(e) => setBarcodeSearch(e.target.value)}
            className="flex-1 px-3.5 py-2 text-sm border border-line rounded-lg bg-canvas font-mono"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-surface border border-line hover:bg-canvas text-ink text-sm font-semibold transition-all"
          >
            Verify Lot
          </button>
        </form>
      </div>

      {/* Scan Result Popout */}
      {barcodeScanResult && (
        <div className="p-4 rounded-xl bg-guard-50 border border-guard-200 flex items-center justify-between gap-4 animate-in fade-in">
          <div>
            <div className="text-xs font-bold uppercase text-guard-800">
              Verified Lot: {barcodeScanResult.lot_number} ({barcodeScanResult.kit_name})
            </div>
            <div className="text-xs text-guard-700 mt-1">
              Manufacturer: <span className="font-semibold">{barcodeScanResult.manufacturer}</span> · Expiry:{' '}
              <span className="font-semibold">{barcodeScanResult.expiry_date}</span> · Remaining Tests:{' '}
              <span className="font-semibold">{barcodeScanResult.remaining_tests}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {getStatusBadge(getKitStatus(barcodeScanResult))}
            <button
              onClick={() => setBarcodeScanResult(null)}
              className="text-xs font-semibold text-guard-700 hover:text-guard-900"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Active Valid Lots</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">
            {testKits.filter((k) => getKitStatus(k) === 'VALID').length}
          </div>
          <div className="text-2xs text-emerald-700 font-medium mt-1">Available for field use</div>
        </div>

        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Expiring &lt; 30 Days</div>
          <div className="text-2xl font-black text-amber-600 mt-1">
            {testKits.filter((k) => getKitStatus(k) === 'EXPIRING').length}
          </div>
          <div className="text-2xs text-amber-700 font-medium mt-1">Order replacement stock</div>
        </div>

        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Expired / Locked</div>
          <div className="text-2xl font-black text-red-600 mt-1">
            {testKits.filter((k) => getKitStatus(k) === 'EXPIRED').length}
          </div>
          <div className="text-2xs text-red-700 font-medium mt-1">Blocked by safety interlock</div>
        </div>

        <div className="p-4 rounded-xl bg-surface border border-line">
          <div className="text-xs font-semibold text-ink-muted uppercase">Quarantined Lots</div>
          <div className="text-2xl font-black text-purple-600 mt-1">
            {testKits.filter((k) => k.quarantined).length}
          </div>
          <div className="text-2xs text-purple-700 font-medium mt-1">Withdrawn from rotation</div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 border-b border-line w-full sm:w-auto overflow-x-auto">
          {(['ALL', 'VALID', 'EXPIRING', 'EXPIRED', 'QUARANTINED'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`pb-2.5 px-3 text-sm font-bold whitespace-nowrap transition-all border-b-2 ${
                filterStatus === status
                  ? 'border-guard-700 text-guard-800'
                  : 'border-transparent text-ink-muted hover:text-ink'
              }`}
            >
              {status} (
              {status === 'ALL'
                ? testKits.length
                : testKits.filter((k) => getKitStatus(k) === status).length}
              )
            </button>
          ))}
        </div>

        <div className="w-full sm:w-72">
          <input
            type="text"
            placeholder="Search lot, kit name, or substance..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-line rounded-lg bg-surface focus:outline-none focus:ring-2 focus:ring-guard-500/20"
          />
        </div>
      </div>

      {/* Kit Table */}
      <div className="bg-surface border border-line rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-canvas border-b border-line text-2xs font-bold uppercase tracking-wider text-ink-light">
              <tr>
                <th className="px-5 py-3">Kit & Manufacturer</th>
                <th className="px-5 py-3">Lot Number</th>
                <th className="px-5 py-3">Expiration Date</th>
                <th className="px-5 py-3">Remaining Tests</th>
                <th className="px-5 py-3">Target Substances</th>
                <th className="px-5 py-3">Compliance Status</th>
                <th className="px-5 py-3 text-right">Quarantine Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {filteredKits.map((kit) => {
                const status = getKitStatus(kit);
                const expiry = new Date(kit.expiry_date);
                const diffDays = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

                return (
                  <tr key={kit.kit_id} className="hover:bg-canvas/50 transition-colors">
                    <td className="px-5 py-4">
                      <div className="font-bold text-ink">{kit.kit_name}</div>
                      <div className="text-2xs text-ink-muted font-medium">{kit.manufacturer}</div>
                    </td>

                    <td className="px-5 py-4 font-mono font-bold text-xs text-ink">
                      {kit.lot_number}
                    </td>

                    <td className="px-5 py-4">
                      <div className="font-semibold text-ink text-xs">{kit.expiry_date}</div>
                      <div className="text-2xs text-ink-light">
                        {diffDays > 0 ? `${diffDays} days left` : 'EXPIRED'}
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-ink">
                          {kit.remaining_tests}
                        </span>
                        <span className="text-2xs text-ink-muted">units</span>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {(kit.target_substances || [kit.target_substance]).map((s) => (
                          <span
                            key={s}
                            className="px-2 py-0.5 rounded text-2xs font-semibold bg-canvas text-ink-muted border border-line"
                          >
                            {s}
                          </span>
                        ))}
                      </div>
                    </td>

                    <td className="px-5 py-4">{getStatusBadge(status)}</td>

                    <td className="px-5 py-4 text-right">
                      <button
                        onClick={() => toggleKitQuarantine(kit.kit_id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                          kit.quarantined
                            ? 'bg-purple-50 text-purple-800 border-purple-300 hover:bg-purple-100'
                            : 'bg-surface text-ink-muted border-line hover:text-purple-700 hover:border-purple-300'
                        }`}
                      >
                        {kit.quarantined ? 'Release Quarantine' : 'Quarantine Lot'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Kit Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-ink/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-surface border border-line rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-line pb-4">
              <div>
                <h2 className="text-lg font-black text-ink">Register Test Kit Batch</h2>
                <p className="text-xs text-ink-muted">Record new chemical reagent lot into central inventory</p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-ink-muted hover:text-ink text-xl p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddKit} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-ink uppercase block mb-1">Kit Name / Reagent Type</label>
                <input
                  type="text"
                  required
                  value={newKitType}
                  onChange={(e) => setNewKitType(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">Manufacturer</label>
                  <input
                    type="text"
                    required
                    value={newManufacturer}
                    onChange={(e) => setNewManufacturer(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">Lot Number</label>
                  <input
                    type="text"
                    required
                    value={newLotNumber}
                    onChange={(e) => setNewLotNumber(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={newExpiryDate}
                    onChange={(e) => setNewExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-ink uppercase block mb-1">Test Units Count</label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    required
                    value={newRemainingTests}
                    onChange={(e) => setNewRemainingTests(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-ink uppercase block mb-1">
                  Target Substances (comma separated)
                </label>
                <input
                  type="text"
                  required
                  value={newTargetSubstances}
                  onChange={(e) => setNewTargetSubstances(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-line">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-line text-sm font-semibold hover:bg-canvas text-ink"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-guard-700 hover:bg-guard-800 text-white text-sm font-semibold shadow-sm transition-all"
                >
                  Save Kit Lot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default KitManagement;
