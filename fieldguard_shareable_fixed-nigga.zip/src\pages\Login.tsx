import { useState } from 'react';
import type { UserRole } from '@/types';
import { useForensicStore } from '@/lib/forensicStore';

interface LoginProps {
  role?: string;
  onLogin: (role: string) => void;
  onBack?: () => void;
}

export function Login({ onLogin, onBack }: LoginProps) {
  const { setCurrentUser } = useForensicStore();
  const [username, setUsername] = useState('officer');
  const [password, setPassword] = useState('officer123');
  const [error, setError] = useState('');

  const handleQuickLogin = (role: UserRole) => {
    setCurrentUser(role);
    onLogin(role.toLowerCase());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const u = username.trim().toLowerCase();
    if (u === 'officer' && password === 'officer123') {
      handleQuickLogin('FIELD_OFFICER');
    } else if (u === 'supervisor' && (password === 'supervisor123' || password === 'officer123')) {
      handleQuickLogin('SUPERVISOR');
    } else if (u === 'admin' && (password === 'admin123' || password === 'officer123')) {
      handleQuickLogin('ADMIN');
    } else if (u === 'analyst' && (password === 'analyst123' || password === 'officer123')) {
      handleQuickLogin('FORENSIC_ANALYST');
    } else if (u === 'auditor' && (password === 'auditor123' || password === 'officer123')) {
      handleQuickLogin('AUDITOR');
    } else {
      setError('Invalid credentials. Use officer / officer123 or select a demo role below.');
    }
  };

  return (
    <div className="min-h-screen bg-canvas flex">
      {/* Left identity panel */}
      <section className="hidden lg:flex lg:w-[46%] relative overflow-hidden bg-guard-800 text-white">
        <div className="absolute inset-0 opacity-[0.08]">
          <div className="absolute -top-32 -left-32 w-[420px] h-[420px] rounded-full border border-white" />
          <div className="absolute top-24 left-20 w-[280px] h-[280px] rounded-full border border-white" />
          <div className="absolute -bottom-40 right-[-80px] w-[520px] h-[520px] rounded-full border border-white" />
        </div>

        <div className="relative z-10 w-full flex flex-col justify-between p-12 xl:p-16">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center">
                <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M12 3.5 19 6v5.4c0 4.2-2.7 7.8-7 9.1-4.3-1.3-7-4.9-7-9.1V6l7-2.5Z" />
                  <path d="m9 12 2 2 4-4" />
                </svg>
              </div>
              <div>
                <div className="text-xl font-black tracking-[-0.04em]">
                  FIELD<span className="text-emerald-200">GUARD</span>
                </div>
                <div className="text-[9px] tracking-[0.22em] uppercase text-white/55">
                  Digital Forensic Evidence Integrity Platform
                </div>
              </div>
            </div>

            <div className="mt-20 max-w-md">
              <div className="text-xs font-bold tracking-[0.2em] uppercase text-emerald-200">
                Secure Forensic Gateway
              </div>

              <h1 className="mt-4 text-5xl xl:text-6xl font-black tracking-[-0.05em] leading-[0.95]">
                Preserve.
                <br />
                Verify.
                <br />
                Defend.
              </h1>

              <p className="mt-6 text-base leading-7 text-white/70">
                End-to-end digital evidence management for colorimetric screening, SHA-256 tamper verification, unbroken chain of custody, and ISO/IEC 17025 compliance.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 max-w-md">
            {[
              ['01', 'INTEGRITY'],
              ['02', 'CUSTODY'],
              ['03', 'AUDIT'],
            ].map(([number, label]) => (
              <div key={label} className="rounded-xl border border-white/10 bg-white/5 p-3">
                <div className="text-[10px] text-white/40 font-bold">{number}</div>
                <div className="mt-2 text-[10px] tracking-[0.14em] font-bold text-white/75">
                  {label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Login panel */}
      <main className="flex-1 min-h-screen flex items-center justify-center px-5 py-10 sm:px-8">
        <div className="w-full max-w-[460px]">
          {onBack && (
            <button
              onClick={onBack}
              className="mb-8 text-sm font-medium text-ink-muted hover:text-ink transition-colors flex items-center gap-2"
            >
              <span>←</span>
              Back
            </button>
          )}

          <div className="lg:hidden mb-8">
            <div className="text-2xl font-black tracking-tight text-ink">
              FIELD<span className="text-guard-700">GUARD</span>
            </div>
            <div className="mt-1 text-[9px] tracking-[0.22em] uppercase text-ink-light">
              Digital Forensic Evidence Integrity
            </div>
          </div>

          <div className="mb-7">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-line bg-surface text-[10px] font-bold tracking-[0.14em] uppercase text-guard-700">
              <span className="w-1.5 h-1.5 rounded-full bg-guard-600" />
              Role-Based Forensic Access
            </div>

            <h2 className="mt-4 text-3xl font-black tracking-tight text-ink">
              Sign in to FIELDGUARD
            </h2>

            <p className="mt-2 text-sm leading-6 text-ink-muted">
              Access field testing wizard, evidence registry, custody ledger, and audit logs.
            </p>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-6 sm:p-7 shadow-sm space-y-5">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold tracking-[0.08em] uppercase text-ink-muted mb-1.5">
                  Officer / Personnel ID
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter ID (e.g. officer, supervisor)"
                  className="w-full px-4 py-3 rounded-xl border border-line bg-canvas text-ink outline-none transition-all focus:border-guard-500 focus:ring-4 focus:ring-guard-500/10 text-sm font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold tracking-[0.08em] uppercase text-ink-muted mb-1.5">
                  Secure Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-3 rounded-xl border border-line bg-canvas text-ink outline-none transition-all focus:border-guard-500 focus:ring-4 focus:ring-guard-500/10 text-sm font-medium"
                  required
                />
              </div>

              {error && (
                <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700 font-semibold">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-guard-700 hover:bg-guard-800 text-white font-bold shadow-sm transition-colors text-sm"
              >
                Enter Forensic Platform
              </button>
            </form>

            {/* Quick Demo Sign In Roles */}
            <div className="pt-4 border-t border-line">
              <div className="text-2xs font-bold uppercase tracking-wider text-ink-light mb-2.5">
                Quick Demo Access (Select Role)
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => handleQuickLogin('FIELD_OFFICER')}
                  className="p-2 rounded-lg bg-canvas hover:bg-guard-50 border border-line hover:border-guard-300 text-ink font-semibold transition-all text-left flex items-center justify-between"
                >
                  <span>Field Officer</span>
                  <span className="text-2xs text-guard-700 font-bold">J. Martinez</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickLogin('SUPERVISOR')}
                  className="p-2 rounded-lg bg-canvas hover:bg-guard-50 border border-line hover:border-guard-300 text-ink font-semibold transition-all text-left flex items-center justify-between"
                >
                  <span>Supervisor</span>
                  <span className="text-2xs text-purple-700 font-bold">D. Vance</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickLogin('FORENSIC_ANALYST')}
                  className="p-2 rounded-lg bg-canvas hover:bg-guard-50 border border-line hover:border-guard-300 text-ink font-semibold transition-all text-left flex items-center justify-between"
                >
                  <span>Analyst</span>
                  <span className="text-2xs text-blue-700 font-bold">E. Thorne</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickLogin('AUDITOR')}
                  className="p-2 rounded-lg bg-canvas hover:bg-guard-50 border border-line hover:border-guard-300 text-ink font-semibold transition-all text-left flex items-center justify-between"
                >
                  <span>Auditor</span>
                  <span className="text-2xs text-amber-700 font-bold">S. Reed</span>
                </button>
              </div>
            </div>
          </div>

          <p className="mt-6 text-center text-[11px] text-ink-light">
            FIELDGUARD FORENSIC · ISO/IEC 17025 Compliant Digital Evidence Architecture
          </p>
        </div>
      </main>
    </div>
  );
}
export default Login;
