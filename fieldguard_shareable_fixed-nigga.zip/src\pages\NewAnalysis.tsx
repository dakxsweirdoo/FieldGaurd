import { useRef, useState, useCallback, useEffect } from 'react';
import { Upload, Camera, X, Radio, Play, AlertCircle, Loader2, FlaskConical } from 'lucide-react';
import type { AnalysisResult, CaseRecord } from '@/types';
import { Panel, PanelHeader } from '@/components/ui/Panel';
import { Button } from '@/components/ui/Button';
import { Badge, StatusDot } from '@/components/ui/Badge';
import { SensorGraph } from '@/components/ui/SensorGraph';
import { WorkflowIndicator, ProgressList } from '@/components/Workflow';
import { DEMO_SENSOR_READINGS } from '@/lib/demo-data';
import { fetchSensorSample } from '@/lib/api';

interface AnalysisProps {
  onAnalysisComplete: (result: AnalysisResult, record: CaseRecord, imagePreview: string | null) => void;
  runAnalysis: (imageBlob: Blob, imageFilename: string, sensorReadings: number[]) => Promise<{ result: AnalysisResult; record: CaseRecord }>;
  demoMode: boolean;
  onDemoSelect: (demoKey: string) => void;
  apiOnline: boolean;
}

const workflowSteps: import('@/types').WorkflowStep[] = ['CAPTURE', 'QUALITY', 'VISION', 'SENSOR', 'DECISION', 'AUDIT'];

const demoScenarios = [
  { key: 'positive', label: 'Presumptive Positive', num: '01' },
  { key: 'negative', label: 'Preliminary Negative', num: '02' },
  { key: 'inconclusive', label: 'Inconclusive', num: '03' },
  { key: 'invalid', label: 'Invalid', num: '04' },
  { key: 'poorquality', label: 'Poor Quality', num: '05' },
];

export function NewAnalysis({ onAnalysisComplete, runAnalysis, demoMode, onDemoSelect, apiOnline }: AnalysisProps) {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBlob, setImageBlob] = useState<Blob | null>(null);
  const [imageFilename, setImageFilename] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(-1);
  const [sensorReadings, setSensorReadings] = useState<number[]>(DEMO_SENSOR_READINGS);
  const [sensorLive, setSensorLive] = useState(false);
  const [progressSteps, setProgressSteps] = useState<{ label: string; status: 'pending' | 'active' | 'complete' }[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (demoMode || !apiOnline) {
      setSensorReadings(DEMO_SENSOR_READINGS);
      setSensorLive(false);
      return;
    }
    fetchSensorSample('001').then((readings) => {
      if (readings && readings.length === 31) {
        setSensorReadings(readings);
        setSensorLive(true);
      } else {
        setSensorLive(false);
      }
    });
  }, [demoMode, apiOnline]);

  const handleFile = useCallback((file: File) => {
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setImagePreview(dataUrl);
      setImageBlob(file);
      setImageFilename(file.name);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) handleFile(file);
  }, [handleFile]);

  const clearImage = () => {
    setImagePreview(null);
    setImageBlob(null);
    setImageFilename('');
    setError(null);
  };

  const runAnalysisSequence = async () => {
    if (!imageBlob && !demoMode) return;

    if (!demoMode && !apiOnline) {
      setError('NARCOVEX API UNAVAILABLE');
      return;
    }

    setError(null);
    setIsRunning(true);
    setCurrentStep(0);

    const steps = [
      { label: 'Image received' },
      { label: 'Image quality assessed' },
      { label: 'Vision model evaluating' },
      { label: 'Sensor evaluation' },
      { label: 'Decision policy' },
      { label: 'Audit record' },
    ];

    for (let i = 0; i < steps.length; i++) {
      const updated = steps.map((s, idx) => ({
        label: s.label,
        status: idx < i ? 'complete' as const : idx === i ? 'active' as const : 'pending' as const,
      }));
      setProgressSteps(updated);
      setCurrentStep(i);
      await new Promise((r) => setTimeout(r, 450 + i * 180));
    }

    try {
      const { result, record } = await runAnalysis(
        imageBlob || new Blob(),
        imageFilename || 'demo_image.jpg',
        sensorReadings,
      );

      setProgressSteps(steps.map((s) => ({ label: s.label, status: 'complete' as const })));
      setCurrentStep(6);

      setTimeout(() => {
        onAnalysisComplete(result, record, imagePreview);
      }, 350);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Analysis failed';
      setError(msg);
      setIsRunning(false);
      setCurrentStep(-1);
      setProgressSteps([]);
    }
  };

  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5 animate-fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-ink">New Field Analysis</h1>
        <p className="text-sm text-ink-muted mt-1.5 max-w-3xl leading-relaxed">
          Capture evidence and review the complete decision chain.
        </p>
      </div>

      <div className="bg-surface border border-line rounded-xl px-4 sm:px-6 py-4 sm:py-5">
        <WorkflowIndicator steps={workflowSteps} currentStep={currentStep < 0 ? 0 : currentStep} />
      </div>

      {!demoMode && !apiOnline && (
        <div className="bg-alert-50 border border-alert-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle size={18} className="text-alert-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-alert-700">AI Engine Offline</p>
            <p className="text-xs text-alert-600 mt-1">
              The Narcovex FastAPI backend is not reachable. Live analysis is unavailable. No fake results will be shown.
            </p>
            <p className="text-xs text-alert-600 mt-1.5">
              Enable Demo Mode to demonstrate the screening pipeline with representative data.
            </p>
          </div>
        </div>
      )}

      {demoMode && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 sm:p-5">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-300 flex items-center justify-center shrink-0">
              <FlaskConical size={16} className="text-amber-800" strokeWidth={2} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold uppercase tracking-wider text-amber-800">Demonstration Scenarios — Demo Data</p>
              <p className="text-2xs text-amber-700 mt-1 mb-3">
                These are representative demo results, not live AI output. Each scenario passes through the complete UI pipeline.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
                {demoScenarios.map((opt) => (
                  <button
                    key={opt.key}
                    onClick={() => onDemoSelect(opt.key)}
                    disabled={isRunning}
                    className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium border border-amber-300 bg-surface text-ink-soft hover:bg-amber-100 hover:border-amber-400 transition-all disabled:opacity-40 text-left"
                  >
                    <span className="text-2xs font-mono font-bold text-amber-600 shrink-0">{opt.num}</span>
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        <div className="lg:col-span-3 space-y-4">
          <Panel className="overflow-hidden">
            <div className="px-5 py-3.5 border-b border-line-soft flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-2xs font-mono font-bold text-ink-light">01</span>
                <h3 className="text-sm font-bold text-ink tracking-tight">Capture</h3>
              </div>
              {imagePreview && <Badge tone="guard" dot>Uploaded</Badge>}
            </div>
            <div className="p-5">
              {!imagePreview ? (
                <div
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  className={`relative border-2 border-dashed rounded-xl transition-all duration-200 ${
                    isDragging ? 'border-guard-500 bg-guard-50' : 'border-line-strong bg-canvas-warm'
                  } py-14 px-6 text-center`}
                >
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-surface border border-line flex items-center justify-center">
                      <Upload size={20} className="text-ink-muted" strokeWidth={1.8} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-ink">Drop Field Test Image Here</p>
                      <p className="text-xs text-ink-muted mt-1">or choose an option below</p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 mt-2">
                      <Button size="sm" variant="secondary" onClick={() => fileInputRef.current?.click()}>
                        <Upload size={14} /> Browse Files
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => cameraInputRef.current?.click()}>
                        <Camera size={14} /> Camera Capture
                      </Button>
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
                  />
                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden border border-line bg-canvas-warm">
                    <img src={imagePreview} alt="Test preview" className="w-full max-h-80 object-contain" />
                    <button
                      onClick={clearImage}
                      className="absolute top-2 right-2 w-7 h-7 rounded-lg bg-surface/90 border border-line flex items-center justify-center hover:bg-surface transition-colors"
                    >
                      <X size={14} className="text-ink-soft" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-xs">
                      <span className="font-mono text-ink-muted truncate">{imageFilename}</span>
                    </div>
                    <Button size="sm" variant="ghost" onClick={clearImage}>Remove</Button>
                  </div>
                </div>
              )}
            </div>
          </Panel>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <Panel className="overflow-hidden">
            <PanelHeader
              icon={Radio}
              title="Auxiliary Sensor"
              action={<Badge tone="guard" dot pulse>Connected</Badge>}
            />
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <span className="data-label">Readings</span>
                  <p className="text-sm font-bold text-ink mt-0.5 font-mono">31 / 31</p>
                </div>
                <div>
                  <span className="data-label">Sample ID</span>
                  <p className="text-sm font-bold text-ink mt-0.5 font-mono">001</p>
                </div>
                <div>
                  <span className="data-label">Condition</span>
                  <p className="text-sm font-bold text-guard-600 mt-0.5">Baseline</p>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="section-label">Signal Condition</span>
                  <span className="text-2xs text-ink-light font-mono">31 readings</span>
                </div>
                <SensorGraph readings={sensorReadings} height={100} />
              </div>
              <div className="flex items-start gap-2 p-3 rounded-lg bg-info-50 border border-info-100">
                <AlertCircle size={14} className="text-info-500 mt-0.5 shrink-0" />
                <p className="text-2xs text-info-600 leading-relaxed">
                  Sensor classification represents signal condition only. It is auxiliary evidence and does not independently establish a drug result.
                </p>
              </div>
            </div>
          </Panel>

          <div className="bg-surface border border-line rounded-xl p-5 shadow-card">
            <Button
              size="lg"
              className="w-full"
              onClick={runAnalysisSequence}
              disabled={isRunning || (!imageBlob && !demoMode) || (!demoMode && !apiOnline)}
              data-run-analysis
            >
              {isRunning ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  Analyzing…
                </>
              ) : (
                <>
                  <Play size={18} fill="currentColor" />
                  Run Field Analysis
                </>
              )}
            </Button>
            <p className="text-2xs text-ink-light text-center mt-3 leading-relaxed">
              Sends image and 31 sensor readings to the Narcovex AI backend. Performs quality assessment, vision inference, sensor evaluation and decision-policy processing.
            </p>
            {!demoMode && apiOnline && (
              <div className="flex items-center justify-center gap-1.5 mt-3 pt-3 border-t border-line-soft">
                <StatusDot tone="guard" pulse />
                <span className="text-2xs font-bold uppercase tracking-wider text-guard-700">AI Engine Connected</span>
              </div>
            )}
            {!demoMode && !apiOnline && (
              <div className="flex items-center justify-center gap-1.5 mt-3 pt-3 border-t border-line-soft">
                <StatusDot tone="alert" />
                <span className="text-2xs font-bold uppercase tracking-wider text-alert-600">AI Engine Offline</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {isRunning && (
        <Panel className="p-5 sm:p-6 animate-slide-up" raised>
          <div className="flex items-center gap-2 mb-4">
            <StatusDot tone="guard" pulse />
            <span className="text-sm font-bold text-ink">Analysis in Progress</span>
          </div>
          <ProgressList steps={progressSteps} />
        </Panel>
      )}

      {error && (
        <Panel className="p-5 border-alert-200 bg-alert-50">
          <div className="flex items-start gap-3">
            <AlertCircle size={18} className="text-alert-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-alert-700">NARCOVEX API UNAVAILABLE</p>
              <p className="text-xs text-alert-600 mt-1">
                {error}. The backend analysis service could not be reached. No data has been fabricated.
              </p>
              <p className="text-xs text-alert-600 mt-2">
                Enable Demo Mode to demonstrate the full screening pipeline with representative results.
              </p>
            </div>
          </div>
        </Panel>
      )}

    </div>
  );
}

