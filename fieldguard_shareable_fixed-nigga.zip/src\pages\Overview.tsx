import { Eye, ScanLine, Radio, ShieldCheck, ArrowRight, Plus, FolderOpen } from 'lucide-react';
import type { Page, CaseRecord } from '@/types';
import { Panel } from '@/components/ui/Panel';
import { Badge, StatusDot } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { resultBadgeTone, formatTimestamp } from '@/lib/result-helpers';

interface OverviewProps {
  cases: CaseRecord[];
  onNavigate: (page: Page) => void;
  onSelectCase: (caseId: string) => void;
  loading: boolean;
}

const readinessItems = [
  { label: 'Vision', value: 'Ready', icon: Eye },
  { label: 'Quality Gate', value: 'Active', icon: ScanLine },
  { label: 'Sensor', value: 'Available', icon: Radio },
  { label: 'Decision Engine', value: 'Active', icon: ShieldCheck },
  { label: 'Audit Trail', value: 'Active', icon: ShieldCheck },
];

export function Overview({ cases, onNavigate, onSelectCase, loading }: OverviewProps) {
  const recent = cases.slice(0, 6);

  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-ink">NARCOVEX</h1>
        <p className="text-sm text-ink-soft mt-1">Field Screening Operations</p>
        <p className="text-sm text-ink-muted mt-2 max-w-2xl leading-relaxed">
          From field evidence to explainable operational decisions.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Button size="lg" onClick={() => onNavigate('analysis')} className="flex-1 sm:flex-initial">
          <Plus size={18} strokeWidth={2.5} />
          Start New Analysis
        </Button>
        <Button size="lg" variant="secondary" onClick={() => onNavigate('cases')} className="flex-1 sm:flex-initial">
          <FolderOpen size={18} strokeWidth={2} />
          View Cases
        </Button>
      </div>

      <Panel className="p-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {readinessItems.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.label} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-guard-50 flex items-center justify-center shrink-0">
                  <Icon size={15} className="text-guard-600" strokeWidth={2} />
                </div>
                <div className="min-w-0">
                  <p className="section-label">{item.label}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <StatusDot tone="guard" pulse />
                    <span className="text-sm font-bold text-ink">{item.value}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-ink uppercase tracking-wider">Recent Field Analyses</h2>
          <button
            onClick={() => onNavigate('cases')}
            className="text-xs font-medium text-guard-600 hover:text-guard-700 flex items-center gap-1"
          >
            All Cases <ArrowRight size={12} />
          </button>
        </div>

        <Panel className="overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="inline-flex w-6 h-6 rounded-full border-2 border-guard-500 border-t-transparent animate-spin" />
              <p className="text-sm text-ink-muted mt-3">Loading case records…</p>
            </div>
          ) : recent.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm text-ink-muted">No analyses recorded yet.</p>
              <Button size="sm" className="mt-4" onClick={() => onNavigate('analysis')}>
                <Plus size={14} /> Start New Analysis
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-line-soft">
              {recent.map((c) => (
                <button
                  key={c.case_id}
                  onClick={() => onSelectCase(c.case_id)}
                  className="w-full text-left px-4 sm:px-5 py-3 hover:bg-canvas-warm transition-colors group"
                >
                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 items-center">
                    <div className="col-span-2 sm:col-span-1">
                      <p className="text-xs font-bold text-ink font-mono">{c.case_id}</p>
                      <p className="text-2xs text-ink-light mt-0.5">{formatTimestamp(c.timestamp)}</p>
                    </div>
                    <div className="hidden lg:block">
                      <Badge tone={resultBadgeTone(c.final_result)}>{c.final_result}</Badge>
                    </div>
                    <div className="hidden lg:block">
                      <span className="text-sm font-semibold text-ink">{c.raw_prediction}</span>
                      <p className="text-2xs text-ink-light font-mono">{c.raw_confidence.toFixed(2)}%</p>
                    </div>
                    <div className="hidden lg:block">
                      <span className="text-sm text-ink-soft">{c.quality_gate}</span>
                      <p className="text-2xs text-ink-light font-mono">{c.quality_risk.toFixed(1)}% risk</p>
                    </div>
                    <div className="hidden lg:block">
                      <span className={`text-sm ${c.sensor_available ? 'text-guard-600 font-medium' : 'text-ink-light'}`}>
                        {c.sensor_available ? c.sensor_class ?? 'Available' : 'N/A'}
                      </span>
                    </div>
                    <div className="hidden lg:flex items-center gap-1.5">
                      <StatusDot tone="guard" />
                      <span className="text-2xs font-medium text-ink-muted">{c.audit_status}</span>
                    </div>
                    <div className="lg:hidden col-span-2 sm:col-span-3 flex items-center justify-between">
                      <Badge tone={resultBadgeTone(c.final_result)}>{c.final_result}</Badge>
                      <ArrowRight size={14} className="text-ink-light group-hover:text-guard-600 transition-colors" />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </Panel>
      </div>

      <div className="flex flex-wrap gap-2 text-2xs text-ink-light font-mono pt-2">
        <span>Image SHA-256 verified</span>
        <span>·</span>
        <span>Vision model: fieldguard_v2.pt</span>
        <span>·</span>
        <span>Evidence modes: VISION_ONLY / VISION_PLUS_AUXILIARY_SENSOR</span>
      </div>
    </div>
  );
}

