import React, { useState, useEffect } from 'react';
import { useForensicStore } from '@/lib/forensicStore';
import { checkEvidenceIntegrity } from '@/lib/crypto';
import type { EvidenceItem } from '@/types';

interface PublicVerifyProps {
  initialEvidenceId?: string | null;
  onNavigateHome?: () => void;
}

export const PublicVerify: React.FC<PublicVerifyProps> = ({
  initialEvidenceId,
  onNavigateHome,
}) => {
  const { evidence, cases, testKits } = useForensicStore();

  const [searchId, setSearchId] = useState(initialEvidenceId || 'EV-2026-000412');
  const [targetEvidence, setTargetEvidence] = useState<EvidenceItem | null>(null);
  const [integrityStatus, setIntegrityStatus] = useState<{
    valid: boolean;
    storedHash: string;
    computedHash: string;
    message: string;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Perform integrity check
  const verifySpecimen = async (id: string) => {
    setLoading(true);
    const found = evidence.find(
      (ev) =>
        ev.evidence_id.toLowerCase() === id.trim().toLowerCase() ||
        (ev.evidence_number && ev.evidence_number.toLowerCase() === id.trim().toLowerCase())
    );

    if (!found) {
      setTargetEvidence(null);
      setIntegrityStatus(null);
      setLoading(false);
      return;
    }

    setTargetEvidence(found);
    const check = await checkEvidenceIntegrity(found);
    setIntegrityStatus({
      valid: check.valid,
      storedHash: check.storedHash,
      computedHash: check.computedHash,
      message: check.message,
    });
    setLoading(false);
  };

  useEffect(() => {
    if (searchId) {
      verifySpecimen(searchId);
    }
  }, [evidence]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchId.trim()) {
      verifySpecimen(searchId.trim());
    }
  };

  const handleCopyHash = () => {
    if (integrityStatus?.computedHash) {
      navigator.clipboard.writeText(integrityStatus.computedHash);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const associatedCase = targetEvidence
    ? cases.find((c) => c.case_id === targetEvidence.case_id)
    : null;

  const associatedKit = targetEvidence
    ? testKits.find((k) => k.kit_id === targetEvidence.test_kit_id)
    : null;

  return (
    <div className="min-h-screen bg-canvas py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Brand & Seal Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-guard-200 bg-surface text-guard-800 text-xs font-bold tracking-[0.16em] uppercase shadow-sm">
            <span className="w-2 h-2 rounded-full bg-guard-600 animate-pulse" />
            Public Evidence Verification Portal
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-ink tracking-tight">
            FIELD<span className="text-guard-700">GUARD</span> AUTHENTICATOR
          </h1>
          <p className="text-sm text-ink-muted max-w-md mx-auto">
            Independent, public-facing forensic record verification powered by SHA-256 cryptographic provenance.
          </p>
        </div>

        {/* Search / Verification Input */}
        <div className="bg-surface p-4 rounded-2xl border border-line shadow-sm">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Enter Evidence Tag or ID (e.g. EV-2026-000412)..."
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                className="w-full pl-10 pr-4 py-3 text-sm border border-line rounded-xl bg-canvas font-mono font-bold text-ink focus:outline-none focus:ring-2 focus:ring-guard-500/20"
              />
              <svg
                className="absolute left-3.5 top-3.5 text-ink-light w-4 h-4"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 rounded-xl bg-guard-700 hover:bg-guard-800 text-white font-bold text-sm shadow-sm transition-all shrink-0"
            >
              {loading ? 'Verifying...' : 'Verify Record'}
            </button>
          </form>
        </div>

        {/* Verification Result Banner */}
        {targetEvidence && integrityStatus && (
          <div
            className={`p-6 rounded-2xl border shadow-lg space-y-6 animate-in fade-in zoom-in-95 ${
              integrityStatus.valid
                ? 'bg-surface border-emerald-300 ring-4 ring-emerald-500/10'
                : 'bg-red-50/70 border-red-400 ring-4 ring-red-500/20'
            }`}
          >
            {/* Status Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-line pb-4">
              <div className="flex items-center gap-3">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow ${
                    integrityStatus.valid ? 'bg-emerald-600' : 'bg-red-600 animate-pulse'
                  }`}
                >
                  {integrityStatus.valid ? (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                      <polyline points="9 12 11 14 15 10" />
                    </svg>
                  ) : (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                      <line x1="12" y1="9" x2="12" y2="13" />
                      <line x1="12" y1="17" x2="12.01" y2="17" />
                    </svg>
                  )}
                </div>
                <div>
                  <div
                    className={`text-sm font-black uppercase tracking-wider ${
                      integrityStatus.valid ? 'text-emerald-800' : 'text-red-800'
                    }`}
                  >
                    {integrityStatus.valid
                      ? 'OFFICIAL RECORD VERIFIED · INTEGRITY CONFIRMED'
                      : 'INTEGRITY COMPROMISED · TAMPERING DETECTED'}
                  </div>
                  <div className="text-xs text-ink-muted">
                    {integrityStatus.valid
                      ? 'The stored SHA-256 hash matches canonical evidence telemetry.'
                      : 'WARNING: Cryptographic signature mismatch. Record has been altered.'}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className="text-2xs font-mono font-bold uppercase text-ink-light block">
                  ISO/IEC 17025
                </span>
                <span className="text-xs font-mono font-bold text-ink">
                  {new Date(targetEvidence.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>

            {/* Specimen Telemetry Table (Clean, NO PII) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm bg-canvas/70 p-4 rounded-xl border border-line">
              <div>
                <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                  Evidence Tag
                </span>
                <span className="font-mono font-bold text-ink text-base">
                  {targetEvidence.evidence_number}
                </span>
              </div>

              <div>
                <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                  Anonymized Case Reference
                </span>
                <span className="font-mono font-bold text-guard-800">
                  {associatedCase ? `${associatedCase.case_number.slice(0, 8)}...` : 'FG-2026-***'}
                </span>
              </div>

              <div>
                <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                  Presumptive Test Result
                </span>
                <span className="inline-flex items-center px-2 py-0.5 mt-0.5 rounded text-xs font-bold bg-guard-50 text-guard-800 border border-guard-200">
                  {targetEvidence.ai_prediction || 'Presumptive Positive'}
                </span>
              </div>

              <div>
                <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                  Reagent Lot Number
                </span>
                <span className="font-mono font-semibold text-ink">
                  {associatedKit ? associatedKit.lot_number : 'SR-2026-901'}
                </span>
              </div>

              <div>
                <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                  Officer Verification
                </span>
                <span className="text-xs font-bold text-emerald-700">
                  {targetEvidence.officer_verification ? '✓ Confirmed by Certified Officer' : 'Pending'}
                </span>
              </div>

              <div>
                <span className="text-2xs font-bold uppercase tracking-wider text-ink-light block">
                  Supervisor Sign-Off
                </span>
                <span className="text-xs font-bold text-purple-700">
                  {targetEvidence.supervisor_signoff ? '✓ Authorized by Supervisor' : 'Pending'}
                </span>
              </div>
            </div>

            {/* SHA-256 Hash Footprint */}
            <div className="p-4 rounded-xl bg-surface border border-line space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                  Cryptographic Hash (SHA-256)
                </span>
                <button
                  onClick={handleCopyHash}
                  className="text-xs text-guard-700 hover:text-guard-900 font-semibold"
                >
                  {copied ? 'Copied to Clipboard!' : 'Copy Full Hash'}
                </button>
              </div>
              <div className="font-mono text-xs break-all bg-canvas p-3 rounded-lg border border-line text-ink">
                {integrityStatus.computedHash}
              </div>
              {!integrityStatus.valid && (
                <div className="text-2xs font-mono text-red-600 bg-red-100 p-2 rounded">
                  Stored Original Hash: {integrityStatus.storedHash}
                </div>
              )}
            </div>

            {/* Public Legal Disclaimer */}
            <div className="text-2xs text-ink-light leading-relaxed border-t border-line/60 pt-3">
              <span className="font-bold text-ink-muted">Official Statutory Notice: </span>
              This verification portal provides cryptographic proof that the digital evidence record registered under the cited identifier has not been altered or tampered with since initial sealing. Colorimetric field test results are presumptive screening outcomes and require laboratory confirmatory testing (GC/MS or LC/MS) for formal judicial admissibility. Personal identifying information has been redacted in compliance with privacy regulations.
            </div>
          </div>
        )}

        {/* If no evidence found */}
        {!targetEvidence && !loading && (
          <div className="p-12 text-center rounded-2xl bg-surface border border-line">
            <svg className="w-12 h-12 mx-auto text-ink-light" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <p className="mt-3 text-sm font-semibold text-ink">No Record Found for "{searchId}"</p>
            <p className="text-xs text-ink-muted mt-1">
              Please check the evidence tag on your field custody receipt and try again.
            </p>
          </div>
        )}

        {/* Back navigation button */}
        {onNavigateHome && (
          <div className="text-center pt-4">
            <button
              onClick={onNavigateHome}
              className="text-xs font-bold text-guard-700 hover:text-guard-800 transition-colors"
            >
              ← Return to FieldGuard Main Application
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
export default PublicVerify;
