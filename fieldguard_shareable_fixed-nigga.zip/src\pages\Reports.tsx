import {
  Download,
  BarChart3,
  PieChart,
  Activity,
  Gauge,
  ShieldCheck,
  FileText,
  ClipboardCheck,
} from 'lucide-react';

import { downloadNarcovexReport } from '@/lib/fieldguardReport';
import type { AnalysisResult, CaseRecord } from '@/types';

interface ReportsProps {
  cases: CaseRecord[];
}

function formatPercent(
  value: number | null | undefined,
): string {
  if (
    value === null ||
    value === undefined ||
    Number.isNaN(value)
  ) {
    return '—';
  }

  return `${(value * 100).toFixed(2)}%`;
}

export function Reports({ cases }: ReportsProps) {
  const emptyState = cases.length === 0;

  const total = cases.length;

  const presumptivePositive = cases.filter(
    (item) =>
      item.final_result === 'PRESUMPTIVE POSITIVE',
  ).length;

  const preliminaryNegative = cases.filter(
    (item) =>
      item.final_result === 'PRELIMINARY NEGATIVE',
  ).length;

  const inconclusive = cases.filter(
    (item) => item.final_result === 'INCONCLUSIVE',
  ).length;

  const invalid = cases.filter(
    (item) => item.final_result === 'INVALID',
  ).length;

  const sensorAvailable = cases.filter(
    (item) => item.sensor_available,
  ).length;

  const averageConfidence =
    total > 0
      ? cases.reduce(
          (sum, item) =>
            sum + (item.raw_confidence || 0),
          0,
        ) / total
      : 0;

  const averageQualityRisk =
    total > 0
      ? cases.reduce(
          (sum, item) =>
            sum + (item.quality_risk || 0),
          0,
        ) / total
      : 0;

  /*
   * Generate the same human-readable report locally.
   * The report contains the case/audit information and does not
   * require a separate backend report endpoint.
   */
  async function handleDownloadReport(item: CaseRecord) {
    try {
      const reportResult: AnalysisResult = {
        final_result: item.final_result,
        evidence_mode: item.evidence_mode,
        reason: item.reason,
        vision: {
          quality_risk: item.quality_risk,
          quality_gate: item.quality_gate,
          quality_reason: '',
          raw_class: item.raw_prediction,
          confidence: item.raw_confidence,
          probabilities: item.probabilities,
          quality_metrics: item.quality_metrics,
        },
        sensor: {
          available: item.sensor_available,
          signal_class: item.sensor_class,
          confidence: item.sensor_confidence,
          status: item.sensor_available ? 'AVAILABLE' : 'UNAVAILABLE',
          readings: item.sensor_readings,
        },
        image_sha256: item.image_sha256 || '',
        warnings: item.warnings,
        audit: {
          recorded: item.audit_status === 'RECORDED',
          case_id: item.case_id,
          timestamp_utc: item.timestamp,
          operator_id: 'OFFICER-FG-44',
          image_filename: item.image_filename,
        },
        case_id: item.case_id,
      };

      await downloadNarcovexReport({
        result: reportResult,
        imageFilename: item.image_filename ?? undefined,
      });
    } catch (error) {
      console.error(error);
      alert(
        error instanceof Error
          ? error.message
          : 'Could not generate report.',
      );
    }
  }

  return (
    <div className="space-y-6">

      {/* HEADER */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-sm text-ink-muted">
            <FileText size={16} />
            <span>Field Operations</span>
          </div>

          <h1 className="mt-1 text-2xl font-bold tracking-tight text-ink sm:text-3xl">
            Reports
          </h1>

          <p className="mt-1 text-sm text-ink-muted">
            Screening activity, evidence summary and traceability.
          </p>
        </div>
      </div>

      {/* EMPTY */}
      {emptyState ? (
        <div className="rounded-2xl border border-border bg-surface p-10 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-surface-muted">
            <FileText
              size={24}
              className="text-ink-muted"
            />
          </div>

          <h2 className="mt-4 text-lg font-semibold text-ink">
            No case data available
          </h2>

          <p className="mx-auto mt-2 max-w-md text-sm text-ink-muted">
            Run an analysis first. Once a real analysis is
            completed, its audit record and report will appear here.
          </p>
        </div>
      ) : (
        <>
          {/* SUMMARY */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <SummaryCard
              icon={<BarChart3 size={20} />}
              label="Total Cases"
              value={String(total)}
            />

            <SummaryCard
              icon={<Activity size={20} />}
              label="Presumptive Positive"
              value={String(presumptivePositive)}
            />

            <SummaryCard
              icon={<ShieldCheck size={20} />}
              label="Preliminary Negative"
              value={String(preliminaryNegative)}
            />

            <SummaryCard
              icon={<Gauge size={20} />}
              label="Inconclusive / Invalid"
              value={String(
                inconclusive + invalid,
              )}
            />
          </div>

          {/* DISTRIBUTION */}
          <section className="rounded-2xl border border-border bg-surface">
            <div className="border-b border-border p-5">
              <div className="flex items-center gap-2">
                <PieChart
                  size={18}
                  className="text-ink-muted"
                />

                <h2 className="font-semibold text-ink">
                  Result Distribution
                </h2>
              </div>
            </div>

            <div className="grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4">
              <DistributionItem
                label="Presumptive Positive"
                value={presumptivePositive}
                total={total}
              />

              <DistributionItem
                label="Preliminary Negative"
                value={preliminaryNegative}
                total={total}
              />

              <DistributionItem
                label="Inconclusive"
                value={inconclusive}
                total={total}
              />

              <DistributionItem
                label="Invalid"
                value={invalid}
                total={total}
              />
            </div>
          </section>

          {/* METRICS */}
          <section className="rounded-2xl border border-border bg-surface">
            <div className="border-b border-border p-5">
              <div className="flex items-center gap-2">
                <Gauge
                  size={18}
                  className="text-ink-muted"
                />

                <h2 className="font-semibold text-ink">
                  Screening Metrics
                </h2>
              </div>
            </div>

            <div className="grid gap-5 p-5 sm:grid-cols-2 lg:grid-cols-3">
              <Metric
                label="Average Vision Confidence"
                value={formatPercent(
                  averageConfidence,
                )}
              />

              <Metric
                label="Average Quality Risk"
                value={formatPercent(
                  averageQualityRisk,
                )}
              />

              <Metric
                label="Sensor Available"
                value={`${sensorAvailable} / ${total}`}
              />
            </div>
          </section>

          {/* CASES */}
          <section className="rounded-2xl border border-border bg-surface">
            <div className="border-b border-border p-5">
              <div className="flex items-center gap-2">
                <ClipboardCheck
                  size={18}
                  className="text-ink-muted"
                />

                <div>
                  <h2 className="font-semibold text-ink">
                    Audit & Reports
                  </h2>

                  <p className="mt-1 text-xs text-ink-muted">
                    Download records generated by the
                    Narcovex Python audit engine.
                  </p>
                </div>
              </div>
            </div>

            <div className="divide-y divide-border">
              {cases
                .slice()
                .reverse()
                .slice(0, 10)
                .map((item) => (
                  <div
                    key={item.case_id}
                    className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center lg:justify-between"
                  >
                    {/* CASE INFO */}
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-sm font-semibold text-ink">
                          {item.case_id}
                        </span>

                        <ResultBadge
                          result={
                            item.final_result
                          }
                        />

                        <span
                          className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide ${
                            item.audit_status ===
                            'RECORDED'
                              ? 'border-border text-ink'
                              : 'border-border text-ink-muted'
                          }`}
                        >
                          Audit{' '}
                          {item.audit_status}
                        </span>
                      </div>

                      <p className="mt-2 truncate text-xs text-ink-muted">
                        {item.image_filename ||
                          'Field test image'}
                      </p>

                      <div className="mt-2 flex flex-wrap gap-4 text-xs text-ink-muted">
                        <span>
                          Confidence:{' '}
                          {formatPercent(
                            item.raw_confidence,
                          )}
                        </span>

                        <span>
                          Risk:{' '}
                          {formatPercent(
                            item.quality_risk,
                          )}
                        </span>
                      </div>
                    </div>

                    {/* ACTIONS */}
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          handleDownloadReport(
                            item,
                          )
                        }
                        className="inline-flex items-center justify-center gap-2 rounded-xl bg-ink px-4 py-2.5 text-sm font-medium text-surface transition hover:opacity-90"
                      >
                        <Download size={16} />
                        Download Report
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </section>

          {/* NOTICE */}
          <section className="rounded-2xl border border-border bg-surface-muted p-5">
            <div className="flex gap-3">
              <ShieldCheck
                size={20}
                className="mt-0.5 shrink-0 text-ink-muted"
              />

              <div>
                <h3 className="text-sm font-semibold text-ink">
                  Screening Notice
                </h3>

                <p className="mt-1 text-xs leading-5 text-ink-muted">
                  Narcovex provides preliminary visual
                  screening support. A PRESUMPTIVE POSITIVE
                  is not chemical or forensic confirmation.
                  A PRELIMINARY NEGATIVE does not establish
                  absence. Sensor signal classes are
                  auxiliary prototype signal-condition
                  labels and should not be interpreted
                  independently as drug results.
                </p>
              </div>
            </div>
          </section>
        </>
      )}
    </div>
  );
}

/* =========================================================
   COMPONENTS
========================================================= */

function SummaryCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-5">
      <div className="flex items-center justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-surface-muted text-ink-muted">
          {icon}
        </div>

        <span className="text-2xl font-bold tracking-tight text-ink">
          {value}
        </span>
      </div>

      <p className="mt-4 text-sm text-ink-muted">
        {label}
      </p>
    </div>
  );
}

function DistributionItem({
  label,
  value,
  total,
}: {
  label: string;
  value: number;
  total: number;
}) {
  const percentage =
    total > 0
      ? (value / total) * 100
      : 0;

  return (
    <div className="rounded-xl border border-border p-4">
      <div className="flex items-center justify-between gap-3">
        <span className="text-sm text-ink-muted">
          {label}
        </span>

        <span className="font-semibold text-ink">
          {value}
        </span>
      </div>

      <div className="mt-3 h-2 overflow-hidden rounded-full bg-surface-muted">
        <div
          className="h-full rounded-full bg-ink"
          style={{
            width: `${percentage}%`,
          }}
        />
      </div>

      <p className="mt-2 text-xs text-ink-light">
        {percentage.toFixed(1)}%
      </p>
    </div>
  );
}

function Metric({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-border p-4">
      <p className="text-xs text-ink-muted">
        {label}
      </p>

      <p className="mt-2 text-xl font-semibold text-ink">
        {value}
      </p>
    </div>
  );
}

function ResultBadge({
  result,
}: {
  result: CaseRecord['final_result'];
}) {
  return (
    <span className="rounded-full border border-border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-ink-muted">
      {result}
    </span>
  );
}
