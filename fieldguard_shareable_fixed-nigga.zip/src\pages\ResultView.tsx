import { useState } from 'react';
import {
  Eye, Activity, Radio, ShieldCheck, FileLock2, Download, ChevronDown, ChevronUp,
  AlertCircle, ScanLine, Gauge, Cpu, FileText
} from 'lucide-react';
import type { AnalysisResult, CaseRecord } from '@/types';
import { Panel, PanelHeader } from '@/components/ui/Panel';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Meter } from '@/components/ui/Meter';
import { ProbabilityBar } from '@/components/ui/ProbabilityBar';
import { SensorGraph } from '@/components/ui/SensorGraph';
import { SafetyNotice } from '@/components/SafetyNotice';
import { resultBadgeTone, resultColor, resultBg, rawTone, formatTimestamp, shortHash } from '@/lib/result-helpers';
import { downloadNarcovexReport } from '@/lib/fieldguardReport';

interface ResultViewProps {
  result: AnalysisResult;
  record: CaseRecord;
  imagePreview: string | null;
  onNewAnalysis: () => void;
  onViewCases: () => void;
}

export function ResultView({ result, record, imagePreview, onNewAnalysis, onViewCases }: ResultViewProps) {
  const [showTechnical, setShowTechnical] = useState(false);

  const qualityMetrics = result.vision?.quality_metrics;
  const brightness = qualityMetrics?.brightness ?? 0;
  const contrast = qualityMetrics?.contrast ?? 0;
  const sharpness = qualityMetrics?.sharpness ?? 0;
  const resolution = qualityMetrics?.resolution ?? '—';

  const probabilities = result.vision?.probabilities ?? {};
  const probEntries = [
    { label: 'POSITIVE', value: Number(probabilities.POSITIVE ?? 0), tone: 'amber' as const },
    { label: 'INCONCLUSIVE', value: Number(probabilities.INCONCLUSIVE ?? 0), tone: 'info' as const },
    { label: 'NEGATIVE', value: Number(probabilities.NEGATIVE ?? 0), tone: 'guard' as const },
    { label: 'INVALID', value: Number(probabilities.INVALID ?? 0), tone: 'alert' as const },
  ].sort((a, b) => b.value - a.value);

  const confidencePercent = Number(result.vision?.confidence ?? 0) * 100;
  const qualityRiskPercent = Number(result.vision?.quality_risk ?? 0) * 100;

  const handleDownloadReport = async () => {
    try {
      let imageBlob: Blob | null = null;

      if (imagePreview) {
        const response = await fetch(imagePreview);
        imageBlob = await response.blob();
      }

      await downloadNarcovexReport({
        result,
        imageBlob,
        imageFilename: record.image_filename ?? undefined,
      });
    } catch (error) {
      console.error(error);
      alert(error instanceof Error ? error.message : 'Failed to generate Narcovex report.');
    }
  };

  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-ink">Field Analysis Result</h1>
          <p className="text-sm text-ink-muted mt-1 font-mono">{record.case_id}</p>
        </div>
        <div className="flex gap-2">
          <Button size="md" variant="secondary" onClick={onViewCases}>View Cases</Button>
          <Button size="md" onClick={onNewAnalysis}>New Analysis</Button>
        </div>
      </div>

      <div className={`rounded-2xl border-2 p-6 sm:p-8 ${resultBg(result.final_result)} animate-slide-up`}>
        <span className="section-label">Final Operational Decision</span>
        <p className={`text-3xl sm:text-5xl font-bold tracking-tight mt-2 ${resultColor(result.final_result)}`}>
          {result.final_result}
        </p>
        <div className="mt-6 pt-6 border-t border-current/10">
          <div className="flex items-baseline gap-3 flex-wrap">
            <span className="section-label">Raw AI Prediction</span>
            <span className={`text-xl font-bold ${resultColor(result.final_result)}`}>{result.vision.raw_class}</span>
            <Badge tone={rawTone(result.vision.raw_class)}>Confidence {confidencePercent.toFixed(2)}%</Badge>
          </div>
          <p className="text-xs text-ink-muted mt-2">
            The final operational decision is determined by the decision policy, not the raw model output alone.
          </p>
        </div>
      </div>

      <SafetyNotice result={result.final_result} />

      <Panel className="p-5">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="flex flex-col gap-1.5">
            <span className="section-label">Vision</span>
            <span className={`text-base font-bold ${resultColor(result.final_result)}`}>{result.vision.raw_class}</span>
            <span className="text-xs font-mono text-ink-muted">{confidencePercent.toFixed(2)}%</span>
          </div>
          <div className="flex flex-col gap-1.5">
            <span className="section-label">Quality</span>
            <span className="text-base font-bold text-ink">{result.vision.quality_gate}</span>
            <span className="text-xs font-mono text-ink-muted">{qualityRiskPercent.toFixed(2)}% risk</span>
          </div>
          <div className="flex flex-col gap-1.5">
            <span className="section-label">Sensor</span>
            <span className="text-base font-bold text-ink">{result.sensor.available ? 'Available' : 'N/A'}</span>
            <span className="text-xs font-mono text-ink-muted">{result.sensor.available ? result.sensor.signal_class : '—'}</span>
          </div>
          <div className="flex flex-col gap-1.5">
            <span className="section-label">Decision Policy</span>
            <span className="text-base font-bold text-guard-600">Applied</span>
            <span className="text-xs font-mono text-ink-muted">{result.evidence_mode.replace(/_/g, ' ')}</span>
          </div>
        </div>
      </Panel>

      <Panel className="overflow-hidden">
        <PanelHeader icon={FileText} title="Why This Result?" subtitle="Explanation for field officers and reviewers" />
        <div className="p-5">
          <p className="text-sm text-ink-soft leading-relaxed">{result.reason}</p>
        </div>
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Panel className="overflow-hidden">
          <PanelHeader icon={Eye} title="Vision AI" />
          <div className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <span className="data-label">Raw Prediction</span>
                <p className={`text-lg font-bold ${resultColor(result.final_result)} mt-0.5`}>{result.vision.raw_class}</p>
              </div>
              <div className="text-right">
                <span className="data-label">Confidence</span>
                <p className="text-lg font-bold text-ink mt-0.5 font-mono">{confidencePercent.toFixed(2)}%</p>
              </div>
            </div>
            <div>
              <span className="section-label mb-3 block">Probability Distribution</span>
              <div className="space-y-2.5">
                {probEntries.map((p) => (
                  <ProbabilityBar key={p.label} label={p.label} value={p.value} tone={p.tone} />
                ))}
              </div>
            </div>
          </div>
        </Panel>

        <Panel className="overflow-hidden">
          <PanelHeader icon={Activity} title="Image Quality Control" />
          <div className="p-5 space-y-5">
            <div className="flex items-center justify-between p-3 rounded-lg bg-canvas-warm">
              <div>
                <span className="data-label">Quality Risk</span>
                <p className="text-lg font-bold text-ink mt-0.5 font-mono">{qualityRiskPercent.toFixed(2)}%</p>
              </div>
              <div className="text-right">
                <span className="data-label">Gate</span>
                <p className={`text-lg font-bold mt-0.5 ${result.vision.quality_gate === 'ACCEPTABLE' ? 'text-guard-600' : 'text-amber-600'}`}>
                  {result.vision.quality_gate}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Meter label="Brightness" value={brightness} />
              <Meter label="Contrast" value={contrast} />
              <Meter label="Sharpness" value={sharpness} />
              <div className="space-y-1.5">
                <span className="data-label">Resolution</span>
                <p className="text-sm font-mono font-semibold text-ink">{resolution}</p>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-info-50 border border-info-100">
              <p className="text-2xs font-bold uppercase tracking-wider text-info-600 mb-1">Quality Policy</p>
              <p className="text-xs text-info-600 leading-relaxed">
                Low-quality evidence is prevented from producing an overconfident operational result.
              </p>
            </div>
          </div>
        </Panel>
      </div>

      <Panel className="overflow-hidden">
        <PanelHeader
          icon={Radio}
          title="Auxiliary Sensor"
          action={result.sensor.available ? <Badge tone="guard" dot>Available</Badge> : <Badge tone="neutral">Unavailable</Badge>}
        />
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <span className="data-label">Availability</span>
              <p className="text-sm font-bold text-ink mt-0.5">{result.sensor.available ? 'AVAILABLE' : 'N/A'}</p>
            </div>
            <div>
              <span className="data-label">Readings</span>
              <p className="text-sm font-bold text-ink mt-0.5">{result.sensor.available ? '31 / 31' : '—'}</p>
            </div>
            <div>
              <span className="data-label">Signal Condition</span>
              <p className="text-sm font-bold text-guard-600 mt-0.5">{result.sensor.available ? (result.sensor.signal_class ?? '—').toUpperCase() : '—'}</p>
            </div>
            <div>
              <span className="data-label">Confidence</span>
              <p className="text-sm font-bold text-ink mt-0.5 font-mono">{result.sensor.available && result.sensor.confidence !== null ? `${result.sensor.confidence.toFixed(1)}%` : '—'}</p>
            </div>
          </div>
          {result.sensor.available && (
            <SensorGraph readings={result.sensor.readings} height={120} />
          )}
          <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 border border-amber-100">
            <AlertCircle size={14} className="text-amber-600 mt-0.5 shrink-0" />
            <div>
              <p className="text-2xs font-bold uppercase tracking-wider text-amber-700">Important Limitation</p>
              <p className="text-xs text-amber-700 mt-1 leading-relaxed">
                Sensor labels are prototype signal-condition labels and are not drug-result labels.
              </p>
            </div>
          </div>
        </div>
      </Panel>

      <Panel className="overflow-hidden">
        <PanelHeader icon={FileLock2} title="Traceability & Audit" subtitle="Tamper-traceable evidence chain" />
        <div className="p-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3">
            <AuditRow label="Case ID" value={record.case_id} mono />
            <AuditRow label="Timestamp" value={formatTimestamp(record.timestamp)} mono />
            <AuditRow label="Image SHA-256" value={shortHash(result.image_sha256)} mono />
            <AuditRow label="Evidence Mode" value={result.evidence_mode.replace(/_/g, ' ')} />
            <AuditRow label="Vision Model" value="fieldguard_v2.pt" mono />
            <AuditRow label="Quality Gate" value="fieldguard_quality_risk_gate.joblib" mono />
            <AuditRow label="Sensor Model" value="sensor_ai_v2_best.joblib" mono />
            <AuditRow label="Audit Status" value={record.audit_status} />
          </div>
          {result.warnings.length > 0 && (
            <div className="mt-4 p-3 rounded-lg bg-amber-50 border border-amber-100">
              <p className="text-2xs font-bold uppercase tracking-wider text-amber-700 mb-1.5">Warnings</p>
              <ul className="space-y-1">
                {result.warnings.map((w, i) => (
                  <li key={i} className="text-xs text-amber-700 flex items-start gap-1.5">
                    <span className="mt-1.5 w-1 h-1 rounded-full bg-amber-500 shrink-0" />{w}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="flex flex-wrap gap-2 mt-5 pt-5 border-t border-line-soft">
            <Button size="sm" variant="secondary" onClick={handleDownloadReport}>
              <Download size={14} /> Download Report
            </Button>
            <button
              onClick={() => setShowTechnical(!showTechnical)}
              className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-ink-muted hover:text-ink hover:bg-canvas-warm transition-colors"
            >
              View Technical Analysis Record
              {showTechnical ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
          </div>
          {showTechnical && (
            <pre className="mt-4 p-4 rounded-lg bg-ink text-canvas text-2xs font-mono overflow-x-auto scrollbar-thin max-h-96 animate-slide-up">
{JSON.stringify({ result, record }, null, 2)}
            </pre>
          )}
        </div>
      </Panel>
    </div>
  );
}

function AuditRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-line-soft last:border-0">
      <span className="data-label">{label}</span>
      <span className={`text-sm font-semibold text-ink ${mono ? 'font-mono text-xs' : ''}`}>{value}</span>
    </div>
  );
}

