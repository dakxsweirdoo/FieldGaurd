import type { ReactNode } from 'react';

type Role = 'citizen' | 'officer';

interface RoleSelectProps {
  onSelect: (role: Role) => void;
}

interface RoleCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  label: string;
  onClick: () => void;
}

function RoleCard({
  icon,
  title,
  description,
  label,
  onClick,
}: RoleCardProps) {
  return (
    <button
      onClick={onClick}
      className="group w-full text-left bg-surface border border-line rounded-2xl p-6 sm:p-7 hover:border-guard-500 hover:shadow-md transition-all duration-200"
    >
      <div className="flex items-start justify-between gap-5">
        <div>
          <div className="w-12 h-12 rounded-xl bg-guard-50 text-guard-700 flex items-center justify-center mb-5">
            {icon}
          </div>

          <h2 className="text-xl font-bold text-ink">
            {title}
          </h2>

          <p className="mt-2 text-sm leading-6 text-ink-muted max-w-sm">
            {description}
          </p>
        </div>

        <span className="text-ink-light group-hover:text-guard-600 group-hover:translate-x-1 transition-all text-xl">
          →
        </span>
      </div>

      <div className="mt-6 text-sm font-semibold text-guard-700">
        {label}
      </div>
    </button>
  );
}

export function RoleSelect({ onSelect }: RoleSelectProps) {
  return (
    <div className="min-h-screen bg-canvas flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-4xl">

        <div className="text-center mb-10">
          <div className="text-xs font-bold tracking-[0.22em] text-guard-600 mb-4">
            NARCOVEX
          </div>

          <h1 className="text-3xl sm:text-4xl font-bold text-ink">
            Choose your access
          </h1>

          <p className="mt-3 text-sm sm:text-base text-ink-muted">
            Select the role that matches how you are using Narcovex.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-5">

          <RoleCard
            title="Citizen"
            description="Access testing services, view your preliminary results, track requests and manage your personal reports."
            label="Continue as Citizen →"
            onClick={() => onSelect('citizen')}
            icon={
              <svg
                width="25"
                height="25"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <circle cx="12" cy="8" r="3.5" />
                <path d="M5.5 20c.7-3.4 2.9-5.2 6.5-5.2s5.8 1.8 6.5 5.2" />
              </svg>
            }
          />

          <RoleCard
            title="Officer"
            description="Access field analysis, sensor evidence, cases, reports, audit records and operational tools."
            label="Continue as Officer →"
            onClick={() => onSelect('officer')}
            icon={
              <svg
                width="25"
                height="25"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <path d="M12 3l7 3v5c0 4.7-2.9 8-7 10-4.1-2-7-5.3-7-10V6l7-3z" />
                <path d="M9.5 12l1.7 1.7 3.6-3.6" />
              </svg>
            }
          />

        </div>

        <div className="mt-8 text-center">
          <p className="text-xs text-ink-light">
            Narcovex is an AI-assisted preliminary screening system.
            Screening results are not forensic confirmation.
          </p>
        </div>

      </div>
    </div>
  );
}
