import { Eye, Radio, Cpu, ShieldCheck, Database, Wifi, AlertTriangle, ScanLine, FileWarning } from 'lucide-react';
import { Panel, PanelHeader } from '@/components/ui/Panel';
import { Badge, StatusDot } from '@/components/ui/Badge';

interface SystemProps {
  apiOnline: boolean;
  dbConnected: boolean;
}

export function System({ apiOnline, dbConnected }: SystemProps) {
  const systemCards = [
    { label: 'Vision AI', value: 'Narcovex V2', status: 'Ready', icon: Eye, online: true },
    { label: 'Quality Risk Gate', value: 'Active', status: 'Active', icon: ScanLine, online: true },
    { label: 'Sensor AI', value: 'Narcovex Sensor V2', status: 'Ready', icon: Radio, online: true },
    { label: 'Decision Engine', value: 'Active', status: 'Active', icon: Cpu, online: true },
    { label: 'Audit Engine', value: 'Active', status: 'Active', icon: ShieldCheck, online: true },
    { label: 'AI Engine', value: apiOnline ? 'Connected' : 'Offline', status: apiOnline ? 'Connected' : 'Offline', icon: Wifi, online: apiOnline },
    { label: 'Database', value: dbConnected ? 'Connected' : 'Disconnected', status: dbConnected ? 'Connected' : 'Offline', icon: Database, online: dbConnected },
  ];

  const limitations = [
    'Vision model performs preliminary visual screening.',
    'Presumptive positive is not forensic confirmation.',
    'Preliminary negative does not establish absence.',
    'Sensor output is auxiliary evidence.',
    'Sensor prototype labels represent signal conditions only.',
    'Prototype benchmark results are not forensic validation.',
    'Poor-quality images may be rejected or marked inconclusive.',
  ];

  const modelFiles = [
    { label: 'Vision Model File', value: 'fieldguard_v2.pt' },
    { label: 'Quality Gate File', value: 'fieldguard_quality_risk_gate.joblib' },
    { label: 'Sensor Model File', value: 'sensor_ai_v2_best.joblib' },
    { label: 'Core Module', value: 'fieldguard_ai_core.py' },
  ];

  return (
    <div className="max-w-instrument mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5 animate-fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-ink">NARCOVEX System</h1>
        <p className="text-sm text-ink-muted mt-1">Model configuration, connectivity and operational limitations</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {systemCards.map((card) => {
          const Icon = card.icon;
          return (
            <Panel key={card.label} className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-guard-50 flex items-center justify-center">
                    <Icon size={15} className="text-guard-600" strokeWidth={2} />
                  </div>
                  <span className="section-label">{card.label}</span>
                </div>
                <StatusDot tone={card.online ? 'guard' : 'amber'} pulse={card.online} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-ink">{card.value}</span>
                <Badge tone={card.online ? 'guard' : 'amber'}>{card.status}</Badge>
              </div>
            </Panel>
          );
        })}
      </div>

      <Panel className="overflow-hidden">
        <PanelHeader icon={AlertTriangle} title="Model & System Limitations" subtitle="Important constraints for all operators and reviewers" />
        <div className="p-5">
          <ul className="space-y-3">
            {limitations.map((limitation, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                <span className="text-sm text-ink-soft leading-relaxed">{limitation}</span>
              </li>
            ))}
          </ul>
          <div className="mt-5 pt-5 border-t border-line-soft p-4 rounded-lg bg-canvas-warm">
            <div className="flex items-start gap-2">
              <FileWarning size={14} className="text-guard-600 mt-0.5 shrink-0" />
              <p className="text-xs text-ink-muted leading-relaxed">
                These limitations are by design. Transparency about constraints increases trust and ensures
                results are interpreted correctly. NARCOVEX is a screening companion, not a forensic
                confirmation system.
              </p>
            </div>
          </div>
        </div>
      </Panel>

      <Panel className="p-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-0">
          {modelFiles.map((f) => (
            <div key={f.label} className="flex items-center justify-between py-2 border-b border-line-soft last:border-0">
              <span className="data-label">{f.label}</span>
              <span className="text-xs font-mono font-semibold text-ink">{f.value}</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

