import React, { useState, useMemo } from 'react';
import { useForensicStore } from '@/lib/forensicStore';
import type {
  EvidenceItem,
  VerificationDecision,
  VerificationRecord,
  VerificationStage,
} from '@/types';

interface VerificationPageProps {
  onNavigate?: (page: any) => void;
}

export const VerificationPage: React.FC<VerificationPageProps> = () => {
  const {
    evidence,
    cases,
    testKits,
    verifications,
    currentUser,
    recordVerification,
  } = useForensicStore();

  const [activeTab, setActiveTab] = useState<
    'PENDING_OFFICER' | 'PENDING_SUPERVISOR' | 'COMPLETED' | 'DISCREPANCIES'
  >('PENDING_OFFICER');

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEvidenceForReview, setSelectedEvidenceForReview] = useState<EvidenceItem | null>(null);

  // Review modal state
  const [decision, setDecision] = useState<VerificationDecision>('CONFIRM');
  const [reasonCategory, setReasonCategory] = useState<string>('Colorimetric reaction matches secondary reference');
  const [notes, setNotes] = useState<string>('');
  const [confirmAttestation, setConfirmAttestation] = useState<boolean>(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Determine items needing Officer review
  const pendingOfficerItems = useMemo(() => {
    return evidence.filter(
      (ev) =>
        ev.status === 'TESTED' &&
        (!ev.officer_verification || ev.officer_verification.decision === 'REQUEST_RETEST')
    );
  }, [evidence]);

  // Determine items needing Supervisor sign-off
  const pendingSupervisorItems = useMemo(() => {
    return evidence.filter(
      (ev) =>
        ev.status === 'VERIFIED' &&
        ev.officer_verification?.decision === 'CONFIRM' &&
        !ev.supervisor_signoff
    );
  }, [evidence]);

  // Completed items
  const completedItems = useMemo(() => {
    return evidence.filter((ev) => ev.officer_verification && ev.supervisor_signoff);
  }, [evidence]);

  // Discrepancy items
  const discrepancyItems = useMemo(() => {
    return evidence.filter(
      (ev) =>
        ev.officer_verification?.decision === 'REJECT' ||
        ev.supervisor_signoff?.decision === 'REJECT' ||
        ev.officer_verification?.discrepancy_flag
    );
  }, [evidence]);

  // Current display list based on active tab
  const currentList = useMemo(() => {
    let list: EvidenceItem[] = [];
    if (activeTab === 'PENDING_OFFICER') list = pendingOfficerItems;
    else if (activeTab === 'PENDING_SUPERVISOR') list = pendingSupervisorItems;
    else if (activeTab === 'COMPLETED') list = completedItems;
    else if (activeTab === 'DISCREPANCIES') list = discrepancyItems;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      list = list.filter(
        (ev) =>
          (ev.evidence_number || ev.evidence_id).toLowerCase().includes(q) ||
          ev.case_id.toLowerCase().includes(q) ||
          ev.substance_claimed?.toLowerCase().includes(q) ||
          ev.ai_prediction?.toLowerCase().includes(q)
      );
    }
    return list;
  }, [
    activeTab,
    pendingOfficerItems,
    pendingSupervisorItems,
    completedItems,
    discrepancyItems,
    searchTerm,
  ]);

  const handleOpenReview = (ev: EvidenceItem) => {
    setSelectedEvidenceForReview(ev);
    setDecision('CONFIRM');
    setNotes('');
    setConfirmAttestation(false);
  };

  const handleExecuteVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEvidenceForReview) return;
    if (!confirmAttestation) {
      alert('You must sign the forensic attestation before submitting.');
      return;
    }

    const stage: VerificationStage =
      activeTab === 'PENDING_SUPERVISOR' || currentUser.role === 'SUPERVISOR'
        ? 'SUPERVISOR'
        : 'OFFICER';

    const fullReason =
      decision === 'CONFIRM'
        ? notes || 'Presumptive test results corroborated by visual inspector.'
        : `[${reasonCategory}] ${notes}`;

    await recordVerification(
      selectedEvidenceForReview.evidence_id,
      selectedEvidenceForReview.case_id,
      stage,
      decision,
      fullReason
    );

    setActionSuccess(
      `Verification record submitted for ${selectedEvidenceForReview.evidence_number} (${decision}).`
    );
    setSelectedEvidenceForReview(null);
    setTimeout(() => setActionSuccess(null), 5000);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-line pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold tracking-[0.16em] uppercase text-guard-700">
            <span className="w-2 h-2 rounded-full bg-guard-600 animate-pulse" />
            Human-in-the-Loop Safeguard Queue
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-ink mt-1">
            Forensic Verification Console
          </h1>
          <p className="text-sm text-ink-muted mt-1">
            Two-stage review ensuring AI inferences are verified and authorized by certified field officers and supervisors.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right text-xs">
            <div className="text-ink-muted">Active Reviewer</div>
            <div className="font-bold text-ink">{currentUser.name}</div>
            <div className="text-2xs font-extrabold text-guard-700 uppercase tracking-wider">
              {currentUser.role}
            </div>
          </div>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <polyline points="22 4 12 14.01 9 11.01" />
          </svg>
          <span className="text-sm font-semibold">{actionSuccess}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button
          onClick={() => setActiveTab('PENDING_OFFICER')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeTab === 'PENDING_OFFICER'
              ? 'bg-guard-50 border-guard-300 ring-2 ring-guard-500/20'
              : 'bg-surface border-line hover:border-guard-200'
          }`}
        >
          <div className="text-xs font-semibold text-ink-muted uppercase">Pending Officer Review</div>
          <div className="text-2xl font-black text-ink mt-1">{pendingOfficerItems.length}</div>
          <div className="text-2xs text-amber-600 font-bold mt-1">Stage 1 Presumptive</div>
        </button>

        <button
          onClick={() => setActiveTab('PENDING_SUPERVISOR')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeTab === 'PENDING_SUPERVISOR'
              ? 'bg-guard-50 border-guard-300 ring-2 ring-guard-500/20'
              : 'bg-surface border-line hover:border-guard-200'
          }`}
        >
          <div className="text-xs font-semibold text-ink-muted uppercase">Pending Supervisor Sign-Off</div>
          <div className="text-2xl font-black text-ink mt-1">{pendingSupervisorItems.length}</div>
          <div className="text-2xs text-purple-600 font-bold mt-1">Stage 2 Authorization</div>
        </button>

        <button
          onClick={() => setActiveTab('COMPLETED')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeTab === 'COMPLETED'
              ? 'bg-guard-50 border-guard-300 ring-2 ring-guard-500/20'
              : 'bg-surface border-line hover:border-guard-200'
          }`}
        >
          <div className="text-xs font-semibold text-ink-muted uppercase">Fully Verified</div>
          <div className="text-2xl font-black text-ink mt-1">{completedItems.length}</div>
          <div className="text-2xs text-emerald-600 font-bold mt-1">Dual Signatures Sealed</div>
        </button>

        <button
          onClick={() => setActiveTab('DISCREPANCIES')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeTab === 'DISCREPANCIES'
              ? 'bg-guard-50 border-guard-300 ring-2 ring-guard-500/20'
              : 'bg-surface border-line hover:border-guard-200'
          }`}
        >
          <div className="text-xs font-semibold text-ink-muted uppercase">Flagged Discrepancies</div>
          <div className="text-2xl font-black text-red-600 mt-1">{discrepancyItems.length}</div>
          <div className="text-2xs text-red-600 font-bold mt-1">AI Override / Retest</div>
        </button>
      </div>

      {/* Search & Tabs */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 border-b border-line w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('PENDING_OFFICER')}
            className={`pb-2.5 px-3 text-sm font-bold transition-all border-b-2 ${
              activeTab === 'PENDING_OFFICER'
                ? 'border-guard-700 text-guard-800'
                : 'border-transparent text-ink-muted hover:text-ink'
            }`}
          >
            Officer Stage ({pendingOfficerItems.length})
          </button>
          <button
            onClick={() => setActiveTab('PENDING_SUPERVISOR')}
            className={`pb-2.5 px-3 text-sm font-bold transition-all border-b-2 ${
              activeTab === 'PENDING_SUPERVISOR'
                ? 'border-guard-700 text-guard-800'
                : 'border-transparent text-ink-muted hover:text-ink'
            }`}
          >
            Supervisor Stage ({pendingSupervisorItems.length})
          </button>
          <button
            onClick={() => setActiveTab('COMPLETED')}
            className={`pb-2.5 px-3 text-sm font-bold transition-all border-b-2 ${
              activeTab === 'COMPLETED'
                ? 'border-guard-700 text-guard-800'
                : 'border-transparent text-ink-muted hover:text-ink'
            }`}
          >
            Completed ({completedItems.length})
          </button>
          <button
            onClick={() => setActiveTab('DISCREPANCIES')}
            className={`pb-2.5 px-3 text-sm font-bold transition-all border-b-2 ${
              activeTab === 'DISCREPANCIES'
                ? 'border-guard-700 text-guard-800'
                : 'border-transparent text-ink-muted hover:text-ink'
            }`}
          >
            Discrepancies ({discrepancyItems.length})
          </button>
        </div>

        <div className="w-full sm:w-72">
          <input
            type="text"
            placeholder="Filter evidence or cases..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-line rounded-lg bg-surface focus:outline-none focus:ring-2 focus:ring-guard-500/20"
          />
        </div>
      </div>

      {/* Review Queue Table */}
      <div className="bg-surface border border-line rounded-2xl overflow-hidden shadow-sm">
        {currentList.length === 0 ? (
          <div className="p-12 text-center">
            <svg className="w-12 h-12 mx-auto text-ink-light" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            <p className="mt-3 text-sm font-semibold text-ink">Queue is clear for this stage</p>
            <p className="text-xs text-ink-muted mt-1">No items currently awaiting review.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-canvas border-b border-line text-2xs font-bold uppercase tracking-wider text-ink-light">
                <tr>
                  <th className="px-5 py-3">Evidence Item</th>
                  <th className="px-5 py-3">Case</th>
                  <th className="px-5 py-3">AI Inferred Result</th>
                  <th className="px-5 py-3">Confidence</th>
                  <th className="px-5 py-3">Officer Status</th>
                  <th className="px-5 py-3">Supervisor Status</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line/60">
                {currentList.map((ev) => {
                  const caseRecord = cases.find((c) => c.case_id === ev.case_id);
                  const confidence = ev.ai_confidence ? Math.round(ev.ai_confidence * 100) : 92;

                  return (
                    <tr key={ev.evidence_id} className="hover:bg-canvas/50 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-ink font-mono">{ev.evidence_number}</div>
                        <div className="text-2xs text-ink-muted">
                          {ev.substance_claimed || ev.type}
                        </div>
                      </td>

                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-guard-800">
                          {caseRecord ? caseRecord.case_number : ev.case_id}
                        </div>
                        <div className="text-2xs text-ink-light truncate max-w-[150px]">
                          {caseRecord?.title}
                        </div>
                      </td>

                      <td className="px-5 py-3.5">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-guard-50 text-guard-800 border border-guard-200">
                          {ev.ai_prediction || 'PENDING'}
                        </span>
                      </td>

                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-2 rounded-full bg-line overflow-hidden">
                            <div
                              className="h-full bg-guard-600 rounded-full"
                              style={{ width: `${confidence}%` }}
                            />
                          </div>
                          <span className="text-xs font-mono font-bold text-ink">{confidence}%</span>
                        </div>
                      </td>

                      <td className="px-5 py-3.5">
                        {ev.officer_verification ? (
                          <span
                            className={`px-2 py-0.5 rounded-full text-2xs font-extrabold border ${
                              ev.officer_verification.decision === 'CONFIRM'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-red-50 text-red-700 border-red-200'
                            }`}
                          >
                            {ev.officer_verification.decision}
                          </span>
                        ) : (
                          <span className="text-2xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            Awaiting
                          </span>
                        )}
                      </td>

                      <td className="px-5 py-3.5">
                        {ev.supervisor_signoff ? (
                          <span
                            className={`px-2 py-0.5 rounded-full text-2xs font-extrabold border ${
                              ev.supervisor_signoff.decision === 'CONFIRM'
                                ? 'bg-purple-50 text-purple-700 border-purple-200'
                                : 'bg-red-50 text-red-700 border-red-200'
                            }`}
                          >
                            {ev.supervisor_signoff.decision}
                          </span>
                        ) : (
                          <span className="text-2xs font-semibold text-ink-muted">
                            {ev.officer_verification?.decision === 'CONFIRM'
                              ? 'Awaiting Sign-off'
                              : 'Pending Officer'}
                          </span>
                        )}
                      </td>

                      <td className="px-5 py-3.5 text-right">
                        <button
                          onClick={() => handleOpenReview(ev)}
                          className="px-3.5 py-1.5 rounded-lg bg-guard-700 hover:bg-guard-800 text-white text-xs font-semibold shadow-sm transition-all"
                        >
                          Review & Sign
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Review & Attestation Modal */}
      {selectedEvidenceForReview && (
        <div className="fixed inset-0 z-50 bg-ink/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-surface border border-line rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-line pb-4">
              <div>
                <h2 className="text-lg font-black text-ink">
                  Forensic Review & Sign-Off
                </h2>
                <p className="text-xs text-ink-muted">
                  Evidence: {selectedEvidenceForReview.evidence_number} · Case:{' '}
                  {selectedEvidenceForReview.case_id}
                </p>
              </div>
              <button
                onClick={() => setSelectedEvidenceForReview(null)}
                className="text-ink-muted hover:text-ink text-xl p-1"
              >
                ✕
              </button>
            </div>

            {/* AI Presumptive Readout */}
            <div className="p-4 rounded-xl bg-canvas border border-line space-y-3">
              <div className="text-xs font-bold uppercase tracking-wider text-ink-light">
                Presumptive AI Analysis Summary
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-ink">
                    Detected Substance:
                  </div>
                  <div className="text-base font-black text-guard-800">
                    {selectedEvidenceForReview.ai_prediction || 'Cocaine HCl'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-ink-muted">Confidence Score:</div>
                  <div className="text-lg font-black text-ink">
                    {selectedEvidenceForReview.ai_confidence
                      ? Math.round(selectedEvidenceForReview.ai_confidence * 100)
                      : 94}
                    %
                  </div>
                </div>
              </div>
              <div className="text-2xs text-amber-800 bg-amber-50 p-2 rounded border border-amber-200">
                ⚠ Statutory Notice: AI inference is an auxiliary field screening tool. Confirmatory sign-off by a qualified officer or supervisor is required prior to evidentiary filing.
              </div>
            </div>

            <form onSubmit={handleExecuteVerification} className="space-y-4">
              {/* Decision Radio Selector */}
              <div>
                <label className="text-xs font-bold text-ink uppercase block mb-2">
                  Forensic Decision
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setDecision('CONFIRM')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      decision === 'CONFIRM'
                        ? 'bg-emerald-50 border-emerald-300 ring-2 ring-emerald-500/20 text-emerald-900 font-bold'
                        : 'bg-surface border-line text-ink-muted hover:border-line'
                    }`}
                  >
                    <div className="text-base">✓</div>
                    <div className="text-xs mt-1">CONFIRM</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDecision('REJECT')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      decision === 'REJECT'
                        ? 'bg-red-50 border-red-300 ring-2 ring-red-500/20 text-red-900 font-bold'
                        : 'bg-surface border-line text-ink-muted hover:border-line'
                    }`}
                  >
                    <div className="text-base">✕</div>
                    <div className="text-xs mt-1">OVERRIDE (REJECT)</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDecision('REQUEST_RETEST')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      decision === 'REQUEST_RETEST'
                        ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-500/20 text-amber-900 font-bold'
                        : 'bg-surface border-line text-ink-muted hover:border-line'
                    }`}
                  >
                    <div className="text-base">↻</div>
                    <div className="text-xs mt-1">REQUEST RETEST</div>
                  </button>
                </div>
              </div>

              {/* If rejecting, require reason category */}
              {decision === 'REJECT' && (
                <div>
                  <label className="text-xs font-bold text-red-700 uppercase block mb-1">
                    Mandatory Reason for Override
                  </label>
                  <select
                    value={reasonCategory}
                    onChange={(e) => setReasonCategory(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-red-200 rounded-lg bg-red-50 text-red-900 font-medium"
                  >
                    <option value="Visual colorimetric reaction inconsistent with AI classification">
                      Visual colorimetric reaction inconsistent with AI classification
                    </option>
                    <option value="Insufficient sample volume / reagent saturation issue">
                      Insufficient sample volume / reagent saturation issue
                    </option>
                    <option value="Excipient / adulterant interference suspected">
                      Excipient / adulterant interference suspected
                    </option>
                    <option value="Lighting / glare distorted reaction window">
                      Lighting / glare distorted reaction window
                    </option>
                  </select>
                </div>
              )}

              {/* Reviewer Notes */}
              <div>
                <label className="text-xs font-bold text-ink uppercase block mb-1">
                  Professional Review Notes & Observations
                </label>
                <textarea
                  rows={2}
                  required={decision !== 'CONFIRM'}
                  placeholder="Record optical observations, secondary verification notes, or test kit lot references..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-line rounded-lg bg-surface font-medium focus:ring-2 focus:ring-guard-500/20"
                />
              </div>

              {/* Attestation Checkbox */}
              <div className="p-3.5 rounded-xl bg-guard-50 border border-guard-200">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confirmAttestation}
                    onChange={(e) => setConfirmAttestation(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-guard-700 focus:ring-guard-500"
                  />
                  <div className="text-xs text-guard-900 leading-snug">
                    <span className="font-bold block">
                      Forensic Sign-Off Attestation ({currentUser.role})
                    </span>
                    I, <span className="font-semibold">{currentUser.name}</span>, officially attest that I have reviewed the photographic evidence, kit validation parameters, and algorithmic outputs for this specimen, and execute this sign-off in accordance with evidentiary standards.
                  </div>
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-line">
                <button
                  type="button"
                  onClick={() => setSelectedEvidenceForReview(null)}
                  className="px-4 py-2 rounded-lg border border-line text-sm font-semibold hover:bg-canvas text-ink"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!confirmAttestation}
                  className="px-5 py-2 rounded-lg bg-guard-700 hover:bg-guard-800 disabled:opacity-50 text-white text-sm font-semibold shadow-sm transition-all"
                >
                  Commit Verification
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default VerificationPage;
