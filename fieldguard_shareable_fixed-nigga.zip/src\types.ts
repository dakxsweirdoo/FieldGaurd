export type FinalResult =
  | 'PRESUMPTIVE POSITIVE'
  | 'PRELIMINARY NEGATIVE'
  | 'INCONCLUSIVE'
  | 'INVALID';

export type RawPrediction =
  | 'POSITIVE'
  | 'NEGATIVE'
  | 'INCONCLUSIVE'
  | 'INVALID';

export type QualityGate =
  | 'ACCEPTABLE'
  | 'RETAKE RECOMMENDED';

export type EvidenceMode =
  | 'VISION_ONLY'
  | 'VISION_PLUS_AUXILIARY_SENSOR'
  | 'VISION_WITH_LOW_CONF_SENSOR';

export type SignalClass =
  | 'Baseline'
  | 'Warming'
  | 'Cooling';

export interface QualityMetrics {
  brightness: number;
  contrast: number;
  sharpness: number;
  resolution: string;
}

export interface Probabilities {
  POSITIVE: number;
  NEGATIVE: number;
  INCONCLUSIVE: number;
  INVALID: number;
}

export interface VisionEvidence {
  quality_risk: number;
  quality_gate: QualityGate;
  quality_reason: string;
  raw_class: RawPrediction;
  confidence: number;
  probabilities: Probabilities;
  quality_metrics: QualityMetrics;
}

export interface SensorEvidence {
  available: boolean;
  signal_class: SignalClass | null;
  confidence: number | null;
  status: string;
  readings: number[];
}

/* =========================================================
   REAL BACKEND AUDIT RECORD
========================================================= */

export interface AuditInfo {
  recorded: boolean;
  case_id: string | null;
  timestamp_utc: string | null;
  operator_id: string | null;
  image_filename?: string | null;
  json_filename?: string | null;
  csv_filename?: string | null;
  download_url?: string | null;
  report_url?: string | null;
}

/* =========================================================
   ANALYSIS RESULT
========================================================= */

export interface AnalysisResult {
  final_result: FinalResult;
  evidence_mode: EvidenceMode;
  reason: string;
  vision: VisionEvidence;
  sensor: SensorEvidence;
  image_sha256: string;
  warnings: string[];
  audit?: AuditInfo | null;
  case_id?: string | null;
  sensor_sample_id?: string | null;
}

/* =========================================================
   CASE RECORD (EXISTING COMPATIBILITY)
========================================================= */

export interface CaseRecord {
  case_id: string;
  timestamp: string;
  image_filename: string | null;
  image_sha256: string | null;

  final_result: FinalResult;

  raw_prediction: RawPrediction;
  raw_confidence: number;

  quality_risk: number;
  quality_gate: QualityGate;
  quality_metrics: QualityMetrics;

  sensor_available: boolean;
  sensor_class: SignalClass | null;
  sensor_confidence: number | null;
  sensor_readings: number[];

  evidence_mode: EvidenceMode;

  probabilities: Probabilities;

  reason: string;
  warnings: string[];

  audit_status: string;
}

/* =========================================================
   ENTERPRISE FORENSIC SYSTEM ROLES & USERS
========================================================= */

export type UserRole =
  | 'FIELD_OFFICER'
  | 'SUPERVISOR'
  | 'FORENSIC_ANALYST'
  | 'AUDITOR'
  | 'ADMIN';

export interface User {
  user_id: string;
  badge_number: string;
  full_name: string;
  name?: string;
  email: string;
  role: UserRole;
  department: string;
  avatar_url?: string;
}

/* =========================================================
   CASE LIFECYCLE & MANAGEMENT
========================================================= */

export type CaseStatus =
  | 'DRAFT'
  | 'ACTIVE'
  | 'TESTING'
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'SEALED'
  | 'ARCHIVED';

export type CasePriority =
  | 'LOW'
  | 'MEDIUM'
  | 'HIGH'
  | 'URGENT';

export interface ForensicCase {
  case_id: string; // e.g. "FG-2026-000184"
  case_number: string;
  case_type: string;
  title?: string;
  description: string;
  priority: CasePriority;
  status: CaseStatus;
  created_by: string; // User ID or name
  assigned_officer: string;
  supervisor: string;
  location_name: string;
  gps_coordinates: {
    lat: number;
    lng: number;
  };
  evidence_count: number;
  test_count: number;
  created_at: string;
  updated_at: string;
}

/* =========================================================
   EVIDENCE & VERSIONING
========================================================= */

export type EvidenceStatus =
  | 'REGISTERED'
  | 'COLLECTED'
  | 'TESTED'
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'SEALED'
  | 'TRANSFERRED'
  | 'ARCHIVED';

export interface EvidenceVersion {
  version_number: number;
  timestamp: string;
  modified_by: string;
  reason: string;
  metadata_snapshot: Record<string, unknown>;
  sha256_hash: string;
}

export interface EvidenceItem {
  evidence_id: string; // e.g. "EV-FG26-000184-01"
  evidence_number?: string;
  case_id: string;
  sample_id: string;
  evidence_type: string;
  type?: string;
  description: string;
  substance_claimed?: string;
  ai_prediction?: string;
  ai_confidence?: number;
  officer_verification?: VerificationRecord;
  supervisor_signoff?: VerificationRecord;
  current_location?: string;
  current_custodian?: string;
  collected_by: string;
  collection_timestamp: string;
  collection_location: string;
  gps_coordinates: {
    lat: number;
    lng: number;
  };
  device_id: string;
  photo_url?: string;
  test_kit_id?: string;
  kit_batch_number?: string;
  kit_expiry_date?: string;
  status: EvidenceStatus;
  current_version: number;
  sha256_hash: string;
  hash_algorithm: 'SHA-256';
  versions: EvidenceVersion[];
  is_tampered?: boolean;
  tampered_field?: string;
  tampered_value?: unknown;
  original_value?: unknown;
  created_at: string;
  updated_at: string;
}

/* =========================================================
   TEST KIT MANAGEMENT
========================================================= */

export type KitStatus =
  | 'AVAILABLE'
  | 'IN_USE'
  | 'EXPIRED'
  | 'DEPLETED'
  | 'QUARANTINED';

export interface TestKit {
  kit_id: string;
  manufacturer: string;
  kit_type: string;
  kit_name?: string;
  target_substance: string;
  target_substances?: string[];
  batch_number: string;
  lot_number: string;
  expiry_date: string;
  received_date: string;
  quantity: number;
  remaining_tests?: number;
  storage_location: string;
  status: KitStatus;
  quarantined?: boolean;
  notes?: string;
}

/* =========================================================
   IMAGE QUALITY ANALYSIS & COLOR CALIBRATION
========================================================= */

export type QualityCheckStatus = 'GOOD' | 'ACCEPTABLE' | 'POOR';

export interface ImageQualityReport {
  overall: QualityCheckStatus;
  resolution_ok: boolean;
  lighting_ok: boolean;
  blur_ok: boolean;
  color_reference_ok: boolean;
  metrics: {
    brightness: number;
    contrast: number;
    sharpness: number;
    resolution: string;
  };
  message: string;
}

export interface ColorCalibration {
  calibration_id: string;
  reference_profile: string;
  lighting_condition: string;
  white_balance: string;
  exposure: string;
  image_hash: string;
  timestamp: string;
}

/* =========================================================
   CHAIN OF CUSTODY
========================================================= */

export type CustodyAction =
  | 'COLLECTED'
  | 'TESTED'
  | 'VERIFIED'
  | 'TRANSFERRED'
  | 'RECEIVED'
  | 'SEALED'
  | 'ARCHIVED';

export interface CustodyEvent {
  event_id: string;
  evidence_id: string;
  case_id: string;
  from_user: string;
  to_user: string;
  from_location: string;
  to_location: string;
  action: CustodyAction;
  timestamp: string;
  reason: string;
  digital_acknowledgement: boolean;
  event_hash: string;
}

/* =========================================================
   HUMAN-IN-THE-LOOP VERIFICATION
========================================================= */

export type VerificationStage = 'OFFICER' | 'SUPERVISOR';
export type VerificationDecision = 'CONFIRM' | 'REJECT' | 'REQUEST_RETEST';

export interface VerificationRecord {
  verification_id: string;
  case_id: string;
  evidence_id: string;
  stage: VerificationStage;
  reviewer_id: string;
  reviewer_name: string;
  decision: VerificationDecision;
  reason?: string;
  timestamp: string;
  discrepancy_flag?: boolean;
}

/* =========================================================
   IMMUTABLE AUDIT LOG
========================================================= */

export type AuditAction =
  | 'CASE_CREATED'
  | 'CASE_UPDATED'
  | 'EVIDENCE_REGISTERED'
  | 'IMAGE_UPLOADED'
  | 'TEST_STARTED'
  | 'TEST_COMPLETED'
  | 'AI_ANALYSIS_COMPLETED'
  | 'RESULT_VERIFIED'
  | 'RESULT_REJECTED'
  | 'EVIDENCE_VIEWED'
  | 'EVIDENCE_EXPORTED'
  | 'EVIDENCE_TRANSFERRED'
  | 'EVIDENCE_SEALED'
  | 'REPORT_GENERATED'
  | 'USER_LOGIN'
  | 'USER_LOGOUT'
  | 'ROLE_CHANGED'
  | 'INTEGRITY_CHECK_PASSED'
  | 'INTEGRITY_CHECK_FAILED'
  | 'EVIDENCE_TAMPER_SIMULATED'
  | 'EVIDENCE_RESTORED';

export interface AuditEvent {
  event_id: string;
  user_id: string;
  user_role: UserRole;
  action: AuditAction;
  entity_type: 'CASE' | 'EVIDENCE' | 'TEST' | 'REPORT' | 'USER' | 'SYSTEM' | 'KIT';
  entity_id: string;
  timestamp: string;
  ip_address?: string;
  device_id?: string;
  previous_value?: string | null;
  new_value?: string | null;
  hash_reference?: string;
}

/* =========================================================
   FORENSIC REPORT
========================================================= */

export interface ForensicReport {
  report_id: string;
  case_id: string;
  evidence_id: string;
  version: string; // e.g. "Report v1"
  generated_at: string;
  generated_by: string;
  report_hash: string;
  qr_code_url: string;
}

/* =========================================================
   OFFLINE SYNC
========================================================= */

export type SyncStatus = 'ONLINE' | 'OFFLINE' | 'SYNCING' | 'SYNC COMPLETE' | 'SYNC ERROR';

export interface SyncQueueItem {
  queue_id: string;
  action: 'CREATE_CASE' | 'REGISTER_EVIDENCE' | 'RECORD_TEST' | 'CUSTODY_TRANSFER' | 'VERIFY';
  payload: Record<string, unknown>;
  timestamp: string;
  status: 'PENDING' | 'SYNCING' | 'COMPLETED' | 'ERROR';
  error?: string;
}

/* =========================================================
   NAVIGATION & WORKFLOW
========================================================= */

export type Page =
  | 'overview'
  | 'analysis'
  | 'cases'
  | 'reports'
  | 'system'
  | 'dashboard'
  | 'evidence'
  | 'custody'
  | 'verification'
  | 'kits'
  | 'audit'
  | 'analytics'
  | 'verify';

export type WorkflowStep =
  | 'CASE_SELECT'
  | 'EVIDENCE_SELECT'
  | 'KIT_SELECT'
  | 'KIT_VERIFY'
  | 'CAPTURE'
  | 'QUALITY'
  | 'CALIBRATION'
  | 'AI_ANALYSIS'
  | 'OFFICER_REVIEW'
  | 'SUPERVISOR_REVIEW'
  | 'FINALIZE'
  | 'VISION'
  | 'SENSOR'
  | 'DECISION'
  | 'AUDIT'
  | string;

export interface WorkflowState {
  step: WorkflowStep;
  status: 'pending' | 'active' | 'complete';
}
