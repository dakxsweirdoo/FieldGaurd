/*
# Create cases table for FIELDGUARD field screening records

1. New Tables
- `cases` — stores complete analysis records for field drug-test screenings
  - `case_id` (text, primary key) — human-readable ID like FG-20260914-XXXXXX
  - `timestamp` (timestamptz) — when the analysis was performed
  - `image_filename` (text) — original uploaded filename
  - `image_sha256` (text) — SHA-256 hash of the test image for traceability
  - `final_result` (text) — final operational decision (PRESUMPTIVE POSITIVE / PRELIMINARY NEGATIVE / INCONCLUSIVE / INVALID)
  - `raw_prediction` (text) — raw AI vision model prediction
  - `raw_confidence` (numeric) — raw model confidence percentage
  - `quality_risk` (numeric) — quality risk percentage
  - `quality_gate` (text) — ACCEPTABLE or RETAKE RECOMMENDED
  - `quality_metrics` (jsonb) — brightness, contrast, sharpness, resolution
  - `sensor_available` (boolean) — whether auxiliary sensor data was available
  - `sensor_class` (text) — signal condition label (Baseline, Warming, Cooling)
  - `sensor_confidence` (numeric) — sensor classification confidence
  - `sensor_readings` (jsonb) — array of 31 sensor readings
  - `evidence_mode` (text) — VISION_ONLY or VISION_PLUS_AUXILIARY_SENSOR
  - `probabilities` (jsonb) — full probability distribution from vision model
  - `reason` (text) — human-readable explanation of the decision
  - `warnings` (jsonb) — array of warning strings
  - `audit_status` (text) — RECORDED
  - `created_at` (timestamptz) — record creation timestamp

2. Security
- Enable RLS on `cases`.
- Single-tenant no-auth app: allow anon + authenticated full CRUD.
  All field officers share the same case data intentionally.
*/

CREATE TABLE IF NOT EXISTS cases (
  case_id text PRIMARY KEY,
  timestamp timestamptz NOT NULL DEFAULT now(),
  image_filename text,
  image_sha256 text,
  final_result text NOT NULL,
  raw_prediction text,
  raw_confidence numeric,
  quality_risk numeric,
  quality_gate text,
  quality_metrics jsonb,
  sensor_available boolean DEFAULT false,
  sensor_class text,
  sensor_confidence numeric,
  sensor_readings jsonb,
  evidence_mode text,
  probabilities jsonb,
  reason text,
  warnings jsonb DEFAULT '[]'::jsonb,
  audit_status text DEFAULT 'RECORDED',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_cases" ON cases;
CREATE POLICY "anon_select_cases" ON cases FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_cases" ON cases;
CREATE POLICY "anon_insert_cases" ON cases FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_cases" ON cases;
CREATE POLICY "anon_update_cases" ON cases FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_cases" ON cases;
CREATE POLICY "anon_delete_cases" ON cases FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_cases_timestamp ON cases (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_cases_final_result ON cases (final_result);
