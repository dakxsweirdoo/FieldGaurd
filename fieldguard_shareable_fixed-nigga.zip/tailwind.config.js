/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        canvas: {
          DEFAULT: '#F6F5F0',
          warm: '#F1EFE9',
          cool: '#EEF0F2',
        },
        ink: {
          DEFAULT: '#1A1C18',
          soft: '#393D34',
          muted: '#676B5E',
          light: '#9DA191',
        },
        guard: {
          50: '#E8F2EB',
          100: '#D1E5D7',
          200: '#A4CDAF',
          300: '#77B487',
          400: '#5A9D6D',
          500: '#3D8453',
          600: '#2E6A40',
          700: '#245535',
          800: '#1B4128',
          900: '#132D1B',
        },
        amber: {
          50: '#FBF5E7',
          100: '#F5E7C2',
          200: '#EDD189',
          300: '#E0BC54',
          400: '#CDA23C',
          500: '#B0862C',
          600: '#8E6B22',
          700: '#73531A',
        },
        alert: {
          50: '#FAE9E9',
          100: '#F3D2D2',
          200: '#E6A6A6',
          300: '#D97A7A',
          400: '#C75A5A',
          500: '#A23838',
          600: '#842828',
          700: '#681D1D',
        },
        info: {
          50: '#EDF2F7',
          100: '#D2E0EC',
          200: '#A6C2D6',
          300: '#7AA3C0',
          400: '#5887AB',
          500: '#3E6E92',
          600: '#305679',
        },
        line: {
          DEFAULT: '#DFDDD6',
          soft: '#EBE9E2',
          strong: '#C7C4BB',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          raised: '#FCFBF7',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      borderRadius: {
        'xl': '10px',
        '2xl': '12px',
      },
      boxShadow: {
        'card': '0 1px 3px rgba(26,28,24,0.05), 0 1px 1px rgba(26,28,24,0.03)',
        'card-raised': '0 2px 8px rgba(26,28,24,0.07), 0 1px 2px rgba(26,28,24,0.04)',
        'panel': '0 1px 3px rgba(26,28,24,0.04)',
        'inset': 'inset 0 1px 2px rgba(26,28,24,0.04)',
      },
      maxWidth: {
        'instrument': '1400px',
      },
      animation: {
        'fade-in': 'fadeIn 0.25s ease-out',
        'slide-up': 'slideUp 0.35s ease-out',
        'step-complete': 'stepComplete 0.25s ease-out',
        'bar-grow': 'barGrow 0.5s ease-out',
        'reveal': 'reveal 0.4s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        stepComplete: {
          '0%': { transform: 'scale(0.85)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        barGrow: {
          '0%': { width: '0%' },
        },
        reveal: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
};
